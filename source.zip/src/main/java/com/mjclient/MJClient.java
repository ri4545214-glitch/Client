package com.mjclient;

import com.mjclient.gui.ClickGuiScreen;
import com.mjclient.module.Module;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;
import org.lwjgl.glfw.GLFW;

public class MJClient implements ClientModInitializer {
	public static final String NAME = "MJ Client";

	private static boolean openRequested;
	private boolean rShiftDown;

	@Override
	public void onInitializeClient() {
		ModuleManager.init();
		Config.load();

		ClientTickEvents.END_CLIENT_TICK.register(this::tick);
		HudRenderCallback.EVENT.register(this::hud);

		// /mj also opens the GUI (handy on mobile without a keyboard)
		ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) ->
				dispatcher.register(ClientCommandManager.literal("mj").executes(context -> {
					openRequested = true;
					return 1;
				})));
	}

	private void tick(MinecraftClient mc) {
		if (mc.getWindow() != null) {
			boolean down = GLFW.glfwGetKey(mc.getWindow().getHandle(), GLFW.GLFW_KEY_RIGHT_SHIFT) == GLFW.GLFW_PRESS;
			if (down && !rShiftDown) {
				if (mc.currentScreen instanceof ClickGuiScreen) {
					mc.setScreen(null);
				} else if (mc.currentScreen == null && mc.player != null) {
					mc.setScreen(new ClickGuiScreen());
				}
			}
			rShiftDown = down;
		}
		if (openRequested && mc.currentScreen == null && mc.player != null) {
			openRequested = false;
			mc.setScreen(new ClickGuiScreen());
		}
		if (mc.player == null || mc.world == null) return;
		for (Module m : ModuleManager.MODULES) {
			if (m.enabled) m.onTick(mc);
		}
	}

	private void hud(DrawContext ctx, RenderTickCounter tickCounter) {
		MinecraftClient mc = MinecraftClient.getInstance();
		if (mc.player == null || mc.world == null) return;
		for (Module m : ModuleManager.MODULES) {
			if (m.enabled) m.onHud(ctx, mc);
		}
	}
}
