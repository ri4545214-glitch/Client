package com.mjclient.module;

import com.mjclient.setting.BoolSetting;
import com.mjclient.setting.ModeSetting;
import com.mjclient.setting.NumberSetting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.entity.mob.Monster;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.MathHelper;

public class Aimbot extends Module {
	public final BoolSetting players = add(new BoolSetting("Players", true));
	public final BoolSetting hostile = add(new BoolSetting("Hostile", true));
	public final BoolSetting passive = add(new BoolSetting("Passive", false));
	public final NumberSetting range = add(new NumberSetting("Range", 6, 2, 20, 0.5));
	public final NumberSetting fov = add(new NumberSetting("FOV", 120, 10, 360, 5));
	public final NumberSetting speed = add(new NumberSetting("Speed", 10, 1, 30, 1));
	public final ModeSetting aimAt = add(new ModeSetting("Aim At", "Head", "Head", "Body", "Feet"));
	public final ModeSetting priority = add(new ModeSetting("Priority", "Distance", "Distance", "Angle", "Health"));
	public final BoolSetting visibleOnly = add(new BoolSetting("Visible Only", true));
	public final BoolSetting onAttack = add(new BoolSetting("On Attack Only", false));

	private long lastNs;

	public Aimbot() {
		super("Aimbot", "Smoothly aims at players & mobs", Category.BASE, false);
	}

	private double[] aimPoint(Entity e) {
		double y;
		if (aimAt.is("Head")) y = e.getEyeY();
		else if (aimAt.is("Body")) y = e.getY() + e.getHeight() * 0.5;
		else y = e.getY() + 0.1;
		return new double[]{e.getX(), y, e.getZ()};
	}

	@Override
	public void onHud(DrawContext ctx, MinecraftClient mc) {
		long now = System.nanoTime();
		double dt = lastNs == 0 ? 0.016 : Math.min(0.1, (now - lastNs) / 1e9);
		lastNs = now;
		if (mc.currentScreen != null) return;
		if (onAttack.value && !mc.options.attackKey.isPressed()) return;

		ClientPlayerEntity p = mc.player;
		double ex = p.getX(), ey = p.getEyeY(), ez = p.getZ();
		Entity best = null;
		double bestScore = Double.MAX_VALUE, bestYaw = 0, bestPitch = 0;

		for (Entity e : mc.world.getEntities()) {
			if (e == p || !(e instanceof LivingEntity) || e instanceof ArmorStandEntity) continue;
			LivingEntity le = (LivingEntity) e;
			if (!le.isAlive()) continue;
			if (e instanceof PlayerEntity) {
				if (!players.value || ((PlayerEntity) e).isSpectator()) continue;
			} else if (e instanceof Monster) {
				if (!hostile.value) continue;
			} else if (!passive.value) {
				continue;
			}
			double[] a = aimPoint(e);
			double dx = a[0] - ex, dy = a[1] - ey, dz = a[2] - ez;
			double dist = Math.sqrt(dx * dx + dy * dy + dz * dz);
			if (dist > range.value) continue;
			if (visibleOnly.value && !p.canSee(e)) continue;

			double ty = Math.toDegrees(Math.atan2(dz, dx)) - 90.0;
			double tp = -Math.toDegrees(Math.atan2(dy, Math.hypot(dx, dz)));
			double yawDiff = MathHelper.wrapDegrees(ty - p.getYaw());
			double pitchDiff = tp - p.getPitch();
			double angle = Math.hypot(yawDiff, pitchDiff);
			if (angle > fov.value / 2.0) continue;

			double score;
			if (priority.is("Distance")) score = dist;
			else if (priority.is("Angle")) score = angle;
			else score = le.getHealth();
			if (score < bestScore) {
				bestScore = score;
				best = e;
				bestYaw = yawDiff;
				bestPitch = pitchDiff;
			}
		}
		if (best == null) return;

		double f = Math.min(1.0, speed.value * dt);
		p.setYaw(p.getYaw() + (float) (bestYaw * f));
		p.setPitch(MathHelper.clamp(p.getPitch() + (float) (bestPitch * f), -90f, 90f));
	}
}
