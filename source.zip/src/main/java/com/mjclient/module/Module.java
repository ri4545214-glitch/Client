package com.mjclient.module;

import com.mjclient.setting.Setting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

import java.util.ArrayList;
import java.util.List;

public abstract class Module {
	public final String name;
	public final String description;
	public final Category category;
	public final List<Setting> settings = new ArrayList<>();

	public boolean enabled;
	public boolean toggleable = true;
	public boolean expanded;
	public double anim; // GUI animation 0..1

	protected Module(String name, String description, Category category, boolean enabled) {
		this.name = name;
		this.description = description;
		this.category = category;
		this.enabled = enabled;
		this.anim = enabled ? 1 : 0;
	}

	protected <T extends Setting> T add(T setting) {
		settings.add(setting);
		return setting;
	}

	public void toggle() {
		if (toggleable) {
			enabled = !enabled;
		}
	}

	public void onTick(MinecraftClient mc) {
	}

	public void onHud(DrawContext ctx, MinecraftClient mc) {
	}
}
