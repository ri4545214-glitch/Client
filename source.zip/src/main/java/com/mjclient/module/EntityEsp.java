package com.mjclient.module;

import com.mjclient.setting.BoolSetting;
import com.mjclient.setting.ModeSetting;
import com.mjclient.setting.NumberSetting;
import com.mjclient.util.Render;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.entity.mob.Monster;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Box;

import java.util.ArrayList;
import java.util.List;

public class EntityEsp extends Module {
	public final BoolSetting players = add(new BoolSetting("Players", true));
	public final BoolSetting hostile = add(new BoolSetting("Hostile", true));
	public final BoolSetting passive = add(new BoolSetting("Passive", false));
	public final BoolSetting boxes = add(new BoolSetting("Boxes", true));
	public final BoolSetting fill = add(new BoolSetting("Fill", false));
	public final BoolSetting tracers = add(new BoolSetting("Tracers", true));
	public final BoolSetting names = add(new BoolSetting("Names", true));
	public final NumberSetting range = add(new NumberSetting("Range", 64, 8, 256, 8));
	public final NumberSetting maxTracers = add(new NumberSetting("Max Tracers", 15, 1, 40, 1));
	public final ModeSetting tracerFrom = add(new ModeSetting("Tracer From", "Bottom", "Bottom", "Center"));

	public EntityEsp() {
		super("Entity ESP", "Players & mobs through walls with tracers", Category.BASE, false);
	}

	@Override
	public void onHud(DrawContext ctx, MinecraftClient mc) {
		if (mc.options.hudHidden) return;
		double px = mc.player.getX(), py = mc.player.getY(), pz = mc.player.getZ();
		List<Object[]> list = new ArrayList<>();
		for (Entity e : mc.world.getEntities()) {
			if (e == mc.player || !(e instanceof LivingEntity) || e instanceof ArmorStandEntity) continue;
			if (!((LivingEntity) e).isAlive()) continue;
			int color;
			if (e instanceof PlayerEntity) {
				if (!players.value) continue;
				color = 0xFF38BDF8;
			} else if (e instanceof Monster) {
				if (!hostile.value) continue;
				color = 0xFFEF4444;
			} else {
				if (!passive.value) continue;
				color = 0xFF4ADE80;
			}
			double dx = e.getX() - px, dy = e.getY() - py, dz = e.getZ() - pz;
			double d = Math.sqrt(dx * dx + dy * dy + dz * dz);
			if (d > range.value) continue;
			list.add(new Object[]{e, d, color});
		}
		list.sort((a, b) -> Double.compare((double) a[1], (double) b[1]));
		int tracerCount = 0;
		boolean bottom = tracerFrom.is("Bottom");
		for (int i = 0; i < list.size() && i < 64; i++) {
			Entity e = (Entity) list.get(i)[0];
			double d = (double) list.get(i)[1];
			int color = (int) list.get(i)[2];
			boolean tracer = tracers.value && tracerCount < maxTracers.intValue();
			if (tracer) tracerCount++;
			String label = null;
			if (names.value) {
				label = e.getName().getString() + " " + (int) ((LivingEntity) e).getHealth() + "hp " + (int) d + "m";
			}
			Box b = e.getBoundingBox();
			Render.target(ctx, mc, b.minX, b.minY, b.minZ, b.maxX, b.maxY, b.maxZ,
					color, boxes.value, fill.value, tracer, bottom, label);
		}
	}
}
