package com.mjclient.module;

public enum Category {
	BASE("Base"),
	CLIENT("Client");

	public final String label;

	Category(String label) {
		this.label = label;
	}
}
