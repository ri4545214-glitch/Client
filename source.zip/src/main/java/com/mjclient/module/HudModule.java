package com.mjclient.module;

import com.mjclient.ModuleManager;
import com.mjclient.setting.BoolSetting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

public class HudModule extends Module {
	public final BoolSetting watermark = add(new BoolSetting("Watermark", true));
	public final BoolSetting arrayList = add(new BoolSetting("Module List", true));

	public HudModule() {
		super("HUD", "Watermark and enabled module list", Category.CLIENT, true);
	}

	@Override
	public void onHud(DrawContext ctx, MinecraftClient mc) {
		if (mc.options.hudHidden) return;
		int accent = ModuleManager.accent();
		if (watermark.value) {
			String t = "MJ Client  |  " + mc.getCurrentFps() + " fps";
			int w = mc.textRenderer.getWidth(t) + 10;
			ctx.fill(4, 4, 4 + w, 17, 0xC0101018);
			ctx.fill(4, 4, 4 + w, 5, accent);
			ctx.drawText(mc.textRenderer, t, 9, 7, 0xFFFFFFFF, true);
		}
		if (arrayList.value) {
			int sw = mc.getWindow().getScaledWidth();
			int y = 4;
			for (Module m : ModuleManager.MODULES) {
				if (!m.enabled || !m.toggleable || m == this) continue;
				int tw = mc.textRenderer.getWidth(m.name);
				ctx.fill(sw - tw - 9, y, sw - 3, y + 11, 0xA0101018);
				ctx.fill(sw - 3, y, sw - 2, y + 11, accent);
				ctx.drawText(mc.textRenderer, m.name, sw - tw - 6, y + 2, accent, true);
				y += 11;
			}
		}
	}
}
