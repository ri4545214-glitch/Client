package com.mjclient.module;

import com.mjclient.setting.BoolSetting;
import com.mjclient.setting.ModeSetting;
import com.mjclient.setting.NumberSetting;
import com.mjclient.util.Render;
import net.minecraft.block.entity.AbstractFurnaceBlockEntity;
import net.minecraft.block.entity.BarrelBlockEntity;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.block.entity.ChestBlockEntity;
import net.minecraft.block.entity.DispenserBlockEntity;
import net.minecraft.block.entity.EnderChestBlockEntity;
import net.minecraft.block.entity.HopperBlockEntity;
import net.minecraft.block.entity.ShulkerBoxBlockEntity;
import net.minecraft.block.entity.TrappedChestBlockEntity;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.chunk.WorldChunk;

import java.util.ArrayList;
import java.util.List;

public class StorageEsp extends Module {
	public final BoolSetting chests = add(new BoolSetting("Chests", true));
	public final BoolSetting enderChests = add(new BoolSetting("Ender Chests", true));
	public final BoolSetting hoppers = add(new BoolSetting("Hoppers", true));
	public final BoolSetting barrels = add(new BoolSetting("Barrels", true));
	public final BoolSetting shulkers = add(new BoolSetting("Shulkers", true));
	public final BoolSetting furnaces = add(new BoolSetting("Furnaces", false));
	public final BoolSetting dispensers = add(new BoolSetting("Dispensers", false));
	public final BoolSetting boxes = add(new BoolSetting("Boxes", true));
	public final BoolSetting fill = add(new BoolSetting("Fill", true));
	public final BoolSetting tracers = add(new BoolSetting("Tracers", true));
	public final BoolSetting labels = add(new BoolSetting("Labels", true));
	public final NumberSetting range = add(new NumberSetting("Range", 64, 16, 128, 8));
	public final NumberSetting maxTracers = add(new NumberSetting("Max Tracers", 20, 1, 60, 1));
	public final ModeSetting tracerFrom = add(new ModeSetting("Tracer From", "Bottom", "Bottom", "Center"));

	private record Target(int x, int y, int z, int color, String name) {
	}

	private final List<Target> targets = new ArrayList<>();
	private int ticks;

	public StorageEsp() {
		super("Storage ESP", "Highlights chests, hoppers & more through walls", Category.BASE, true);
	}

	@Override
	public void onTick(MinecraftClient mc) {
		if (++ticks % 10 != 0) return;
		List<Target> found = new ArrayList<>();
		int rad = (int) Math.ceil(range.value / 16.0) + 1;
		int pcx = mc.player.getBlockX() >> 4, pcz = mc.player.getBlockZ() >> 4;
		double r2 = range.value * range.value;
		for (int dx = -rad; dx <= rad; dx++) {
			for (int dz = -rad; dz <= rad; dz++) {
				WorldChunk chunk = mc.world.getChunkManager().getWorldChunk(pcx + dx, pcz + dz);
				if (chunk == null) continue;
				for (BlockEntity be : new ArrayList<>(chunk.getBlockEntities().values())) {
					Target t = classify(be);
					if (t == null) continue;
					double ddx = t.x + 0.5 - mc.player.getX(), ddy = t.y + 0.5 - mc.player.getY(), ddz = t.z + 0.5 - mc.player.getZ();
					if (ddx * ddx + ddy * ddy + ddz * ddz <= r2) found.add(t);
				}
			}
		}
		targets.clear();
		targets.addAll(found);
	}

	private Target classify(BlockEntity be) {
		BlockPos p = be.getPos();
		if (be instanceof TrappedChestBlockEntity) {
			return chests.value ? new Target(p.getX(), p.getY(), p.getZ(), 0xFFEF4444, "Trapped Chest") : null;
		}
		if (be instanceof ChestBlockEntity) {
			return chests.value ? new Target(p.getX(), p.getY(), p.getZ(), 0xFFF59E0B, "Chest") : null;
		}
		if (be instanceof EnderChestBlockEntity) {
			return enderChests.value ? new Target(p.getX(), p.getY(), p.getZ(), 0xFFA855F7, "Ender Chest") : null;
		}
		if (be instanceof HopperBlockEntity) {
			return hoppers.value ? new Target(p.getX(), p.getY(), p.getZ(), 0xFF22D3EE, "Hopper") : null;
		}
		if (be instanceof BarrelBlockEntity) {
			return barrels.value ? new Target(p.getX(), p.getY(), p.getZ(), 0xFFD97706, "Barrel") : null;
		}
		if (be instanceof ShulkerBoxBlockEntity) {
			return shulkers.value ? new Target(p.getX(), p.getY(), p.getZ(), 0xFFEC4899, "Shulker") : null;
		}
		if (be instanceof AbstractFurnaceBlockEntity) {
			return furnaces.value ? new Target(p.getX(), p.getY(), p.getZ(), 0xFF9CA3AF, "Furnace") : null;
		}
		if (be instanceof DispenserBlockEntity) {
			return dispensers.value ? new Target(p.getX(), p.getY(), p.getZ(), 0xFF4ADE80, "Dispenser") : null;
		}
		return null;
	}

	@Override
	public void onHud(DrawContext ctx, MinecraftClient mc) {
		if (mc.options.hudHidden || targets.isEmpty()) return;
		double px = mc.player.getX(), py = mc.player.getY(), pz = mc.player.getZ();
		List<double[]> order = new ArrayList<>();
		for (int i = 0; i < targets.size(); i++) {
			Target t = targets.get(i);
			double dx = t.x + 0.5 - px, dy = t.y + 0.5 - py, dz = t.z + 0.5 - pz;
			order.add(new double[]{i, Math.sqrt(dx * dx + dy * dy + dz * dz)});
		}
		order.sort((a, b) -> Double.compare(a[1], b[1]));
		int tracerCount = 0;
		boolean bottom = tracerFrom.is("Bottom");
		for (double[] o : order) {
			Target t = targets.get((int) o[0]);
			boolean tracer = tracers.value && tracerCount < maxTracers.intValue();
			if (tracer) tracerCount++;
			String label = labels.value ? t.name + " " + (int) o[1] + "m" : null;
			Render.target(ctx, mc, t.x, t.y, t.z, t.x + 1, t.y + 1, t.z + 1,
					t.color, boxes.value, fill.value, tracer, bottom, label);
		}
	}
}
