package com.mjclient.module;

import com.mjclient.setting.BoolSetting;
import com.mjclient.setting.ModeSetting;
import com.mjclient.util.Render;

public class ThemeModule extends Module {
	public final ModeSetting color = add(new ModeSetting("Color", "Blue", "Blue", "Purple", "Red", "Green", "Orange", "Cyan", "Pink"));
	public final BoolSetting rainbow = add(new BoolSetting("Rainbow", false));
	public final BoolSetting dim = add(new BoolSetting("Dim Background", true));

	public ThemeModule() {
		super("Theme", "GUI accent color and look", Category.CLIENT, true);
		toggleable = false;
	}

	public int accent() {
		if (rainbow.value) {
			return Render.hsv((System.currentTimeMillis() % 6000) / 6000f, 0.6f, 1f);
		}
		return switch (color.value()) {
			case "Purple" -> 0xFF8B5CF6;
			case "Red" -> 0xFFEF4444;
			case "Green" -> 0xFF22C55E;
			case "Orange" -> 0xFFF59E0B;
			case "Cyan" -> 0xFF06B6D4;
			case "Pink" -> 0xFFEC4899;
			default -> 0xFF3B82F6;
		};
	}
}
