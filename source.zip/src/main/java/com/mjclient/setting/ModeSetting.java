package com.mjclient.setting;

public class ModeSetting extends Setting {
	public final String[] modes;
	public int index;

	public ModeSetting(String name, String def, String... modes) {
		super(name);
		this.modes = modes;
		for (int i = 0; i < modes.length; i++) {
			if (modes[i].equals(def)) {
				index = i;
			}
		}
	}

	public String value() {
		return modes[index];
	}

	public boolean is(String mode) {
		return modes[index].equals(mode);
	}

	public void cycle(int dir) {
		index = (index + dir + modes.length) % modes.length;
	}

	@Override
	public String serialize() {
		return value();
	}

	@Override
	public void deserialize(String s) {
		for (int i = 0; i < modes.length; i++) {
			if (modes[i].equals(s)) {
				index = i;
			}
		}
	}
}
