package com.mjclient.setting;

import java.util.Locale;

public class NumberSetting extends Setting {
	public final double min, max, step;
	public double value;

	public NumberSetting(String name, double def, double min, double max, double step) {
		super(name);
		this.min = min;
		this.max = max;
		this.step = step;
		set(def);
	}

	public void set(double v) {
		v = Math.max(min, Math.min(max, v));
		if (step > 0) {
			v = Math.round((v - min) / step) * step + min;
		}
		this.value = Math.max(min, Math.min(max, v));
	}

	public int intValue() {
		return (int) Math.round(value);
	}

	public String display() {
		if (step >= 1) {
			return String.valueOf((int) Math.round(value));
		}
		return String.format(Locale.ROOT, "%.1f", value);
	}

	@Override
	public String serialize() {
		return Double.toString(value);
	}

	@Override
	public void deserialize(String s) {
		try {
			set(Double.parseDouble(s));
		} catch (NumberFormatException ignored) {
		}
	}
}
