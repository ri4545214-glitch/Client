package com.mjclient.setting;

public class BoolSetting extends Setting {
	public boolean value;

	public BoolSetting(String name, boolean def) {
		super(name);
		this.value = def;
	}

	public void toggle() {
		value = !value;
	}

	@Override
	public String serialize() {
		return String.valueOf(value);
	}

	@Override
	public void deserialize(String s) {
		value = Boolean.parseBoolean(s);
	}
}
