package com.mjclient.util;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.ClientPlayerEntity;

/** 2D drawing + 3D->screen projection helpers (no custom render pipeline needed). */
public final class Render {
	private Render() {
	}

	public static int alpha(int rgb, int a) {
		return ((a & 0xFF) << 24) | (rgb & 0xFFFFFF);
	}

	public static int mix(int a, int b, double t) {
		t = Math.max(0, Math.min(1, t));
		int r = (int) (((a >> 16) & 0xFF) * (1 - t) + ((b >> 16) & 0xFF) * t);
		int g = (int) (((a >> 8) & 0xFF) * (1 - t) + ((b >> 8) & 0xFF) * t);
		int bl = (int) ((a & 0xFF) * (1 - t) + (b & 0xFF) * t);
		return 0xFF000000 | (r << 16) | (g << 8) | bl;
	}

	public static int hsv(float h, float s, float v) {
		float r, g, b;
		int i = (int) Math.floor(h * 6);
		float f = h * 6 - i;
		float p = v * (1 - s), q = v * (1 - f * s), t = v * (1 - (1 - f) * s);
		switch (((i % 6) + 6) % 6) {
			case 0 -> { r = v; g = t; b = p; }
			case 1 -> { r = q; g = v; b = p; }
			case 2 -> { r = p; g = v; b = t; }
			case 3 -> { r = p; g = q; b = v; }
			case 4 -> { r = t; g = p; b = v; }
			default -> { r = v; g = p; b = q; }
		}
		return 0xFF000000 | ((int) (r * 255) << 16) | ((int) (g * 255) << 8) | (int) (b * 255);
	}

	public static void outline(DrawContext c, int x1, int y1, int x2, int y2, int color) {
		c.fill(x1, y1, x2, y1 + 1, color);
		c.fill(x1, y2 - 1, x2, y2, color);
		c.fill(x1, y1 + 1, x1 + 1, y2 - 1, color);
		c.fill(x2 - 1, y1 + 1, x2, y2 - 1, color);
	}

	/** Clipped 1px line drawn as run-length fills. */
	public static void line(DrawContext c, int w, int h, double x1, double y1, double x2, double y2, int color) {
		double dx = x2 - x1, dy = y2 - y1;
		double t0 = 0, t1 = 1;
		double[] p = {-dx, dx, -dy, dy};
		double[] q = {x1, w - x1, y1, h - y1};
		for (int i = 0; i < 4; i++) {
			if (p[i] == 0) {
				if (q[i] < 0) return;
			} else {
				double r = q[i] / p[i];
				if (p[i] < 0) {
					if (r > t1) return;
					if (r > t0) t0 = r;
				} else {
					if (r < t0) return;
					if (r < t1) t1 = r;
				}
			}
		}
		double ax = x1 + t0 * dx, ay = y1 + t0 * dy, bx = x1 + t1 * dx, by = y1 + t1 * dy;
		if (Math.abs(bx - ax) >= Math.abs(by - ay)) {
			if (ax > bx) {
				double t = ax; ax = bx; bx = t;
				t = ay; ay = by; by = t;
			}
			int xs = (int) Math.floor(ax), xe = (int) Math.floor(bx);
			double slope = bx > ax ? (by - ay) / (bx - ax) : 0;
			int runStart = xs, runY = (int) Math.floor(ay);
			for (int x = xs + 1; x <= xe + 1; x++) {
				int y = x <= xe ? (int) Math.floor(ay + (x - ax) * slope) : Integer.MIN_VALUE;
				if (y != runY) {
					c.fill(runStart, runY, x, runY + 1, color);
					runStart = x;
					runY = y;
				}
			}
		} else {
			if (ay > by) {
				double t = ax; ax = bx; bx = t;
				t = ay; ay = by; by = t;
			}
			int ys = (int) Math.floor(ay), ye = (int) Math.floor(by);
			double slope = by > ay ? (bx - ax) / (by - ay) : 0;
			int runStart = ys, runX = (int) Math.floor(ax);
			for (int y = ys + 1; y <= ye + 1; y++) {
				int x = y <= ye ? (int) Math.floor(ax + (y - ay) * slope) : Integer.MIN_VALUE;
				if (x != runX) {
					c.fill(runX, runStart, runX + 1, y, color);
					runStart = y;
					runX = x;
				}
			}
		}
	}

	/**
	 * Projects a world position to GUI-scaled screen coordinates.
	 * Returns {x, y, depth}; depth &lt;= 0 means behind the camera (x,y then point toward the screen edge).
	 */
	public static double[] project(MinecraftClient mc, double x, double y, double z) {
		ClientPlayerEntity p = mc.player;
		double dx = x - p.getX(), dy = y - p.getEyeY(), dz = z - p.getZ();
		double yr = Math.toRadians(p.getYaw()), pr = Math.toRadians(p.getPitch());
		double sy = Math.sin(yr), cy = Math.cos(yr), sp = Math.sin(pr), cp = Math.cos(pr);

		double right = -dx * cy - dz * sy;
		double up = -dx * sy * sp + dy * cp + dz * cy * sp;
		double fwd = -dx * sy * cp - dy * sp + dz * cy * cp;

		double w = mc.getWindow().getScaledWidth(), h = mc.getWindow().getScaledHeight();
		double tan = Math.tan(Math.toRadians(mc.options.getFov().getValue()) / 2.0);
		double aspect = w / h;

		if (fwd > 0.05) {
			double sx = w / 2 + (right / fwd) / (tan * aspect) * (w / 2);
			double sc = h / 2 - (up / fwd) / tan * (h / 2);
			return new double[]{sx, sc, fwd};
		}
		double len = Math.hypot(right, up);
		if (len < 1e-6) {
			right = 0;
			up = -1;
			len = 1;
		}
		return new double[]{w / 2 + right / len * (w + h), h / 2 - up / len * (w + h), -1};
	}

	/** Draws a box (screen-space), optional fill, label and tracer for a world AABB. */
	public static void target(DrawContext ctx, MinecraftClient mc,
							  double x1, double y1, double z1, double x2, double y2, double z2,
							  int color, boolean box, boolean fill, boolean tracer, boolean fromBottom, String label) {
		int w = mc.getWindow().getScaledWidth(), h = mc.getWindow().getScaledHeight();
		boolean allFront = true;
		double minX = 1e9, minY = 1e9, maxX = -1e9, maxY = -1e9;
		for (int i = 0; i < 8; i++) {
			double cx = (i & 1) == 0 ? x1 : x2;
			double cy = (i & 2) == 0 ? y1 : y2;
			double cz = (i & 4) == 0 ? z1 : z2;
			double[] s = project(mc, cx, cy, cz);
			if (s[2] <= 0) {
				allFront = false;
			} else {
				minX = Math.min(minX, s[0]);
				maxX = Math.max(maxX, s[0]);
				minY = Math.min(minY, s[1]);
				maxY = Math.max(maxY, s[1]);
			}
		}
		if (allFront && (box || fill || label != null)
				&& !(maxX < 0 || minX > w || maxY < 0 || minY > h)
				&& (maxX - minX) < w * 3 && (maxY - minY) < h * 3) {
			int ix1 = (int) minX, iy1 = (int) minY, ix2 = (int) maxX + 1, iy2 = (int) maxY + 1;
			if (fill) ctx.fill(ix1, iy1, ix2, iy2, alpha(color, 45));
			if (box) outline(ctx, ix1, iy1, ix2, iy2, color);
			if (label != null) {
				int tw = mc.textRenderer.getWidth(label);
				ctx.drawText(mc.textRenderer, label, (ix1 + ix2) / 2 - tw / 2, iy1 - 10, color, true);
			}
		}
		if (tracer) {
			double[] c = project(mc, (x1 + x2) / 2, (y1 + y2) / 2, (z1 + z2) / 2);
			double ox = w / 2.0, oy = fromBottom ? h : h / 2.0;
			line(ctx, w, h, ox, oy, c[0], c[1], color);
		}
	}
}
