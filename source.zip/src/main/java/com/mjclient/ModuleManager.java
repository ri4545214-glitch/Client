package com.mjclient;

import com.mjclient.module.Aimbot;
import com.mjclient.module.Category;
import com.mjclient.module.EntityEsp;
import com.mjclient.module.HudModule;
import com.mjclient.module.Module;
import com.mjclient.module.StorageEsp;
import com.mjclient.module.ThemeModule;

import java.util.ArrayList;
import java.util.List;

public final class ModuleManager {
	public static final List<Module> MODULES = new ArrayList<>();
	public static StorageEsp STORAGE_ESP;
	public static EntityEsp ENTITY_ESP;
	public static Aimbot AIMBOT;
	public static HudModule HUD;
	public static ThemeModule THEME;

	private ModuleManager() {
	}

	public static void init() {
		STORAGE_ESP = new StorageEsp();
		ENTITY_ESP = new EntityEsp();
		AIMBOT = new Aimbot();
		HUD = new HudModule();
		THEME = new ThemeModule();
		MODULES.add(STORAGE_ESP);
		MODULES.add(ENTITY_ESP);
		MODULES.add(AIMBOT);
		MODULES.add(HUD);
		MODULES.add(THEME);
	}

	public static List<Module> byCategory(Category c) {
		List<Module> out = new ArrayList<>();
		for (Module m : MODULES) {
			if (m.category == c) out.add(m);
		}
		return out;
	}

	public static int accent() {
		return THEME.accent();
	}
}
