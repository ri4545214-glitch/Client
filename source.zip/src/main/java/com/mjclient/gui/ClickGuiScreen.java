package com.mjclient.gui;

import com.mjclient.Config;
import com.mjclient.ModuleManager;
import com.mjclient.module.Category;
import com.mjclient.module.Module;
import com.mjclient.setting.BoolSetting;
import com.mjclient.setting.ModeSetting;
import com.mjclient.setting.NumberSetting;
import com.mjclient.setting.Setting;
import com.mjclient.util.Render;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;

public class ClickGuiScreen extends Screen {
	public static final Map<Category, int[]> POS = new EnumMap<>(Category.class);
	private static final Map<Category, Boolean> COLLAPSED = new EnumMap<>(Category.class);

	private static final int PANEL_W = 130, HEADER_H = 18, ROW_H = 15, SET_H = 16;

	private enum Kind { HEADER, MODULE, BOOL, NUM, MODE }

	private record Region(int x, int y, int w, int h, Kind kind, Category cat, Module module, Setting setting) {
		boolean contains(double mx, double my) {
			return mx >= x && mx < x + w && my >= y && my < y + h;
		}
	}

	private final List<Region> regions = new ArrayList<>();
	private Category dragPanel;
	private int dragOffX, dragOffY;
	private NumberSetting dragSlider;
	private int sliderX, sliderW;
	private double open;

	public ClickGuiScreen() {
		super(Text.literal("MJ Client"));
	}

	private static int[] pos(Category c) {
		return POS.computeIfAbsent(c, k -> new int[]{14 + k.ordinal() * (PANEL_W + 10), 34});
	}

	@Override
	public boolean shouldPause() {
		return false;
	}

	@Override
	public void removed() {
		Config.save();
	}

	// ------------------------------------------------------------ rendering

	@Override
	public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
		regions.clear();
		open = Math.min(1.0, open + 0.1);
		int accent = ModuleManager.accent();

		if (ModuleManager.THEME.dim.value) {
			ctx.fill(0, 0, width, height, Render.alpha(0x000000, (int) (120 * open)));
		}

		String title = "MJ CLIENT";
		ctx.drawText(textRenderer, title, width / 2 - textRenderer.getWidth(title) / 2, 8, accent, true);
		String hint = "Drag headers to move  |  Left click: toggle  |  Right click: settings";
		ctx.drawText(textRenderer, hint, width / 2 - textRenderer.getWidth(hint) / 2, 19, 0xFF9A9AAA, true);

		Module hovered = null;
		for (Category cat : Category.values()) {
			Module h = drawPanel(ctx, cat, mouseX, mouseY, accent);
			if (h != null) hovered = h;
		}
		if (hovered != null) {
			String d = hovered.description;
			int tw = textRenderer.getWidth(d);
			int tx = Math.min(mouseX + 10, width - tw - 8), ty = Math.min(mouseY + 10, height - 16);
			ctx.fill(tx - 3, ty - 3, tx + tw + 3, ty + 11, 0xF0101018);
			Render.outline(ctx, tx - 3, ty - 3, tx + tw + 3, ty + 11, accent);
			ctx.drawText(textRenderer, d, tx, ty, 0xFFFFFFFF, false);
		}
	}

	private Module drawPanel(DrawContext ctx, Category cat, int mouseX, int mouseY, int accent) {
		int[] p = pos(cat);
		int x = p[0], y = p[1];
		boolean collapsed = COLLAPSED.getOrDefault(cat, false);
		List<Module> mods = ModuleManager.byCategory(cat);

		int h = HEADER_H;
		if (!collapsed) {
			for (Module m : mods) {
				h += ROW_H;
				if (m.expanded) h += m.settings.size() * SET_H;
			}
		}

		ctx.fill(x - 1, y - 1, x + PANEL_W + 1, y + h + 1, Render.alpha(accent, 110));
		ctx.fill(x, y, x + PANEL_W, y + h, 0xF0121218);
		ctx.fill(x, y, x + PANEL_W, y + HEADER_H, 0xFF1B1B26);
		ctx.fill(x, y + HEADER_H - 1, x + PANEL_W, y + HEADER_H, accent);
		ctx.drawText(textRenderer, cat.label.toUpperCase(), x + 7, y + 5, 0xFFFFFFFF, true);
		String sign = collapsed ? "+" : "-";
		ctx.drawText(textRenderer, sign, x + PANEL_W - 12, y + 5, accent, true);
		regions.add(new Region(x, y, PANEL_W, HEADER_H, Kind.HEADER, cat, null, null));
		if (collapsed) return null;

		Module hovered = null;
		int cy = y + HEADER_H;
		for (Module m : mods) {
			boolean hov = mouseX >= x && mouseX < x + PANEL_W && mouseY >= cy && mouseY < cy + ROW_H;
			if (hov) hovered = m;
			m.anim += ((m.enabled ? 1 : 0) - m.anim) * 0.25;
			ctx.fill(x, cy, x + PANEL_W, cy + ROW_H, hov ? 0xFF22222E : 0xFF171720);
			if (m.anim > 0.02) {
				ctx.fill(x, cy, x + PANEL_W, cy + ROW_H, Render.alpha(accent, (int) (m.anim * 55)));
			}
			ctx.fill(x, cy, x + 2, cy + ROW_H, Render.mix(0xFF3A3A48, accent, m.anim));
			int nameColor = Render.mix(0xFFB0B0BC, 0xFFFFFFFF, m.anim);
			ctx.drawText(textRenderer, m.name, x + 8, cy + 4, nameColor, true);
			if (!m.settings.isEmpty()) {
				ctx.drawText(textRenderer, m.expanded ? "v" : ">", x + PANEL_W - 12, cy + 4, 0xFF7A7A8A, false);
			}
			regions.add(new Region(x, cy, PANEL_W, ROW_H, Kind.MODULE, cat, m, null));
			cy += ROW_H;
			if (m.expanded) {
				for (Setting s : m.settings) {
					drawSetting(ctx, s, m, cat, x, cy, mouseX, mouseY, accent);
					cy += SET_H;
				}
			}
		}
		return hovered;
	}

	private void drawSetting(DrawContext ctx, Setting s, Module m, Category cat, int x, int cy, int mouseX, int mouseY, int accent) {
		boolean hov = mouseX >= x && mouseX < x + PANEL_W && mouseY >= cy && mouseY < cy + SET_H;
		ctx.fill(x, cy, x + PANEL_W, cy + SET_H, hov ? 0xFF171722 : 0xFF0E0E15);
		ctx.fill(x + 3, cy, x + 4, cy + SET_H, Render.alpha(accent, 130));
		int textColor = 0xFFC8C8D2;

		if (s instanceof BoolSetting b) {
			ctx.drawText(textRenderer, s.name, x + 9, cy + 4, textColor, false);
			int px = x + PANEL_W - 22, py = cy + 5;
			ctx.fill(px, py, px + 14, py + 6, b.value ? accent : 0xFF2C2C38);
			int kx = b.value ? px + 8 : px;
			ctx.fill(kx, py, kx + 6, py + 6, 0xFFFFFFFF);
			regions.add(new Region(x, cy, PANEL_W, SET_H, Kind.BOOL, cat, m, s));
		} else if (s instanceof NumberSetting n) {
			ctx.drawText(textRenderer, s.name, x + 9, cy + 2, textColor, false);
			String v = n.display();
			ctx.drawText(textRenderer, v, x + PANEL_W - 7 - textRenderer.getWidth(v), cy + 2, accent, false);
			int sx = x + 9, sw = PANEL_W - 18;
			ctx.fill(sx, cy + SET_H - 4, sx + sw, cy + SET_H - 2, 0xFF2C2C38);
			double t = (n.value - n.min) / (n.max - n.min);
			ctx.fill(sx, cy + SET_H - 4, sx + (int) (sw * t), cy + SET_H - 2, accent);
			regions.add(new Region(x, cy, PANEL_W, SET_H, Kind.NUM, cat, m, s));
		} else if (s instanceof ModeSetting ms) {
			ctx.drawText(textRenderer, s.name, x + 9, cy + 4, textColor, false);
			String v = ms.value();
			ctx.drawText(textRenderer, v, x + PANEL_W - 7 - textRenderer.getWidth(v), cy + 4, accent, false);
			regions.add(new Region(x, cy, PANEL_W, SET_H, Kind.MODE, cat, m, s));
		}
	}

	// ------------------------------------------------------------ input

	private void updateSlider(double mx) {
		if (dragSlider == null) return;
		double t = Math.max(0, Math.min(1, (mx - sliderX) / (double) sliderW));
		dragSlider.set(dragSlider.min + t * (dragSlider.max - dragSlider.min));
	}

	@Override
	public boolean mouseClicked(Click click, boolean doubled) {
		double mx = click.x(), my = click.y();
		int btn = click.button();
		for (int i = regions.size() - 1; i >= 0; i--) {
			Region r = regions.get(i);
			if (!r.contains(mx, my)) continue;
			switch (r.kind) {
				case HEADER -> {
					if (btn == 0) {
						int[] p = pos(r.cat);
						dragPanel = r.cat;
						dragOffX = (int) mx - p[0];
						dragOffY = (int) my - p[1];
					} else if (btn == 1) {
						COLLAPSED.put(r.cat, !COLLAPSED.getOrDefault(r.cat, false));
					}
				}
				case MODULE -> {
					if (btn == 0) r.module.toggle();
					else if (!r.module.settings.isEmpty()) r.module.expanded = !r.module.expanded;
				}
				case BOOL -> {
					if (btn == 0) ((BoolSetting) r.setting).toggle();
				}
				case MODE -> ((ModeSetting) r.setting).cycle(btn == 1 ? -1 : 1);
				case NUM -> {
					if (btn == 0) {
						dragSlider = (NumberSetting) r.setting;
						sliderX = r.x + 9;
						sliderW = PANEL_W - 18;
						updateSlider(mx);
					}
				}
			}
			return true;
		}
		return super.mouseClicked(click, doubled);
	}

	@Override
	public boolean mouseDragged(Click click, double offsetX, double offsetY) {
		if (dragPanel != null) {
			int[] p = pos(dragPanel);
			p[0] = Math.max(0, Math.min(width - 30, (int) click.x() - dragOffX));
			p[1] = Math.max(0, Math.min(height - HEADER_H, (int) click.y() - dragOffY));
			return true;
		}
		if (dragSlider != null) {
			updateSlider(click.x());
			return true;
		}
		return super.mouseDragged(click, offsetX, offsetY);
	}

	@Override
	public boolean mouseReleased(Click click) {
		dragPanel = null;
		dragSlider = null;
		return super.mouseReleased(click);
	}
}
