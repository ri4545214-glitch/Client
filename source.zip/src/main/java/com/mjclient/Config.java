package com.mjclient;

import com.mjclient.gui.ClickGuiScreen;
import com.mjclient.module.Category;
import com.mjclient.module.Module;
import com.mjclient.setting.Setting;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;

/** Saves module states, settings and panel positions to config/mjclient.properties */
public final class Config {
	private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("mjclient.properties");

	private Config() {
	}

	private static String key(Module m, String suffix) {
		return "module." + m.name.replace(' ', '_') + "." + suffix.replace(' ', '_');
	}

	public static void load() {
		if (!Files.exists(FILE)) return;
		Properties props = new Properties();
		try (Reader r = Files.newBufferedReader(FILE)) {
			props.load(r);
		} catch (IOException e) {
			return;
		}
		for (Module m : ModuleManager.MODULES) {
			String en = props.getProperty(key(m, "enabled"));
			if (en != null && m.toggleable) m.enabled = Boolean.parseBoolean(en);
			m.anim = m.enabled ? 1 : 0;
			for (Setting s : m.settings) {
				String v = props.getProperty(key(m, s.name));
				if (v != null) s.deserialize(v);
			}
		}
		for (Category c : Category.values()) {
			try {
				String x = props.getProperty("panel." + c.name() + ".x");
				String y = props.getProperty("panel." + c.name() + ".y");
				if (x != null && y != null) {
					ClickGuiScreen.POS.put(c, new int[]{Integer.parseInt(x), Integer.parseInt(y)});
				}
			} catch (NumberFormatException ignored) {
			}
		}
	}

	public static void save() {
		Properties props = new Properties();
		for (Module m : ModuleManager.MODULES) {
			props.setProperty(key(m, "enabled"), String.valueOf(m.enabled));
			for (Setting s : m.settings) {
				props.setProperty(key(m, s.name), s.serialize());
			}
		}
		for (var e : ClickGuiScreen.POS.entrySet()) {
			props.setProperty("panel." + e.getKey().name() + ".x", String.valueOf(e.getValue()[0]));
			props.setProperty("panel." + e.getKey().name() + ".y", String.valueOf(e.getValue()[1]));
		}
		try (Writer w = Files.newBufferedWriter(FILE)) {
			props.store(w, "MJ Client config");
		} catch (IOException ignored) {
		}
	}
}
