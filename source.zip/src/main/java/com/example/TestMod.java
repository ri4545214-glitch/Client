package com.example;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.player.PlayerBlockBreakEvents;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;

public class TestMod implements ModInitializer {
	public static final String MOD_ID = "test-mod";
	public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

	// Add or remove items here to change what can drop
	private static final List<Item> DROPS = List.of(
		Items.DIAMOND,
		Items.GOLD_INGOT,
		Items.IRON_INGOT,
		Items.EMERALD,
		Items.APPLE,
		Items.GOLDEN_APPLE,
		Items.ARROW,
		Items.COOKED_BEEF,
		Items.TNT,
		Items.ENDER_PEARL,
		Items.Bamboo
	);

	@Override
	public void onInitialize() {
		PlayerBlockBreakEvents.AFTER.register((world, player, pos, state, blockEntity) -> {
			if (!(world instanceof ServerLevel serverLevel)) return;
			if (player.isCreative()) return;
			if (!state.is(Blocks.GRASS_BLOCK)) return;

			Item item = DROPS.get(serverLevel.getRandom().nextInt(DROPS.size()));
			Block.popResource(serverLevel, pos, new ItemStack(item));
		});

		LOGGER.info("Random grass drops loaded!");
	}

	public static ResourceLocation id(String path) {
		return ResourceLocation.fromNamespaceAndPath(MOD_ID, path);
	}
}