package com.goku;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import java.util.ArrayList;
import java.util.List;

public abstract class Module {
    public final String name;
    public boolean enabled, open;
    public boolean toggleable = true;
    /** Short one-line description shown in the GUI. */
    public String desc = "";
    /** Keybind: GLFW key code, 1000+button for extra mouse buttons, -1 = unbound. keyHold = active only while held. */
    public int key = -1;
    public boolean keyHold, keyWas, heldOn;
    public float anim, openAnim; // GUI animation state
    public final List<Setting> settings = new ArrayList<>();
    protected final MinecraftClient mc = MinecraftClient.getInstance();

    protected Module(String name) { this.name = name; }
    protected Setting add(Setting s) { settings.add(s); return s; }

    public void toggle() { setEnabled(!enabled); }
    public void setEnabled(boolean e) {
        if (e == enabled) return;
        enabled = e;
        if (e) onEnable(); else onDisable();
        com.goku.util.Toasts.push(this);
    }

    public void onEnable() {}
    public void onDisable() {}
    public void onPreTick() {}
    public void onTick() {}
    public void onRender(DrawContext ctx, float td) {}
}
