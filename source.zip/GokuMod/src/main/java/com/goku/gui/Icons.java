package com.goku.gui;

import net.minecraft.client.gui.DrawContext;

import java.util.Map;

/** Tiny 7x7 pixel icons for the sidebar (no textures needed). */
final class Icons {
    private static final Map<String, String[]> MAP = Map.of(
            "Active", new String[]{"...###.", "..###..", ".###...", "#######", "...###.", "..##...", ".##...."},
            "Base", new String[]{"...#...", "..###..", ".#####.", "#######", ".##.##.", ".##.##.", ".##.##."},
            "Combat", new String[]{"..###..", ".#...#.", "#..#..#", "#.###.#", "#..#..#", ".#...#.", "..###.."},
            "Movement", new String[]{"...#...", "....#..", ".....#.", "#######", ".....#.", "....#..", "...#..."},
            "Automation", new String[]{"..#.#..", ".#####.", "##...##", ".#...#.", "##...##", ".#####.", "..#.#.."},
            "Visuals", new String[]{".......", "..###..", ".#...#.", "#..#..#", ".#...#.", "..###..", "......."},
            "Mods", new String[]{"###.###", "###.###", "###.###", ".......", "###.###", "###.###", "###.###"},
            "Practice Bot", new String[]{"...#...", ".#####.", "##.#.##", "#######", "#.###.#", ".#####.", ".#...#."},
            "Settings", new String[]{"#######", "..##...", ".......", "#######", "....##.", ".......", "#######"}
    );
    private static final String[] SEARCH = {".###...", "#...#..", "#...#..", "#...#..", ".###...", ".....#.", "......#"};

    static void draw(DrawContext c, String name, int x, int y, int scale, int col) {
        paint(c, MAP.getOrDefault(name, MAP.get("Mods")), x, y, scale, col);
    }

    static void search(DrawContext c, int x, int y, int col) { paint(c, SEARCH, x, y, 1, col); }

    private static void paint(DrawContext c, String[] rows, int x, int y, int s, int col) {
        for (int r = 0; r < rows.length; r++)
            for (int k = 0; k < rows[r].length(); k++)
                if (rows[r].charAt(k) == '#') c.fill(x + k * s, y + r * s, x + k * s + s, y + r * s + s, col);
    }
}
