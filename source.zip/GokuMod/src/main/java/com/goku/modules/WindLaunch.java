package com.goku.modules;

import com.goku.Module;
import com.goku.Modules;
import com.goku.Setting;
import com.goku.util.Inv;
import com.goku.util.Targets;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;

import java.util.List;

/** Wind Launch: throws a wind charge at your feet to shoot up above a nearby target, then equips the mace for the smash (pairs with Auto Mace). */
public class WindLaunch extends Module {
    final Setting players = add(Setting.bool("Players", true));
    final Setting mobs = add(Setting.bool("Mobs", false));
    final Setting range = add(Setting.num("Target Within", 9, 3, 20, 1));
    final Setting needMace = add(Setting.bool("Only With A Mace", true));
    final Setting equipMace = add(Setting.bool("Equip Mace After", true));
    final Setting swapBack = add(Setting.bool("Else Swap Back", true));
    final Setting cooldown = add(Setting.num("Cooldown (ticks)", 30, 10, 100, 5));
    final Setting walls = add(Setting.bool("Through Walls", false));
    int cd;

    public WindLaunch() { super("Wind Launch"); }

    @Override public void onTick() {
        if (mc.currentScreen != null || Modules.FREECAM.enabled || !mc.player.isAlive()) return;
        if (cd > 0) { cd--; return; }
        if (!mc.player.isOnGround()) return;
        List<LivingEntity> t = Targets.find(mc, LegitMode.reach(range.v + 0.0), players.b, mobs.b, LegitMode.walls(walls.b));
        if (t.isEmpty()) return;
        int wind = Inv.hotbar(s -> s.isOf(Items.WIND_CHARGE));
        if (wind < 0) return;
        if (needMace.b && Inv.hotbar(s -> s.isOf(Items.MACE)) < 0) return;
        int prev = Inv.selected();
        float yaw = mc.player.getYaw(), pitch = mc.player.getPitch();
        Inv.select(wind);
        mc.player.setPitch(90f);
        mc.interactionManager.interactItem(mc.player, Hand.MAIN_HAND);
        mc.player.swingHand(Hand.MAIN_HAND);
        mc.player.setYaw(yaw); mc.player.setPitch(pitch);
        int m = equipMace.b ? AutoMace.bestMace(t.get(0), true, 8) : -1;
        if (m >= 0) Inv.select(m);
        else if (swapBack.b) Inv.select(prev);
        cd = LegitMode.delay(cooldown.i());
    }
}
