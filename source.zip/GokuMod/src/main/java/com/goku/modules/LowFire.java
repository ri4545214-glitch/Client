package com.goku.modules;

import com.goku.Module;
import com.goku.Setting;

/** Hides the fire overlay on your screen while you burn (client-side only; you still take fire damage). */
public class LowFire extends Module {
    final Setting hide = add(Setting.bool("Hide Fire Overlay", true));

    public LowFire() { super("Low Fire"); }

    @Override public void onTick() {
        if (!hide.b || mc.player == null) return;
        if (mc.player.isOnFire()) { mc.player.setFireTicks(0); mc.player.setOnFire(false); }
    }
}
