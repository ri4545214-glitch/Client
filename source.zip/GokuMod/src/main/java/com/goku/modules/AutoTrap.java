package com.goku.modules;

import com.goku.Module;
import com.goku.Modules;
import com.goku.Setting;
import com.goku.util.Inv;
import com.goku.util.Place;
import com.goku.util.Targets;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.math.BlockPos;

/** Boxes in the nearest player with obsidian. */
public class AutoTrap extends Module {
    final Setting range = add(Setting.num("Target Range", 5, 2, 8, 0.5));
    final Setting reach = add(Setting.num("Place Range", 4.5, 2, 5, 0.5));
    final Setting obsOnly = add(Setting.bool("Obsidian Only", true));
    final Setting perTick = add(Setting.num("Blocks Per Tick", 2, 1, 4, 1));
    final Setting delay = add(Setting.num("Delay (ticks)", 1, 0, 10, 1));
    final Setting base = add(Setting.bool("Floor Block", false));
    final Setting head = add(Setting.bool("Head Level Sides", true));
    final Setting top = add(Setting.bool("Cap Above Head", true));
    final Setting swapBack = add(Setting.bool("Swap Back", true));
    int cd;

    public AutoTrap() { super("Auto Trap"); }

    @Override public void onTick() {
        if (mc.currentScreen != null || Modules.FREECAM.enabled) return;
        if (cd > 0) { cd--; return; }
        var list = Targets.find(mc, range.v, true, false, true);
        if (list.isEmpty()) return;
        LivingEntity t = list.get(0);
        int slot = Place.blockSlot(obsOnly.b);
        if (slot < 0) return;
        int prev = Inv.selected(), n = 0;
        Inv.select(slot);
        for (BlockPos p : Place.shell(t.getBlockPos(), base.b, head.b, top.b)) {
            if (n >= com.goku.modules.LegitMode.perTick(perTick.i())) break;
            if (Place.place(p, reach.v)) n++;
        }
        if (swapBack.b) Inv.select(prev);
        if (n > 0) cd = LegitMode.delay(delay.i());
    }
}
