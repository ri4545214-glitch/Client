package com.goku.modules;

import com.goku.Module;
import com.goku.Modules;
import com.goku.Setting;
import com.goku.util.Draw;
import com.goku.util.Fx;
import com.goku.util.Hud;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.Entity;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.mob.Monster;
import net.minecraft.entity.passive.AnimalEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Vec3d;

/** Mini radar: a top-down view of nearby players / mobs that rotates with your camera. */
public class Radar extends Module {
    final Setting corner = add(Setting.mode("Corner", 0, Hud.CORNERS));
    final Setting offX = add(Setting.num("Offset X", 8, 0, 400, 2));
    final Setting offY = add(Setting.num("Offset Y", 8, 0, 400, 2));
    final Setting size = add(Setting.num("Size", 96, 56, 220, 4));
    final Setting range = add(Setting.num("Range", 60, 10, 200, 5));
    final Setting rotate = add(Setting.bool("Rotate With View", true));
    final Setting players = add(Setting.bool("Players", true));
    final Setting hostile = add(Setting.bool("Hostile Mobs", false));
    final Setting animals = add(Setting.bool("Animals", false));
    final Setting items = add(Setting.bool("Dropped Items", false));
    final Setting sweep = add(Setting.bool("Sweep Animation", true));
    final Setting dotSize = add(Setting.num("Dot Size", 3, 2, 6, 1));
    final Setting bgAlpha = add(Setting.num("Background Alpha", 150, 40, 255, 5));

    public Radar() { super("Radar"); desc = "Top-down mini radar of nearby entities"; }

    @Override public void onRender(DrawContext c, float td) {
        Entity cam = mc.getCameraEntity();
        if (cam == null) return;
        int sz = size.i(), half = sz / 2;
        int[] p = Hud.pos(corner.idx, offX.i(), offY.i(), sz, sz);
        int x1 = p[0], y1 = p[1], x2 = x1 + sz, y2 = y1 + sz, cx = x1 + half, cy = y1 + half;
        int acc = Modules.accent(), acc2 = Modules.accent2();

        Fx.glow(c, x1, y1, x2, y2, acc, 3, 50);
        Fx.round(c, x1, y1, x2, y2, bgAlpha.i() << 24 | 0x0A0A12);
        c.fillGradient(x1 + 2, y1, x2 - 2, y1 + 1, acc, acc2);
        c.fill(x1 + 2, cy, x2 - 2, cy + 1, Fx.a(acc, 0x28));
        c.fill(cx, y1 + 2, cx + 1, y2 - 2, Fx.a(acc, 0x28));
        Draw.outline(c, cx - half / 2, cy - half / 2, cx + half / 2 + 1, cy + half / 2 + 1, Fx.a(acc, 0x22));

        double yaw = Math.toRadians(cam.getYaw(td));
        double fwx = -Math.sin(yaw), fwz = Math.cos(yaw), rx = -Math.cos(yaw), rz = -Math.sin(yaw);
        Vec3d me = cam.getLerpedPos(td);

        c.enableScissor(x1 + 1, y1 + 1, x2 - 1, y2 - 1);
        if (sweep.b) {
            double a = Fx.time() * 1.6;
            for (int i = 0; i < 6; i++) {
                double aa = a - i * 0.07;
                Draw.line(c, cx, cy, cx + Math.cos(aa) * half * 1.45, cy + Math.sin(aa) * half * 1.45, 1, Fx.a(acc, 0x50 - i * 12));
            }
        }
        int ds = dotSize.i();
        for (Entity e : mc.world.getEntities()) {
            if (e == cam || e == mc.player) continue;
            int col;
            if (players.b && e instanceof PlayerEntity) col = acc | 0xFF000000;
            else if (hostile.b && e instanceof Monster) col = 0xFFFF4455;
            else if (animals.b && e instanceof AnimalEntity) col = 0xFF55EE77;
            else if (items.b && e instanceof ItemEntity) col = 0xFFFFDD44;
            else continue;
            Vec3d lp = e.getLerpedPos(td);
            double dx = lp.x - me.x, dz = lp.z - me.z;
            double px, py;
            if (rotate.b) { px = (dx * rx + dz * rz) / range.v * half; py = -(dx * fwx + dz * fwz) / range.v * half; }
            else { px = dx / range.v * half; py = dz / range.v * half; }
            double len = Math.hypot(px, py), lim = half - ds - 1;
            boolean edge = len > lim;
            if (edge) { px = px / len * lim; py = py / len * lim; }
            int dxp = (int) Math.round(cx + px), dyp = (int) Math.round(cy + py);
            int a = edge ? 0x90 : 0xFF;
            c.fill(dxp - ds / 2 - 1, dyp - ds / 2 - 1, dxp + ds / 2 + 2, dyp + ds / 2 + 2, Fx.a(col, 0x38));
            c.fill(dxp - ds / 2, dyp - ds / 2, dxp - ds / 2 + ds, dyp - ds / 2 + ds, Fx.a(col, a));
        }
        c.disableScissor();
        // you
        double sa = rotate.b ? -Math.PI / 2 : Math.atan2(fwz, fwx);
        Fx.arrow(c, cx, cy, sa, 8, 0xFFFFFFFF);
        if (rotate.b) {
            String n = "N";
            int nx = (int) (cx + Math.sin(yaw) * (half - 8)), ny = (int) (cy + Math.cos(yaw) * (half - 8));
            Draw.text(c, n, nx, ny - 4, 0xFFFF6677);
        }
    }
}
