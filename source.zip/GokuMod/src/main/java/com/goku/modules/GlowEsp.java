package com.goku.modules;

import com.goku.Module;
import com.goku.Modules;
import com.goku.Setting;
import com.goku.util.Draw;
import com.goku.util.Fx;
import com.goku.util.Projector;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.Entity;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.mob.Monster;
import net.minecraft.entity.passive.AnimalEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

/** Glow ESP: soft neon halo around entities (screen space, visible through walls). */
public class GlowEsp extends Module {
    final Setting players = add(Setting.bool("Players", true));
    final Setting hostile = add(Setting.bool("Hostile Mobs", false));
    final Setting animals = add(Setting.bool("Animals", false));
    final Setting items = add(Setting.bool("Dropped Items", false));
    final Setting style = add(Setting.mode("Style", 0, "Soft Glow", "Neon Outline", "Pulse"));
    final Setting layers = add(Setting.num("Glow Size", 6, 2, 12, 1));
    final Setting intensity = add(Setting.num("Intensity", 70, 10, 100, 5));
    final Setting fill = add(Setting.bool("Inner Glow", true));
    final Setting colorMode = add(Setting.mode("Color", 0, "Health", "GUI Accent", "Rainbow", "Custom"));
    final Setting custom = add(Setting.mode("Custom Color", 4, Draw.NAMES));
    final Setting range = add(Setting.num("Range (0=inf)", 0, 0, 500, 10));

    public GlowEsp() { super("Glow ESP"); desc = "Neon halo around players and mobs"; }

    @Override public void onRender(DrawContext c, float td) {
        if (!Projector.ok) return;
        double t = Fx.time();
        int idx = 0;
        for (Entity e : mc.world.getEntities()) {
            if (e == mc.getCameraEntity()) continue;
            boolean ok = (players.b && e instanceof PlayerEntity)
                    || (hostile.b && e instanceof Monster)
                    || (animals.b && e instanceof AnimalEntity)
                    || (items.b && e instanceof ItemEntity);
            if (!ok) continue;
            if (e instanceof LivingEntity le && !le.isAlive()) continue;
            Vec3d lp = e.getLerpedPos(td);
            double d = lp.distanceTo(Projector.cam);
            if (range.v > 0 && d > range.v) continue;
            Box b = e.getBoundingBox().offset(lp.subtract(e.getEntityPos()));
            int[] r = Projector.box(b);
            if (r == null) continue;
            int col;
            switch (colorMode.idx) {
                case 0 -> {
                    float f = e instanceof LivingEntity le2 ? Math.max(0f, Math.min(1f, le2.getHealth() / Math.max(1f, le2.getMaxHealth()))) : 1f;
                    col = Fx.healthColor(f);
                }
                case 1 -> col = Modules.accent();
                case 2 -> col = 0xFF000000 | Draw.hsv((float) (t * 0.15 + idx * 0.13));
                default -> col = Draw.COLORS[custom.idx];
            }
            idx++;
            int maxA = (int) (intensity.v * 2.0);
            if (style.idx == 2) maxA = (int) (maxA * (0.55 + 0.45 * Math.sin(t * 4 + idx)));
            if (fill.b) c.fillGradient(r[0], r[1], r[2], r[3], Fx.a(col, 0x06), Fx.a(col, (int) (0x44 * intensity.v / 100.0)));
            Fx.glow(c, r[0], r[1], r[2], r[3], col, layers.i(), Math.min(255, maxA));
            Draw.outline(c, r[0], r[1], r[2], r[3], style.idx == 1 ? 0xFFFFFFFF : Fx.a(col, 0xFF));
        }
    }
}
