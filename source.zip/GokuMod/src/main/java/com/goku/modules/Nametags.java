package com.goku.modules;

import com.goku.Module;
import com.goku.Modules;
import com.goku.Setting;
import com.goku.util.Draw;
import com.goku.util.Fx;
import com.goku.util.Projector;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.util.math.Vec3d;

import java.util.Locale;

/** Clean player nametags: name, health number, health + armour bars, held item, distance, a pointer pin and a soft glow. */
public class Nametags extends Module {
    final Setting name = add(Setting.bool("Name", true));
    final Setting hpText = add(Setting.bool("Health Number", true));
    final Setting hpBar = add(Setting.bool("Health Bar", true));
    final Setting armor = add(Setting.bool("Armor Bar", true));
    final Setting item = add(Setting.bool("Held Item", true));
    final Setting dist = add(Setting.bool("Distance", true));
    final Setting pin = add(Setting.bool("Pin Arrow", true));
    final Setting glow = add(Setting.bool("Glow", true));
    final Setting bg = add(Setting.mode("Background", 0, "Glass", "Solid", "None"));
    final Setting colorMode = add(Setting.mode("Color", 0, "Health", "GUI Accent", "White", "Custom"));
    final Setting custom = add(Setting.mode("Custom Color", 4, Draw.NAMES));
    final Setting scale = add(Setting.num("Scale", 1.0, 0.5, 2.5, 0.1));
    final Setting distScale = add(Setting.bool("Scale With Distance", true));
    final Setting self = add(Setting.bool("Show Self (Freecam)", true));
    final Setting range = add(Setting.num("Range (0=inf)", 0, 0, 500, 10));

    public Nametags() { super("Nametags"); desc = "Name, health and armor above players"; }

    @Override public void onRender(DrawContext c, float td) {
        if (!Projector.ok) return;
        for (Entity e : mc.world.getEntities()) {
            if (!(e instanceof PlayerEntity p) || p == mc.getCameraEntity() || !p.isAlive()) continue;
            if (p == mc.player && !self.b) continue;
            Vec3d lp = p.getLerpedPos(td);
            double d = lp.distanceTo(Projector.cam);
            if (range.v > 0 && d > range.v) continue;
            double[] s = Projector.to(new Vec3d(lp.x, lp.y + p.getHeight() + 0.4, lp.z));
            if (s == null || s[0] < -90 || s[0] > Projector.W + 90 || s[1] < -50 || s[1] > Projector.H + 50) continue;
            tag(c, p, s[0], s[1], d);
        }
    }

    void tag(DrawContext c, PlayerEntity p, double sx, double sy, double d) {
        TextRenderer tr = mc.textRenderer;
        float hp = p.getHealth(), max = Math.max(1f, p.getMaxHealth()), abs = p.getAbsorptionAmount();
        float f = Math.max(0f, Math.min(1f, hp / max));
        int col = switch (colorMode.idx) {
            case 0 -> Fx.healthColor(f);
            case 1 -> Modules.accent();
            case 2 -> 0xFFFFFFFF;
            default -> Draw.COLORS[custom.idx];
        };
        String nm = name.b ? p.getName().getString() : "";
        String hs = hpText.b ? String.format(Locale.ROOT, "%.1f", hp) + (abs > 0 ? " +" + (int) abs : "") : "";
        String ds = dist.b ? (int) d + "m" : "";
        int tw = 0;
        if (!nm.isEmpty()) tw += tr.getWidth(nm);
        if (!hs.isEmpty()) tw += (tw > 0 ? 5 : 0) + tr.getWidth(hs);
        if (!ds.isEmpty()) tw += (tw > 0 ? 5 : 0) + tr.getWidth(ds);
        ItemStack hand = p.getMainHandStack();
        String it = item.b && !hand.isEmpty() ? hand.getName().getString() : "";
        if (it.length() > 26) it = it.substring(0, 25) + "..";
        int armorVal = p.getArmor();
        boolean showArmor = armor.b && armorVal > 0;
        int w = Math.max(Math.max(tw, tr.getWidth(it)), 54) + 12;
        int h = (tw > 0 ? 12 : 4) + (hpBar.b ? 6 : 0) + (showArmor ? 4 : 0) + (it.isEmpty() ? 0 : 11) + 2;

        float sc = (float) scale.v;
        if (distScale.b) sc *= (float) Math.max(0.55, Math.min(1.25, 1.35 - d / 60.0));
        var m = c.getMatrices();
        m.pushMatrix();
        m.translate((float) sx, (float) sy);
        m.scale(sc, sc);

        int bot = -7, top = bot - h, x1 = -w / 2, x2 = x1 + w;
        if (glow.b) Fx.glow(c, x1, top, x2, bot, col, 3, 70);
        if (bg.idx == 0) { Fx.round(c, x1, top, x2, bot, 0xB00C0C14); c.fill(x1 + 2, top, x2 - 2, top + 1, Fx.a(col, 0xFF)); }
        else if (bg.idx == 1) { Fx.round(c, x1, top, x2, bot, 0xF0101018); c.fill(x1 + 2, top, x2 - 2, top + 1, Fx.a(col, 0xFF)); }

        int y = top + 3;
        if (tw > 0) {
            int x = -tw / 2;
            if (!nm.isEmpty()) { c.drawText(tr, nm, x, y, 0xFFFFFFFF, true); x += tr.getWidth(nm) + 5; }
            if (!hs.isEmpty()) { c.drawText(tr, hs, x, y, Fx.healthColor(f), true); x += tr.getWidth(hs) + 5; }
            if (!ds.isEmpty()) c.drawText(tr, ds, x, y, 0xFFA0A0B8, true);
            y += 12;
        } else y += 1;
        if (hpBar.b) {
            int bx1 = x1 + 4, bx2 = x2 - 4, bw = bx2 - bx1;
            c.fill(bx1, y, bx2, y + 3, 0xA0202030);
            int fw = (int) (bw * f);
            if (fw > 0) c.fillGradient(bx1, y, bx1 + fw, y + 3, Fx.mix(Fx.healthColor(f), 0xFFFFFFFF, 0.25f), Fx.healthColor(f));
            if (abs > 0) c.fill(bx1, y + 3, bx1 + (int) (bw * Math.min(1f, abs / max)), y + 4, 0xFFFFC83C);
            y += 6;
        }
        if (showArmor) {
            int bx1 = x1 + 4, bx2 = x2 - 4;
            c.fill(bx1, y, bx2, y + 2, 0xA0202030);
            c.fill(bx1, y, bx1 + (int) ((bx2 - bx1) * Math.min(1f, armorVal / 20f)), y + 2, 0xFF5AA0FF);
            y += 4;
        }
        if (!it.isEmpty()) Draw.text(c, it, 0, y + 1, 0xFFB8B8D0);
        if (pin.b) Fx.arrow(c, 0, bot + 4, Math.PI / 2, 8, col);
        m.popMatrix();
    }
}
