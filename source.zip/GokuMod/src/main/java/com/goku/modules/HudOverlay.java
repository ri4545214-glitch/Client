package com.goku.modules;

import com.goku.Module;
import com.goku.Modules;
import com.goku.Setting;
import com.goku.util.Fx;
import com.goku.util.Hud;
import com.goku.util.Projector;
import com.goku.util.Toasts;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/** HUD Overlay: watermark pill, sorted list of enabled modules and toggle notifications. */
public class HudOverlay extends Module {
    final Setting watermark = add(Setting.bool("Watermark", true));
    final Setting wmFps = add(Setting.bool("Watermark: FPS", true));
    final Setting wmName = add(Setting.bool("Watermark: Player Name", true));
    final Setting list = add(Setting.bool("Module List", true));
    final Setting corner = add(Setting.mode("List Corner", 1, Hud.CORNERS));
    final Setting offX = add(Setting.num("List Offset X", 4, 0, 400, 2));
    final Setting offY = add(Setting.num("List Offset Y", 4, 0, 400, 2));
    final Setting bar = add(Setting.mode("Side Bar", 0, "Outer Edge", "None"));
    final Setting bg = add(Setting.num("List Background", 120, 0, 255, 5));
    final Setting colors = add(Setting.mode("List Colors", 0, "Gradient", "GUI Accent", "White"));
    public final Setting toasts = add(Setting.bool("Toggle Notifications", true));

    public HudOverlay() { super("HUD Overlay"); desc = "Watermark, module list and notifications"; }

    @Override public void onRender(DrawContext c, float td) {
        TextRenderer tr = mc.textRenderer;
        int acc = Modules.accent(), acc2 = Modules.accent2();
        if (watermark.b) {
            StringBuilder sb = new StringBuilder(" v" + Fx.version());
            if (wmFps.b) sb.append("  |  ").append(mc.getCurrentFps()).append(" fps");
            if (wmName.b && mc.player != null) sb.append("  |  ").append(mc.player.getName().getString());
            String rest = sb.toString();
            int w = tr.getWidth("GOKU") + tr.getWidth(rest) + 16;
            int x = Projector.W / 2 - w / 2, y = 4;
            Fx.glow(c, x, y, x + w, y + 15, acc, 3, 40);
            Fx.round(c, x, y, x + w, y + 15, 0xC00C0C14);
            c.fillGradient(x + 2, y + 14, x + w - 2, y + 15, acc, acc2);
            int tx = x + 8;
            String g = "GOKU";
            for (int i = 0; i < g.length(); i++) {
                String ch = String.valueOf(g.charAt(i));
                c.drawText(tr, ch, tx, y + 4, Fx.mix(acc, acc2, i / 3f), true);
                tx += tr.getWidth(ch);
            }
            c.drawText(tr, rest, tx, y + 4, 0xFFB8B8D0, false);
        }
        if (list.b) {
            List<Module> on = new ArrayList<>();
            for (Module m : Modules.ALL) if (m.enabled && m.toggleable && m != this) on.add(m);
            if (!on.isEmpty()) {
                on.sort(Comparator.comparingInt((Module m) -> -tr.getWidth(m.name)));
                int rowH = 11, maxW = tr.getWidth(on.get(0).name) + 10;
                int[] p = Hud.pos(corner.idx, offX.i(), offY.i(), maxW, on.size() * rowH);
                boolean right = (corner.idx & 1) != 0;
                for (int i = 0; i < on.size(); i++) {
                    Module m = on.get(i);
                    int rw = tr.getWidth(m.name) + 10;
                    int x = right ? p[0] + maxW - rw : p[0], y = p[1] + i * rowH;
                    int col = switch (colors.idx) {
                        case 0 -> Fx.mix(acc, acc2, on.size() <= 1 ? 0f : i / (float) (on.size() - 1));
                        case 1 -> acc;
                        default -> 0xFFFFFFFF;
                    };
                    if (bg.i() > 0) c.fill(x, y, x + rw, y + rowH, bg.i() << 24);
                    if (bar.idx == 0) c.fill(right ? x + rw - 2 : x, y, right ? x + rw : x + 2, y + rowH, col);
                    c.drawText(tr, m.name, x + (right ? 4 : 5), y + 2, col, true);
                }
            }
        }
        Toasts.render(c);
    }
}
