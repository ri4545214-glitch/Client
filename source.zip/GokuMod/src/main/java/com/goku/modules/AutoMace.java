package com.goku.modules;

import com.goku.Module;
import com.goku.Modules;
import com.goku.Setting;
import com.goku.util.Esp;
import com.goku.util.Inv;
import com.goku.util.Targets;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.Enchantments;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.registry.tag.ItemTags;
import net.minecraft.util.Hand;

import java.util.List;

/**
 * Auto Mace Hit: while you fall onto a target it swaps to the mace and smashes at the right moment (full charge, enough fall height).
 * Optionally breaks shields with an axe first, and picks the Breach or Density mace by the target's armor.
 */
public class AutoMace extends Module {
    final Setting players = add(Setting.bool("Players", true));
    final Setting mobs = add(Setting.bool("Mobs", false));
    final Setting range = add(Setting.num("Range", 3.5, 2, 6, 0.1));
    final Setting minFall = add(Setting.num("Min Fall Height", 2.0, 1.5, 20, 0.5));
    final Setting autoSwap = add(Setting.bool("Auto Swap To Mace", true));
    final Setting swapBack = add(Setting.bool("Swap Back After", true));
    final Setting smart = add(Setting.bool("Smart Mace (Breach/Density)", true));
    final Setting armorLimit = add(Setting.num("Breach If Armor >=", 8, 1, 20, 1));
    final Setting shield = add(Setting.bool("Break Shields With Axe", true));
    final Setting charge = add(Setting.num("Min Charge %", 90, 40, 100, 5));
    final Setting delay = add(Setting.num("Delay (ticks)", 4, 1, 20, 1));
    final Setting rotate = add(Setting.bool("Rotate", true));
    final Setting walls = add(Setting.bool("Through Walls", false));
    final Setting hud = add(Setting.bool("Smash Damage HUD", true));

    int cd, restore = -1, idle;

    public AutoMace() { super("Auto Mace"); }

    // ---- shared helpers (also used by WindLaunch / MaceSwap)
    static int lvl(ItemStack s, RegistryKey<Enchantment> k) {
        var comp = s.getEnchantments();
        for (RegistryEntry<Enchantment> en : comp.getEnchantments()) if (en.matchesKey(k)) return comp.getLevel(en);
        return 0;
    }

    /** Hotbar slot of the best mace for this target (Breach vs armored targets, Density otherwise), or -1. */
    static int bestMace(LivingEntity target, boolean smart, int armorLimit) {
        var inv = net.minecraft.client.MinecraftClient.getInstance().player.getInventory();
        int best = -1; double bestScore = -1;
        boolean armored = target != null && target.getArmor() >= armorLimit;
        for (int i = 0; i < 9; i++) {
            ItemStack st = inv.getStack(i);
            if (!st.isOf(Items.MACE)) continue;
            double sc = 1;
            if (smart) sc += armored ? lvl(st, Enchantments.BREACH) * 10 + lvl(st, Enchantments.DENSITY) : lvl(st, Enchantments.DENSITY) * 10 + lvl(st, Enchantments.BREACH);
            if (sc > bestScore) { bestScore = sc; best = i; }
        }
        return best;
    }

    static boolean falling(PlayerEntity p) {
        return !p.isOnGround() && p.getVelocity().y < -0.1 && !p.isClimbing() && !p.isTouchingWater() && !p.isInLava();
    }

    /** Expected smash damage for a fall (vanilla bonus: 4/block for 3, 2/block for 5, 1/block after, +0.5/block per Density level). */
    static double smash(double f, int density) {
        double bonus = Math.min(f, 3) * 4 + Math.max(0, Math.min(f - 3, 5)) * 2 + Math.max(0, f - 8) + f * 0.5 * density;
        return 6 + bonus;
    }

    int axeSlot() { return Inv.hotbar(s -> s.isIn(ItemTags.AXES)); }

    boolean ready() { return mc.player.getAttackCooldownProgress(0.5f) * 100f >= charge.v; }

    /** Turn towards the target. Returns false while a human-like turn is still in progress. */
    boolean aim(LivingEntity e) {
        if (!rotate.b) return true;
        float[] r = Targets.rot(mc.player.getEyePos(), e.getEntityPos().add(0, e.getHeight() * 0.6, 0));
        if (LegitMode.human()) {
            float dy = Targets.wrap(r[0] - mc.player.getYaw()), dp = r[1] - mc.player.getPitch();
            float m = LegitMode.maxTurn(180f);
            mc.player.setYaw(mc.player.getYaw() + Math.max(-m, Math.min(m, dy)) + LegitMode.noise());
            mc.player.setPitch(Math.max(-90f, Math.min(90f, mc.player.getPitch() + Math.max(-m, Math.min(m, dp)) + LegitMode.noise())));
            return Math.abs(dy) <= 12f && Math.abs(dp) <= 12f;
        }
        mc.player.setYaw(r[0]); mc.player.setPitch(r[1]);
        return true;
    }

    void ensureMace(LivingEntity target) {
        int s = bestMace(target, smart.b, armorLimit.i());
        if (s < 0 || Inv.selected() == s) return;
        if (restore < 0) restore = Inv.selected();
        Inv.select(s);
    }

    void hit(LivingEntity e) {
        mc.interactionManager.attackEntity(mc.player, e);
        mc.player.swingHand(Hand.MAIN_HAND);
        cd = LegitMode.delay(delay.i());
    }

    @Override public void onDisable() { restore = -1; idle = 0; }

    @Override public void onTick() {
        if (mc.currentScreen != null || Modules.FREECAM.enabled || !mc.player.isAlive()) return;
        if (cd > 0) cd--;
        double reach = LegitMode.reach(range.v);
        List<LivingEntity> near = Targets.find(mc, reach + 3, players.b, mobs.b, LegitMode.walls(walls.b));
        LivingEntity tgt = null;
        for (LivingEntity e : near) if (mc.player.distanceTo(e) <= reach) { tgt = e; break; }
        boolean fall = falling(mc.player) && mc.player.fallDistance >= minFall.v;

        if (!near.isEmpty()) idle = 0;
        if (autoSwap.b && !near.isEmpty() && falling(mc.player) && mc.player.fallDistance >= minFall.v * 0.5) ensureMace(near.get(0));

        if (tgt != null && cd <= 0 && ready()) {
            if (shield.b && tgt.isBlocking()) {
                int ax = axeSlot();
                if (ax >= 0 && aim(tgt)) {
                    if (restore < 0 && Inv.selected() != ax) restore = Inv.selected();
                    Inv.select(ax);
                    hit(tgt);
                    return;
                }
            }
            if (fall && mc.player.getMainHandStack().isOf(Items.MACE) && aim(tgt)) hit(tgt);
        }

        if (restore >= 0 && (mc.player.isOnGround() || near.isEmpty()) && ++idle > 2) {
            if (swapBack.b) Inv.select(restore);
            restore = -1; idle = 0;
        }
    }

    @Override public void onRender(DrawContext c, float td) {
        if (!hud.b || mc.player == null) return;
        ItemStack held = mc.player.getMainHandStack();
        if (!held.isOf(Items.MACE)) return;
        double f = mc.player.isOnGround() ? 0 : mc.player.fallDistance;
        Esp.hud(c, String.format("Mace: fall %.1f blocks  |  smash ~%.0f HP", f, smash(f, lvl(held, Enchantments.DENSITY))), Modules.accent());
    }
}
