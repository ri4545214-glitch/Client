package com.goku.modules;

import com.goku.Module;
import com.goku.Modules;
import com.goku.Setting;
import com.goku.util.Draw;
import com.goku.util.Esp;
import com.goku.util.Projector;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.text.Text;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

/** Waypoints saved per server/dimension in config/gokumod/waypoints.json. Use the "> " buttons in the GUI to add/remove. */
public class Waypoints extends Module {
    public static class Wp { public String name, dim; public int x, y, z, color; }

    static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    static List<Wp> all;

    final Setting add = add(Setting.bool("> Add Here", false));
    final Setting removeNear = add(Setting.bool("> Remove Nearest", false));
    final Setting clear = add(Setting.bool("> Clear This Dimension", false));
    final Setting newColor = add(Setting.mode("New Waypoint Color", 4, Draw.NAMES));
    final Setting death = add(Setting.bool("Death Waypoint", true));
    final Setting box = add(Setting.bool("Marker Box", true));
    final Setting labels = add(Setting.bool("Names", true));
    final Setting showDist = add(Setting.bool("Distance", true));
    final Setting fade = add(Setting.bool("Distance Fade", true));
    final Setting tracers = add(Setting.bool("Tracers", false));
    final Setting origin = add(Setting.mode("Tracer From", 0, Esp.ORIGINS));
    final Setting maxDist = add(Setting.num("Max Distance (0=inf)", 0, 0, 5000, 50));
    final Setting hideNear = add(Setting.num("Hide Closer Than", 3, 0, 50, 1));

    private boolean wasDead;

    public Waypoints() { super("Waypoints"); }

    static Path file() { return FabricLoader.getInstance().getConfigDir().resolve("gokumod").resolve("waypoints.json"); }

    public static List<Wp> list() {
        if (all == null) {
            try {
                Path f = file();
                all = Files.exists(f) ? GSON.fromJson(Files.readString(f), new TypeToken<List<Wp>>() {}.getType()) : null;
            } catch (Exception e) { all = null; }
            if (all == null) all = new ArrayList<>();
        }
        return all;
    }

    public static void save() {
        try { Files.createDirectories(file().getParent()); Files.writeString(file(), GSON.toJson(list())); } catch (Exception ignored) {}
    }

    /** Key of the dimension/server the player is in now (matches Wp.dim), or "" outside a world. */
    public String currentDim() { return mc.world == null ? "" : dimKey(); }

    private String dimKey() {
        var si = mc.getCurrentServerEntry();
        return (si == null ? "singleplayer" : si.address) + "|" + mc.world.getRegistryKey().getValue();
    }

    private void msg(String s) { if (mc.player != null) mc.player.sendMessage(Text.literal("[Goku] " + s), true); }

    private void addHere(String name, int color) {
        Wp w = new Wp();
        w.dim = dimKey(); w.color = color;
        w.x = mc.player.getBlockX(); w.y = mc.player.getBlockY(); w.z = mc.player.getBlockZ();
        int n = 1;
        for (Wp o : list()) if (o.dim.equals(w.dim)) n++;
        w.name = name != null ? name : "WP " + n;
        list().add(w);
        save();
    }

    @Override public void onTick() {
        if (mc.player == null || mc.world == null) return;
        String dim = dimKey();
        if (add.b) { add.b = false; addHere(null, Draw.COLORS[newColor.idx]); msg("Waypoint added"); }
        if (removeNear.b) {
            removeNear.b = false;
            Wp best = null; double bd = 1e18;
            for (Wp w : list()) if (w.dim.equals(dim)) {
                double d = mc.player.squaredDistanceTo(w.x + 0.5, w.y + 0.5, w.z + 0.5);
                if (d < bd) { bd = d; best = w; }
            }
            if (best != null) { list().remove(best); save(); msg("Removed " + best.name); } else msg("No waypoints here");
        }
        if (clear.b) { clear.b = false; list().removeIf(w -> w.dim.equals(dim)); save(); msg("Cleared waypoints in this dimension"); }
        boolean dead = !mc.player.isAlive();
        if (dead && !wasDead && death.b) { addHere("Death", 0xFFFF4444); }
        wasDead = dead;
    }

    @Override public void onRender(DrawContext c, float td) {
        if (!Projector.ok || mc.world == null) return;
        String dim = dimKey();
        for (Wp w : list()) {
            if (!w.dim.equals(dim)) continue;
            Vec3d ctr = new Vec3d(w.x + 0.5, w.y + 0.5, w.z + 0.5);
            double dist = ctr.distanceTo(Projector.cam);
            if (dist < hideNear.v || (maxDist.v > 0 && dist > maxDist.v)) continue;
            int col = fade.b ? Esp.fade(w.color, dist, maxDist.v > 0 ? maxDist.v : 500) : w.color;
            if (box.b) Esp.box(c, new Box(w.x, w.y, w.z, w.x + 1, w.y + 1, w.z + 1), col, 1, true, 1);
            if (tracers.b) Esp.tracer(c, ctr, col, origin.idx, 1);
            if (labels.b || showDist.b) {
                double[] p = Projector.to(new Vec3d(w.x + 0.5, w.y + 1.4, w.z + 0.5));
                if (p == null) continue;
                String t = (labels.b ? w.name : "") + (showDist.b ? (labels.b ? " " : "") + (int) dist + "m" : "");
                Esp.label(c, t, (int) p[0], (int) p[1] - 11, col);
            }
        }
    }
}
