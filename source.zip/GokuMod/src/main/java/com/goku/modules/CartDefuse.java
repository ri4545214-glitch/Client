package com.goku.modules;

import com.goku.Module;
import com.goku.Modules;
import com.goku.Setting;
import com.goku.util.Targets;
import net.minecraft.entity.Entity;
import net.minecraft.entity.vehicle.TntMinecartEntity;
import net.minecraft.util.Hand;

/**
 * Cart Defense: breaks enemy TNT minecarts that are close to you while they stand still (a still cart just drops as an item;
 * a moving one would blow up, so those are left alone). Your own Cart Aura carts are ignored.
 */
public class CartDefuse extends Module {
    final Setting reach = add(Setting.num("Reach", 3.0, 2, 4.5, 0.1));
    final Setting ignoreOwn = add(Setting.bool("Ignore Carts When Cart Aura On", true));
    final Setting rotate = add(Setting.bool("Rotate", true));
    final Setting delay = add(Setting.num("Delay (ticks)", 2, 1, 10, 1));
    final Setting maxSpeed = add(Setting.num("Max Cart Speed", 0.05, 0.0, 0.09, 0.01));
    int cd;

    public CartDefuse() { super("Cart Defense"); }

    @Override public void onTick() {
        if (mc.currentScreen != null || Modules.FREECAM.enabled || !mc.player.isAlive()) return;
        if (cd > 0) { cd--; return; }
        if (ignoreOwn.b && Modules.CART_AURA.enabled) return;
        TntMinecartEntity best = null; double bd = 1e9;
        for (Entity e : mc.world.getEntities()) {
            if (!(e instanceof TntMinecartEntity c) || !c.isAlive()) continue;
            double d = mc.player.distanceTo(c);
            if (d > LegitMode.reach(reach.v) || d >= bd) continue;
            var v = c.getVelocity();
            if (Math.sqrt(v.x * v.x + v.z * v.z) > maxSpeed.v) continue;
            best = c; bd = d;
        }
        if (best == null) return;
        if (rotate.b) {
            float[] r = Targets.rot(mc.player.getEyePos(), best.getEntityPos().add(0, 0.3, 0));
            mc.player.setYaw(r[0]); mc.player.setPitch(r[1]);
        }
        mc.interactionManager.attackEntity(mc.player, best);
        mc.player.swingHand(Hand.MAIN_HAND);
        cd = LegitMode.delay(delay.i());
    }
}
