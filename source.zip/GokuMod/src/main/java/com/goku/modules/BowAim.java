package com.goku.modules;

import com.goku.Module;
import com.goku.Modules;
import com.goku.Setting;
import com.goku.util.Targets;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.BowItem;
import net.minecraft.item.CrossbowItem;
import net.minecraft.item.ItemStack;
import net.minecraft.util.math.Vec3d;

import java.util.HashMap;
import java.util.Map;

/** Aims bows and crossbows: leads moving targets and compensates arrow drop. */
public class BowAim extends Module {
    final Setting players = add(Setting.bool("Players", true));
    final Setting mobs = add(Setting.bool("Mobs", false));
    final Setting range = add(Setting.num("Range", 60, 10, 120, 5));
    final Setting fov = add(Setting.num("FOV", 90, 10, 360, 5));
    final Setting smooth = add(Setting.num("Smoothness", 3, 1, 20, 1));
    final Setting aim = add(Setting.mode("Aim At", 1, "Head", "Body", "Feet"));
    final Setting predict = add(Setting.bool("Lead Moving Targets", true));
    final Setting drop = add(Setting.bool("Compensate Arrow Drop", true));
    final Setting walls = add(Setting.bool("Through Walls", false));
    final Setting onlyDrawing = add(Setting.bool("Only While Drawing", true));
    final Setting release = add(Setting.bool("Auto Release (Bow)", false));

    private Map<Integer, Vec3d> last = new HashMap<>(), vel = new HashMap<>();

    public BowAim() { super("Bow Aim"); }

    /** Launch angle (degrees, up positive) and flight time in ticks for an arrow to reach horizontal distance d at height dy. */
    static double[] solve(double d, double dy, double v) {
        double prevErr = Double.NaN, prevA = 0, prevT = 0;
        for (double a = -80; a <= 80; a += 0.5) {
            double r = Math.toRadians(a), vx = v * Math.cos(r), vy = v * Math.sin(r), x = 0, y = 0, yAt = Double.NaN, tt = 0;
            for (int t = 1; t <= 200; t++) {
                double nx = x + vx, ny = y + vy;
                if (nx >= d) { double f = nx == x ? 0 : (d - x) / (nx - x); yAt = y + (ny - y) * f; tt = t - 1 + f; break; }
                x = nx; y = ny; vx *= 0.99; vy = vy * 0.99 - 0.05;
                if (vx < 0.01) break;
            }
            if (Double.isNaN(yAt)) { prevErr = Double.NaN; continue; }
            double err = yAt - dy;
            if (!Double.isNaN(prevErr) && prevErr < 0 && err >= 0) {
                double f = -prevErr / (err - prevErr);
                return new double[]{prevA + (a - prevA) * f, prevT + (tt - prevT) * f};
            }
            prevErr = err; prevA = a; prevT = tt;
        }
        return null;
    }

    Vec3d point(LivingEntity e) {
        return aim.idx == 0 ? e.getEyePos() : aim.idx == 1 ? e.getEntityPos().add(0, e.getHeight() / 2, 0) : e.getEntityPos().add(0, 0.2, 0);
    }

    @Override public void onTick() {
        // velocity tracking (per tick position delta)
        Map<Integer, Vec3d> nl = new HashMap<>(), nv = new HashMap<>();
        for (Entity e : mc.world.getEntities()) {
            if (!(e instanceof LivingEntity) || e == mc.player) continue;
            Vec3d p = e.getEntityPos(), q = last.get(e.getId());
            nl.put(e.getId(), p);
            if (q != null) nv.put(e.getId(), p.subtract(q));
        }
        last = nl; vel = nv;

        if (mc.currentScreen != null || Modules.FREECAM.enabled) return;
        ItemStack st = mc.player.getMainHandStack();
        boolean bow = st.getItem() instanceof BowItem, xbow = st.getItem() instanceof CrossbowItem;
        if (!bow && !xbow) return;
        if (bow && onlyDrawing.b && !mc.player.isUsingItem()) return;
        if (xbow && !CrossbowItem.isCharged(st)) return;
        double speed = bow ? (mc.player.isUsingItem() ? BowItem.getPullProgress(mc.player.getItemUseTime()) * 3.0 : 3.0) : 3.15;
        if (speed < 0.3) return;

        Vec3d eye = mc.player.getEyePos();
        LivingEntity best = null; float bestDiff = 1e9f, bestYaw = 0, bestPitch = 0;
        for (LivingEntity e : Targets.find(mc, range.v, players.b, mobs.b, LegitMode.walls(walls.b))) {
            Vec3d base = point(e), v = predict.b ? vel.getOrDefault(e.getId(), Vec3d.ZERO) : Vec3d.ZERO, aimPos = base;
            double t = 0;
            float yaw = 0, pitch = 0;
            boolean ok = true;
            for (int it = 0; it < 3 && ok; it++) {
                aimPos = base.add(v.multiply(t));
                double dx = aimPos.x - eye.x, dz = aimPos.z - eye.z, d = Math.sqrt(dx * dx + dz * dz), dy = aimPos.y - eye.y;
                float[] r = Targets.rot(eye, aimPos);
                yaw = r[0]; pitch = r[1];
                if (drop.b) {
                    double[] sol = solve(d, dy, speed);
                    if (sol == null) { ok = false; break; }
                    pitch = (float) -sol[0]; t = sol[1];
                } else t = Math.sqrt(d * d + dy * dy) / speed;
            }
            if (!ok) continue;
            float dyaw = Targets.wrap(yaw - mc.player.getYaw()), dpit = pitch - mc.player.getPitch();
            float diff = (float) Math.sqrt(dyaw * dyaw + dpit * dpit);
            if (diff <= fov.v / 2 && diff < bestDiff) { best = e; bestDiff = diff; bestYaw = yaw; bestPitch = pitch; }
        }
        if (best == null) return;
        float s = LegitMode.smooth((float) smooth.v);
        mc.player.setYaw(mc.player.getYaw() + Targets.wrap(bestYaw - mc.player.getYaw()) / s + LegitMode.noise());
        mc.player.setPitch(Math.max(-90, Math.min(90, mc.player.getPitch() + (bestPitch - mc.player.getPitch()) / s)));
        if (release.b && bow && mc.player.isUsingItem() && mc.player.getItemUseTime() >= 20 && bestDiff < 2f)
            mc.interactionManager.stopUsingItem(mc.player);
    }
}
