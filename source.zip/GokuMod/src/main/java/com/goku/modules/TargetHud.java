package com.goku.modules;

import com.goku.Module;
import com.goku.Modules;
import com.goku.Setting;
import com.goku.util.Fx;
import com.goku.util.Hud;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Vec3d;

import java.util.Locale;

/** Target HUD: info card for the player you are looking at (name, health, armor, distance). */
public class TargetHud extends Module {
    final Setting corner = add(Setting.mode("Corner", 3, com.goku.util.Hud.CORNERS));
    final Setting offX = add(Setting.num("Offset X", 14, 0, 400, 2));
    final Setting offY = add(Setting.num("Offset Y", 70, 0, 400, 2));
    final Setting scale = add(Setting.num("Scale", 1.0, 0.6, 2.0, 0.1));
    final Setting range = add(Setting.num("Range", 60, 10, 200, 5));
    final Setting cone = add(Setting.num("Aim Cone (deg)", 18, 4, 60, 2));
    final Setting hold = add(Setting.num("Hold Time (s)", 3, 1, 10, 1));
    final Setting showArmor = add(Setting.bool("Armor Bar", true));
    final Setting showDist = add(Setting.bool("Distance", true));

    PlayerEntity target;
    long seen;
    float shown = -1;

    public TargetHud() { super("Target HUD"); desc = "Info card for the player you aim at"; }

    @Override public void onDisable() { target = null; shown = -1; }

    PlayerEntity pick(float td) {
        if (mc.targetedEntity instanceof PlayerEntity tp && tp != mc.player && tp.isAlive()) return tp;
        Entity cam = mc.getCameraEntity();
        if (cam == null) return null;
        Vec3d from = cam.getCameraPosVec(td), look = cam.getRotationVec(td);
        double best = Math.cos(Math.toRadians(cone.v));
        PlayerEntity res = null;
        for (Entity e : mc.world.getEntities()) {
            if (!(e instanceof PlayerEntity p) || p == mc.player || p == cam || !p.isAlive()) continue;
            Vec3d lp = p.getLerpedPos(td);
            Vec3d to = new Vec3d(lp.x, lp.y + p.getHeight() * 0.5, lp.z).subtract(from);
            double len = to.length();
            if (len < 0.5 || len > range.v) continue;
            double dot = look.dotProduct(to.multiply(1.0 / len));
            if (dot > best) { best = dot; res = p; }
        }
        return res;
    }

    @Override public void onRender(DrawContext c, float td) {
        long now = System.currentTimeMillis();
        PlayerEntity p = pick(td);
        if (p != null) { if (p != target) shown = -1; target = p; seen = now; }
        if (target == null || !target.isAlive()) { target = null; return; }
        long left = (long) (hold.v * 1000) - (now - seen);
        if (left <= 0) { target = null; return; }
        float fade = Math.min(1f, left / 400f);

        TextRenderer tr = mc.textRenderer;
        float hp = target.getHealth(), max = Math.max(1f, target.getMaxHealth());
        float f = Math.max(0f, Math.min(1f, hp / max));
        shown = shown < 0 ? f : shown + (f - shown) * 0.18f;
        int acc = Modules.accent(), acc2 = Modules.accent2();
        int armor = target.getArmor();
        boolean ar = showArmor.b && armor > 0;
        int w = 156, h = ar ? 46 : 42;
        float sc = (float) scale.v;
        int[] pos = Hud.pos(corner.idx, offX.i(), offY.i(), (int) (w * sc), (int) (h * sc));

        var m = c.getMatrices();
        m.pushMatrix();
        m.translate(pos[0], pos[1]);
        m.scale(sc, sc);
        Fx.glow(c, 0, 0, w, h, acc, 3, (int) (50 * fade));
        Fx.round(c, 0, 0, w, h, Fx.fadeA(0xD00C0C14, fade));
        c.fillGradient(2, 0, w - 2, 1, Fx.fadeA(acc, fade), Fx.fadeA(acc2, fade));
        // avatar tile
        Fx.round(c, 6, 7, 34, 35, Fx.fadeA(0xFF1A1A26, fade));
        c.fillGradient(7, 8, 33, 34, Fx.fadeA(acc, 0.35f * fade), Fx.fadeA(acc2, 0.10f * fade));
        String nm = target.getName().getString();
        String ini = nm.isEmpty() ? "?" : nm.substring(0, 1).toUpperCase(Locale.ROOT);
        c.drawText(tr, ini, 20 - tr.getWidth(ini) / 2, 17, Fx.fadeA(0xFFFFFFFF, fade), true);
        // text
        String shownName = nm;
        while (shownName.length() > 1 && tr.getWidth(shownName) > w - 44 - (showDist.b ? 30 : 0)) shownName = shownName.substring(0, shownName.length() - 1);
        c.drawText(tr, shownName, 42, 8, Fx.fadeA(0xFFFFFFFF, fade), true);
        if (showDist.b) {
            String ds = (int) mc.player.distanceTo(target) + "m";
            c.drawText(tr, ds, w - 6 - tr.getWidth(ds), 8, Fx.fadeA(0xFFA0A0B8, fade), false);
        }
        String hs = String.format(Locale.ROOT, "%.1f / %.0f", hp, max);
        c.drawText(tr, hs, 42, 19, Fx.fadeA(Fx.healthColor(f), fade), false);
        // health bar
        int bx1 = 42, bx2 = w - 8;
        c.fill(bx1, 31, bx2, 36, Fx.fadeA(0xFF22222E, fade));
        int fw = (int) ((bx2 - bx1) * Math.max(0f, Math.min(1f, shown)));
        if (fw > 0) c.fillGradient(bx1, 31, bx1 + fw, 36, Fx.fadeA(Fx.mix(Fx.healthColor(f), 0xFFFFFFFF, 0.3f), fade), Fx.fadeA(Fx.healthColor(f), fade));
        int fw2 = (int) ((bx2 - bx1) * f);
        if (fw2 > 0) c.fill(bx1, 31, bx1 + fw2, 32, Fx.fadeA(0x55FFFFFF, fade));
        if (ar) {
            c.fill(bx1, 38, bx2, 41, Fx.fadeA(0xFF22222E, fade));
            c.fill(bx1, 38, bx1 + (int) ((bx2 - bx1) * Math.min(1f, armor / 20f)), 41, Fx.fadeA(0xFF5AA0FF, fade));
        }
        m.popMatrix();
    }
}
