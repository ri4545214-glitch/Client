package com.goku.modules;

import com.goku.Module;
import com.goku.Setting;
import com.goku.util.Draw;
import com.goku.util.Hud;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;

import java.util.ArrayList;
import java.util.List;

/** Small HUD with FPS (optionally ping and coordinates). Very cheap: a few text draws per frame. */
public class FpsCounter extends Module {
    final Setting corner = add(Setting.mode("Corner", 0, Hud.CORNERS));
    final Setting offX = add(Setting.num("Offset X", 4, 0, 400, 2));
    final Setting offY = add(Setting.num("Offset Y", 4, 0, 400, 2));
    final Setting scale = add(Setting.num("Scale", 1.0, 0.5, 2.0, 0.1));
    final Setting showFps = add(Setting.bool("Show FPS", true));
    final Setting showPing = add(Setting.bool("Show Ping", false));
    final Setting showXyz = add(Setting.bool("Show Coordinates", false));
    final Setting label = add(Setting.bool("Labels", true));
    final Setting colorMode = add(Setting.mode("Color", 0, "By FPS", "Fixed"));
    final Setting fixed = add(Setting.mode("Fixed Color", 6, Draw.NAMES));
    final Setting bg = add(Setting.bool("Background", true));
    final Setting bgAlpha = add(Setting.num("Background Alpha", 100, 0, 255, 5));

    public FpsCounter() { super("FPS Counter"); }

    @Override public void onRender(DrawContext c, float td) {
        if (mc.player == null) return;
        List<String> lines = new ArrayList<>();
        int fps = mc.getCurrentFps();
        if (showFps.b) lines.add((label.b ? "FPS: " : "") + fps);
        if (showPing.b) {
            var net = mc.getNetworkHandler();
            var e = net == null ? null : net.getPlayerListEntry(mc.player.getUuid());
            lines.add((label.b ? "Ping: " : "") + (e == null ? "-" : e.getLatency() + "ms"));
        }
        if (showXyz.b) lines.add((label.b ? "XYZ: " : "") + mc.player.getBlockX() + " " + mc.player.getBlockY() + " " + mc.player.getBlockZ());
        if (lines.isEmpty()) return;
        TextRenderer tr = mc.textRenderer;
        int w = 0;
        for (String s : lines) w = Math.max(w, tr.getWidth(s));
        w += 6;
        int h = lines.size() * 10 + 2;
        float sc = (float) scale.v;
        int[] p = Hud.pos(corner.idx, offX.i(), offY.i(), (int) (w * sc), (int) (h * sc));
        int col = colorMode.idx == 0 ? (fps >= 60 ? 0xFF55FF55 : fps >= 30 ? 0xFFFFFF55 : 0xFFFF5555) : Draw.COLORS[fixed.idx];
        var m = c.getMatrices();
        m.pushMatrix();
        m.translate(p[0], p[1]);
        m.scale(sc, sc);
        if (bg.b) c.fill(0, 0, w, h, (bgAlpha.i() << 24));
        int y = 2;
        for (String s : lines) { c.drawText(tr, s, 3, y, col, true); y += 10; }
        m.popMatrix();
    }
}
