package com.goku.modules;

import com.goku.Module;
import com.goku.Modules;
import com.goku.Setting;
import com.goku.util.Draw;
import com.goku.util.Fx;
import com.goku.util.Projector;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.mob.Monster;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Vec3d;

/** Direction pins: glowing arrows that point at players (and mobs) that are outside your view, with name, distance and health. */
public class DirectionPins extends Module {
    final Setting players = add(Setting.bool("Players", true));
    final Setting hostile = add(Setting.bool("Hostile Mobs", false));
    final Setting mode = add(Setting.mode("Layout", 0, "Circle", "Screen Edge"));
    final Setting radius = add(Setting.num("Circle Radius", 110, 40, 300, 5));
    final Setting margin = add(Setting.num("Edge Margin", 26, 10, 80, 2));
    final Setting size = add(Setting.num("Arrow Size", 12, 6, 24, 1));
    final Setting name = add(Setting.bool("Name", true));
    final Setting dist = add(Setting.bool("Distance", true));
    final Setting health = add(Setting.bool("Health Bar", true));
    final Setting glow = add(Setting.bool("Glow", true));
    final Setting pulse = add(Setting.bool("Pulse Near Targets", true));
    final Setting onScreen = add(Setting.bool("Pin On-Screen Targets", false));
    final Setting colorMode = add(Setting.mode("Color", 0, "By Distance", "Health", "GUI Accent", "Custom"));
    final Setting custom = add(Setting.mode("Custom Color", 0, Draw.NAMES));
    final Setting range = add(Setting.num("Range (0=inf)", 150, 0, 500, 10));

    public DirectionPins() { super("Direction Pins"); desc = "Glowing arrows pointing at players"; }

    @Override public void onRender(DrawContext c, float td) {
        if (!Projector.ok) return;
        TextRenderer tr = mc.textRenderer;
        double t = Fx.time();
        double cx = Projector.W / 2.0, cy = Projector.H / 2.0;
        for (Entity e : mc.world.getEntities()) {
            if (e == mc.getCameraEntity() || e == mc.player) continue;
            boolean ok = (players.b && e instanceof PlayerEntity) || (hostile.b && e instanceof Monster);
            if (!ok || !(e instanceof LivingEntity le) || !le.isAlive()) continue;
            Vec3d lp = e.getLerpedPos(td);
            double d = lp.distanceTo(Projector.cam);
            if (range.v > 0 && d > range.v) continue;
            Vec3d mid = new Vec3d(lp.x, lp.y + e.getHeight() * 0.5, lp.z);
            double[] s = Projector.toEdge(mid);
            boolean behind = Projector.depth(mid) < 0.05;
            double dx = s[0] - cx, dy = s[1] - cy, len = Math.hypot(dx, dy);
            boolean visible = !behind && s[0] >= 0 && s[0] <= Projector.W && s[1] >= 0 && s[1] <= Projector.H;
            float f = Math.max(0f, Math.min(1f, le.getHealth() / Math.max(1f, le.getMaxHealth())));
            double rmax = range.v > 0 ? range.v : 200;
            int col = switch (colorMode.idx) {
                case 0 -> Fx.mix(0xFFFF4455, 0xFF44DDFF, (float) Math.min(1.0, d / Math.min(rmax, 120)));
                case 1 -> Fx.healthColor(f);
                case 2 -> Modules.accent();
                default -> Draw.COLORS[custom.idx];
            };

            if (visible && onScreen.b) {
                Fx.diamond(c, s[0], s[1] - 18, 4, Fx.a(col, 0x55));
                Fx.diamond(c, s[0], s[1] - 18, 2, col);
            }
            if (len < 1.0) continue;
            double ux = dx / len, uy = dy / len, px, py;
            if (mode.idx == 0) {
                if (visible && len < radius.v) continue;       // already in the middle of the screen
                px = cx + ux * radius.v; py = cy + uy * radius.v;
            } else {
                if (visible) continue;
                double mx = cx - margin.v, my = cy - margin.v;
                double k = Math.min(Math.abs(ux) < 1e-6 ? 1e9 : mx / Math.abs(ux), Math.abs(uy) < 1e-6 ? 1e9 : my / Math.abs(uy));
                px = cx + ux * k; py = cy + uy * k;
            }
            double ang = Math.atan2(dy, dx);
            int sz = size.i();
            double beat = pulse.b && d < 25 ? 0.75 + 0.25 * Math.sin(t * 9) : 1.0;
            if (glow.b) {
                Fx.arrow(c, px, py, ang, sz + 8, Fx.a(col, (int) (0x28 * beat)));
                Fx.arrow(c, px, py, ang, sz + 4, Fx.a(col, (int) (0x50 * beat)));
            }
            Fx.arrow(c, px, py, ang, sz, Fx.a(col, (int) (0xFF * beat)));

            // label sits on the inner side of the arrow
            double lx = px - ux * (sz + 12), ly = py - uy * (sz + 12);
            lx = Math.max(30, Math.min(Projector.W - 30, lx));
            ly = Math.max(10, Math.min(Projector.H - 24, ly));
            int ty = (int) ly - 4;
            if (name.b) { Draw.text(c, e.getName().getString(), (int) lx, ty, 0xFFFFFFFF); ty += 10; }
            if (dist.b) { Draw.text(c, (int) d + "m", (int) lx, ty, 0xFFB0B0C8); ty += 10; }
            if (health.b) {
                int bx = (int) lx - 14;
                c.fill(bx, ty, bx + 28, ty + 3, 0xA0202030);
                c.fill(bx, ty, bx + (int) (28 * f), ty + 3, Fx.healthColor(f));
            }
        }
    }
}
