package com.goku;

import com.goku.util.Sfx;
import com.google.gson.JsonObject;
import net.minecraft.client.MinecraftClient;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.nio.file.Files;
import java.util.Locale;

/**
 * Module keybinds. Any toggleable module can be bound to a keyboard key or an extra mouse button (middle / side buttons),
 * as Toggle (press) or Hold (active while held). Stored globally in config/gokumod/keybinds.json (not per profile).
 * Binds only fire in-game (no screen open), so typing in chat or menus never triggers them.
 */
public final class Keybinds {
    public static final int MOUSE_BASE = 1000;

    /** Polled every frame and at both ends of every tick (called from GokuMod.pollOpen). */
    public static void poll(MinecraftClient mc) {
        if (mc.getWindow() == null) return;
        long h = mc.getWindow().getHandle();
        boolean free = mc.currentScreen == null && mc.player != null && mc.world != null && mc.getOverlay() == null;
        for (Module m : Modules.ALL) {
            if (m.key < 0 || !m.toggleable) { m.keyWas = false; continue; }
            boolean down = free && isDown(h, m.key);
            if (m.keyHold) {
                if (down && !m.enabled) { m.setEnabled(true); m.heldOn = true; }
                else if (!down && m.heldOn) { m.setEnabled(false); m.heldOn = false; }
            } else if (down && !m.keyWas) {
                m.toggle();
                Sfx.play(m.enabled ? "on" : "off", 1f);
            }
            m.keyWas = down;
        }
    }

    static boolean isDown(long window, int key) {
        if (key >= MOUSE_BASE) return GLFW.glfwGetMouseButton(window, key - MOUSE_BASE) == GLFW.GLFW_PRESS;
        return GLFW.glfwGetKey(window, key) == GLFW.GLFW_PRESS;
    }

    /** Keys that belong to the mod's own menus. */
    public static boolean reserved(int k) {
        return k == GLFW.GLFW_KEY_RIGHT_ALT || k == GLFW.GLFW_KEY_INSERT || k == GLFW.GLFW_KEY_RIGHT_SHIFT || k == GLFW.GLFW_KEY_RIGHT_CONTROL;
    }

    public static String name(int k) {
        if (k < 0) return "None";
        if (k >= MOUSE_BASE) return "MOUSE " + (k - MOUSE_BASE + 1);
        if (k >= GLFW.GLFW_KEY_A && k <= GLFW.GLFW_KEY_Z) return String.valueOf((char) ('A' + (k - GLFW.GLFW_KEY_A)));
        if (k >= GLFW.GLFW_KEY_0 && k <= GLFW.GLFW_KEY_9) return String.valueOf((char) ('0' + (k - GLFW.GLFW_KEY_0)));
        if (k >= GLFW.GLFW_KEY_F1 && k <= GLFW.GLFW_KEY_F25) return "F" + (k - GLFW.GLFW_KEY_F1 + 1);
        if (k >= GLFW.GLFW_KEY_KP_0 && k <= GLFW.GLFW_KEY_KP_9) return "NUM " + (k - GLFW.GLFW_KEY_KP_0);
        switch (k) {
            case GLFW.GLFW_KEY_SPACE: return "SPACE";
            case GLFW.GLFW_KEY_TAB: return "TAB";
            case GLFW.GLFW_KEY_ENTER: return "ENTER";
            case GLFW.GLFW_KEY_CAPS_LOCK: return "CAPS";
            case GLFW.GLFW_KEY_LEFT_SHIFT: return "L-SHIFT";
            case GLFW.GLFW_KEY_LEFT_CONTROL: return "L-CTRL";
            case GLFW.GLFW_KEY_LEFT_ALT: return "L-ALT";
            case GLFW.GLFW_KEY_UP: return "UP";
            case GLFW.GLFW_KEY_DOWN: return "DOWN";
            case GLFW.GLFW_KEY_LEFT: return "LEFT";
            case GLFW.GLFW_KEY_RIGHT: return "RIGHT";
            case GLFW.GLFW_KEY_HOME: return "HOME";
            case GLFW.GLFW_KEY_END: return "END";
            case GLFW.GLFW_KEY_PAGE_UP: return "PGUP";
            case GLFW.GLFW_KEY_PAGE_DOWN: return "PGDN";
            case GLFW.GLFW_KEY_DELETE: return "DEL";
            case GLFW.GLFW_KEY_KP_ADD: return "NUM +";
            case GLFW.GLFW_KEY_KP_SUBTRACT: return "NUM -";
            case GLFW.GLFW_KEY_KP_MULTIPLY: return "NUM *";
            case GLFW.GLFW_KEY_KP_DIVIDE: return "NUM /";
            case GLFW.GLFW_KEY_KP_ENTER: return "NUM ENTER";
            case GLFW.GLFW_KEY_KP_DECIMAL: return "NUM .";
            case GLFW.GLFW_KEY_PAUSE: return "PAUSE";
            case GLFW.GLFW_KEY_SCROLL_LOCK: return "SCROLL";
            case GLFW.GLFW_KEY_PRINT_SCREEN: return "PRTSC";
            default: {
                String n = GLFW.glfwGetKeyName(k, 0);
                return n != null && !n.isEmpty() ? n.toUpperCase(Locale.ROOT) : "KEY " + k;
            }
        }
    }

    static void msg(String s) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player != null) mc.player.sendMessage(Text.literal("[Goku] " + s), true);
    }

    /** Binds a module. Another module that already uses the same key is unbound (one key, one module). */
    public static void set(Module m, int key) {
        if (key >= 0) for (Module o : Modules.ALL) if (o != m && o.key == key) { o.key = -1; o.heldOn = false; msg(Keybinds.name(key) + " moved from " + o.name + " to " + m.name); }
        m.key = key; m.keyWas = true; m.heldOn = false;
        save();
        if (key >= 0) Sfx.play("on", 1.2f);
    }

    public static void clear(Module m) { set(m, -1); m.keyHold = false; save(); Sfx.play("off", 1f); }

    public static void setHold(Module m, boolean hold) { m.keyHold = hold; m.heldOn = false; save(); }

    /** Feeds a pressed key into a bind capture. Returns true when the capture is finished (bound, cleared or cancelled). */
    public static boolean capture(Module m, int k) {
        if (k == GLFW.GLFW_KEY_ESCAPE) return true;
        if (k == GLFW.GLFW_KEY_BACKSPACE || k == GLFW.GLFW_KEY_DELETE) { clear(m); return true; }
        if (reserved(k)) { msg(name(k) + " is used by the menus - pick another key"); return false; }
        set(m, k);
        return true;
    }

    /** Mouse button capture (middle / side buttons only; left and right click keep their normal GUI meaning). */
    public static boolean captureMouse(Module m, int button) {
        if (button < 2) return false;
        set(m, MOUSE_BASE + button);
        return true;
    }

    public static void save() {
        try {
            Files.createDirectories(Config.dir());
            JsonObject root = new JsonObject();
            for (Module m : Modules.ALL) {
                if (!m.toggleable || (m.key < 0 && !m.keyHold)) continue;
                JsonObject o = new JsonObject();
                o.addProperty("key", m.key);
                o.addProperty("hold", m.keyHold);
                root.add(m.name, o);
            }
            Files.writeString(Config.dir().resolve("keybinds.json"), Config.GSON.toJson(root));
        } catch (Exception ignored) { }
    }

    public static void load() {
        try {
            var f = Config.dir().resolve("keybinds.json");
            if (!Files.exists(f)) return;
            JsonObject root = Config.GSON.fromJson(Files.readString(f), JsonObject.class);
            for (Module m : Modules.ALL) {
                if (!root.has(m.name)) continue;
                JsonObject o = root.getAsJsonObject(m.name);
                if (o.has("key")) m.key = o.get("key").getAsInt();
                if (o.has("hold")) m.keyHold = o.get("hold").getAsBoolean();
            }
        } catch (Exception ignored) { }
    }
}
