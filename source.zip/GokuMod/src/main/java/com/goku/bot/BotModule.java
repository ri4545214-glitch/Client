package com.goku.bot;

import com.goku.Module;
import com.goku.Setting;
import net.minecraft.text.Text;

/** Practice bot (singleplayer only). Settings live here; the behaviour is in BotBrain. */
public class BotModule extends Module {
    public final Setting mode = add(Setting.mode("Fight Style", 0, "Crystal PvP", "Mace PvP", "Nethpot PvP"));
    public final Setting difficulty = add(Setting.num("Difficulty", 5, 1, 10, 1));
    public final Setting passive = add(Setting.bool("Training Dummy (No Attacks)", false));
    public final Setting health = add(Setting.num("Bot Health", 20, 20, 100, 2));
    public final Setting hop = add(Setting.bool("Jump Around", true));
    public final Setting strafe = add(Setting.bool("Strafe", true));
    public final Setting respawn = add(Setting.bool("Auto Respawn", true));
    public final Setting respawnDelay = add(Setting.num("Respawn Delay (s)", 3, 1, 30, 1));
    public final Setting spawnDist = add(Setting.num("Spawn Distance", 8, 3, 30, 1));
    public final Setting prot = add(Setting.num("Armor Protection Lvl", 4, 0, 4, 1));
    public final Setting totem = add(Setting.bool("Offhand Totem", true));
    public final Setting totems = add(Setting.num("Totem Refills", 3, 0, 20, 1));
    public final Setting sharp = add(Setting.num("Sword Sharpness", 5, 0, 5, 1));
    public final Setting density = add(Setting.num("Mace Density", 5, 0, 5, 1));
    public final Setting launch = add(Setting.num("Mace Launch Height", 8, 4, 16, 1));
    public final Setting crystalPower = add(Setting.num("Crystal Power", 6, 2, 6, 1));
    public final Setting crystalRate = add(Setting.num("Crystal Every (ticks)", 12, 4, 40, 1));
    public final Setting pots = add(Setting.num("Splash Pots", 15, 0, 40, 1));
    public final Setting healAt = add(Setting.num("Heal At HP", 10, 2, 30, 1));
    public final Setting buffs = add(Setting.bool("Speed/Strength Pots", true));
    public final Setting reload = add(Setting.bool("> Reload Bot Config (bot.json)", false));
    public final Setting rekit = add(Setting.bool("> Re-Kit Bot", false));
    public final Setting respawnNow = add(Setting.bool("> Respawn Bot", false));

    static { BotBrain.init(); BotCommands.register(); }

    public BotModule() { super("Practice Bot"); BotBrain.module = this; BotConfig.load(); }

    void msg(String s) { if (mc.player != null) mc.player.sendMessage(Text.literal("[Goku] " + s), false); }

    @Override public void onEnable() {
        if (!mc.isInSingleplayer() || mc.getServer() == null || mc.world == null) {
            msg("Practice Bot only works in singleplayer.");
            setEnabled(false);
            return;
        }
        BotConfig.load();
        msg("Spawning bot '" + BotConfig.name + "' (skin: " + BotConfig.skin + "). Use /gokubot help to configure it by command.");
        spawn();
    }

    /** Spawns (or re-spawns) the bot. If a cape account is configured its cape is downloaded first. */
    void spawn() {
        if (mc.player == null || mc.world == null || !mc.isInSingleplayer()) return;
        String cape = BotConfig.cape;
        if (cape.isEmpty()) { doSpawn(null); return; }
        com.goku.skin.SkinFetch.load(cape, l -> mc.execute(() -> {
            String asset = null;
            if (l.cape() != null) asset = l.cape().getNamespace() + ":" + l.cape().getPath().replaceFirst("^textures/", "").replaceFirst("\\.png$", "");
            else msg("Account '" + cape + "' has no cape; spawning without one.");
            doSpawn(asset);
        }), err -> mc.execute(() -> { msg("Could not load cape '" + cape + "': " + err); doSpawn(null); }));
    }

    private void doSpawn(String capeAsset) {
        var p = mc.player;
        if (p == null || mc.world == null) return;
        double yaw = Math.toRadians(p.getYaw());
        double d = spawnDist.v;
        BotBrain.requestSpawn(mc.world.getRegistryKey(), p.getUuid(), p.getX() - Math.sin(yaw) * d, p.getY() + 0.5, p.getZ() + Math.cos(yaw) * d, capeAsset);
    }

    /** Used by /gokubot: (re)spawn the bot, switching the module on if needed. */
    void spawnOrEnable() {
        if (enabled) spawn(); else setEnabled(true);
    }

    @Override public void onDisable() { BotBrain.requestRemove(); }

    @Override public void onTick() {
        if (reload.b) { reload.b = false; BotConfig.load(); msg("Bot config reloaded: " + BotConfig.name + " / skin " + BotConfig.skin + " (press Respawn Bot to apply)"); }
        if (rekit.b) { rekit.b = false; BotBrain.requestRekit(); }
        if (respawnNow.b) { respawnNow.b = false; spawn(); }
    }
}
