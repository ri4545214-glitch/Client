package com.goku.bot;

import com.goku.Modules;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.BoolArgumentType;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.command.v2.FabricClientCommandSource;
import net.minecraft.client.MinecraftClient;
import net.minecraft.text.Text;

/** /gokubot ... : configure the practice bot from chat (singleplayer). Everything is saved to config/gokumod/bot.json. */
final class BotCommands {
    private static boolean done;

    static void register() {
        if (done) return;
        done = true;
        ClientCommandRegistrationCallback.EVENT.register((d, access) -> build(d));
    }

    private static BotModule bot() { return BotBrain.module; }

    private static int say(com.mojang.brigadier.context.CommandContext<FabricClientCommandSource> c, String s) {
        c.getSource().sendFeedback(Text.literal("[Goku] " + s));
        return 1;
    }

    private static LiteralArgumentBuilder<FabricClientCommandSource> lit(String n) { return ClientCommandManager.literal(n); }

    private static void build(CommandDispatcher<FabricClientCommandSource> d) {
        var root = lit("gokubot");

        root.executes(c -> help(c));
        root.then(lit("help").executes(c -> help(c)));

        root.then(lit("spawn").executes(c -> { bot().spawnOrEnable(); return say(c, "Spawning the bot..."); }));
        root.then(lit("respawn").executes(c -> { bot().spawnOrEnable(); return say(c, "Respawning the bot..."); }));
        root.then(lit("remove").executes(c -> { bot().setEnabled(false); return say(c, "Bot removed."); }));
        root.then(lit("kit").executes(c -> { BotBrain.requestRekit(); return say(c, "Re-kitting the bot."); }));
        root.then(lit("status").executes(c -> say(c, "Bot: " + (bot().enabled ? BotBrain.status() : "off")
                + " | style " + bot().mode.modeName() + ", difficulty " + bot().difficulty.i() + ", hp " + bot().health.i()
                + " | name '" + BotConfig.name + "', skin '" + BotConfig.skin + "', cape '" + (BotConfig.cape.isEmpty() ? "none" : BotConfig.cape) + "'")));
        root.then(lit("save").executes(c -> { BotConfig.save(); return say(c, "Saved " + BotConfig.file()); }));

        root.then(lit("style")
                .then(lit("crystal").executes(c -> style(c, 0)))
                .then(lit("mace").executes(c -> style(c, 1)))
                .then(lit("nethpot").executes(c -> style(c, 2))));

        root.then(lit("difficulty").then(ClientCommandManager.argument("level", IntegerArgumentType.integer(1, 10))
                .executes(c -> { bot().difficulty.v = IntegerArgumentType.getInteger(c, "level"); return say(c, "Difficulty " + bot().difficulty.i()); })));
        root.then(lit("health").then(ClientCommandManager.argument("hp", IntegerArgumentType.integer(20, 100))
                .executes(c -> { bot().health.v = IntegerArgumentType.getInteger(c, "hp"); return say(c, "Bot health " + bot().health.i() + " (applies on respawn)"); })));
        root.then(lit("passive").then(ClientCommandManager.argument("on", BoolArgumentType.bool())
                .executes(c -> { bot().passive.b = BoolArgumentType.getBool(c, "on"); return say(c, "Training dummy (no attacks): " + bot().passive.b); })));
        root.then(lit("totems").then(ClientCommandManager.argument("n", IntegerArgumentType.integer(0, 20))
                .executes(c -> { bot().totems.v = IntegerArgumentType.getInteger(c, "n"); return say(c, "Totem refills " + bot().totems.i() + " (applies on respawn)"); })));

        root.then(lit("name").then(ClientCommandManager.argument("text", StringArgumentType.greedyString()).executes(c -> {
            BotConfig.name = StringArgumentType.getString(c, "text");
            BotConfig.save(); BotConfig.load();
            return apply(c, "Bot name: " + BotConfig.name);
        })));
        root.then(lit("showname").then(ClientCommandManager.argument("on", BoolArgumentType.bool()).executes(c -> {
            BotConfig.showName = BoolArgumentType.getBool(c, "on");
            BotConfig.save();
            return apply(c, "Name tag " + (BotConfig.showName ? "shown" : "hidden"));
        })));
        root.then(lit("skin").then(ClientCommandManager.argument("account", StringArgumentType.word()).executes(c -> {
            String a = StringArgumentType.getString(c, "account");
            if (a.equalsIgnoreCase("me")) a = MinecraftClient.getInstance().getSession().getUsername();
            BotConfig.skin = a;
            BotConfig.save(); BotConfig.load();
            return apply(c, "Bot skin: " + BotConfig.skin);
        })));
        root.then(lit("cape").then(ClientCommandManager.argument("account", StringArgumentType.word()).executes(c -> {
            String a = StringArgumentType.getString(c, "account");
            if (a.equalsIgnoreCase("me")) a = MinecraftClient.getInstance().getSession().getUsername();
            BotConfig.cape = a.equalsIgnoreCase("none") ? "" : a;
            BotConfig.save(); BotConfig.load();
            return apply(c, "Bot cape: " + (BotConfig.cape.isEmpty() ? "none" : "cape of " + BotConfig.cape));
        })));

        d.register(root);
    }

    private static int style(com.mojang.brigadier.context.CommandContext<FabricClientCommandSource> c, int i) {
        bot().mode.idx = i;
        if (bot().enabled) { bot().spawnOrEnable(); return say(c, "Style: " + bot().mode.modeName() + " (bot respawned with the new kit)"); }
        return say(c, "Style: " + bot().mode.modeName());
    }

    /** Name/skin/cape changes need a fresh bot; respawn it if it is out. */
    private static int apply(com.mojang.brigadier.context.CommandContext<FabricClientCommandSource> c, String msg) {
        if (bot().enabled) { bot().spawnOrEnable(); return say(c, msg + " (bot respawned)"); }
        return say(c, msg + " (applies when you spawn the bot)");
    }

    private static int help(com.mojang.brigadier.context.CommandContext<FabricClientCommandSource> c) {
        String[] l = {
                "/gokubot spawn | respawn | remove | kit | status | save",
                "/gokubot style crystal|mace|nethpot",
                "/gokubot difficulty <1-10>   health <20-100>   totems <0-20>   passive <true|false>",
                "/gokubot name <text>   showname <true|false>",
                "/gokubot skin <account|me>   cape <account|me|none>",
                "Skin/cape use real Minecraft account names (downloaded from Mojang). Singleplayer only."};
        for (String s : l) c.getSource().sendFeedback(Text.literal("[Goku] " + s));
        return 1;
    }
}
