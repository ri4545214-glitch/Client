package com.goku.util;

import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.registry.Registries;
import net.minecraft.state.property.Property;
import net.minecraft.util.Identifier;

import java.io.DataInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;
import java.util.zip.GZIPInputStream;

/** Minimal Sponge schematic (.schem, v2 and v3) reader. Gives a size and a flat list of non-air blocks. */
public final class Schem {
    public record Entry(int x, int y, int z, Block block, BlockState state) {}

    public int width, height, length;
    public final List<Entry> blocks = new ArrayList<>();

    // ---- tiny NBT reader
    static Object read(DataInputStream in, int type) throws IOException {
        switch (type) {
            case 1: return in.readByte();
            case 2: return in.readShort();
            case 3: return in.readInt();
            case 4: return in.readLong();
            case 5: return in.readFloat();
            case 6: return in.readDouble();
            case 7: { byte[] b = new byte[in.readInt()]; in.readFully(b); return b; }
            case 8: return in.readUTF();
            case 9: {
                int t = in.readByte(), n = in.readInt();
                List<Object> l = new ArrayList<>();
                for (int i = 0; i < n; i++) l.add(read(in, t));
                return l;
            }
            case 10: {
                Map<String, Object> m = new HashMap<>();
                while (true) {
                    int t = in.readByte();
                    if (t == 0) break;
                    String k = in.readUTF();
                    m.put(k, read(in, t));
                }
                return m;
            }
            case 11: { int[] a = new int[in.readInt()]; for (int i = 0; i < a.length; i++) a[i] = in.readInt(); return a; }
            case 12: { long[] a = new long[in.readInt()]; for (int i = 0; i < a.length; i++) a[i] = in.readLong(); return a; }
            default: throw new IOException("bad nbt tag " + type);
        }
    }

    @SuppressWarnings("unchecked")
    static Map<String, Object> map(Object o) { return o instanceof Map ? (Map<String, Object>) o : null; }

    @SuppressWarnings({"unchecked", "rawtypes"})
    static BlockState withProp(BlockState st, String name, String val) {
        Property p = st.getBlock().getStateManager().getProperty(name);
        if (p == null) return st;
        Optional o = p.parse(val);
        return o.isPresent() ? (BlockState) st.with(p, (Comparable) o.get()) : st;
    }

    static BlockState parseState(String s) {
        String id = s, props = null;
        int i = s.indexOf('[');
        if (i >= 0) { id = s.substring(0, i); props = s.substring(i + 1, s.length() - 1); }
        Block b = Registries.BLOCK.get(Identifier.of(id));
        BlockState st = b.getDefaultState();
        if (props != null && !props.isEmpty()) for (String kv : props.split(",")) {
            int e = kv.indexOf('=');
            if (e > 0) st = withProp(st, kv.substring(0, e), kv.substring(e + 1));
        }
        return st;
    }

    public static Schem load(Path file) throws IOException {
        try (InputStream raw = Files.newInputStream(file); DataInputStream in = new DataInputStream(new GZIPInputStream(raw))) {
            int t = in.readByte();
            if (t != 10) throw new IOException("not a schematic");
            in.readUTF();
            Map<String, Object> root = map(read(in, 10));
            if (root.containsKey("Schematic")) root = map(root.get("Schematic"));
            Schem s = new Schem();
            s.width = ((Number) root.get("Width")).intValue();
            s.height = ((Number) root.get("Height")).intValue();
            s.length = ((Number) root.get("Length")).intValue();
            Map<String, Object> palette; byte[] data;
            Map<String, Object> bl = map(root.get("Blocks"));
            if (bl != null) { palette = map(bl.get("Palette")); data = (byte[]) bl.get("Data"); }
            else { palette = map(root.get("Palette")); data = (byte[]) root.get("BlockData"); }
            if (palette == null || data == null) throw new IOException("unsupported schematic (need Sponge .schem v2/v3)");
            Map<Integer, BlockState> states = new HashMap<>();
            for (var e : palette.entrySet()) states.put(((Number) e.getValue()).intValue(), parseState(e.getKey()));
            int pos = 0, idx = 0, total = s.width * s.height * s.length;
            while (pos < data.length && idx < total) {
                int v = 0, shift = 0, b;
                do { b = data[pos++]; v |= (b & 0x7F) << shift; shift += 7; } while ((b & 0x80) != 0 && pos < data.length);
                BlockState st = states.get(v);
                if (st != null && !st.isAir()) {
                    int x = idx % s.width, z = (idx / s.width) % s.length, y = idx / (s.width * s.length);
                    s.blocks.add(new Entry(x, y, z, st.getBlock(), st));
                }
                idx++;
                if (s.blocks.size() > 300_000) throw new IOException("schematic too large (300k blocks max)");
            }
            return s;
        }
    }
}
