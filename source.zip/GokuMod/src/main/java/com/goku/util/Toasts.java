package com.goku.util;

import com.goku.Module;
import com.goku.Modules;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;

import java.util.ArrayList;
import java.util.List;

/** Small slide-in notifications ("Kill Aura enabled"). Drawn by the HUD Overlay module. */
public final class Toasts {
    private static final class T { String name; boolean on; long t0; }
    private static final List<T> LIST = new ArrayList<>();
    private static final long LIFE = 2200;

    public static void push(Module m) {
        if (!m.toggleable || Modules.HUD == null || m == Modules.HUD) return;
        if (!Modules.HUD.enabled || !Modules.HUD.toasts.b) return;
        T t = new T();
        t.name = m.name; t.on = m.enabled; t.t0 = System.currentTimeMillis();
        LIST.add(t);
        while (LIST.size() > 4) LIST.remove(0);
    }

    public static void render(DrawContext c) {
        long now = System.currentTimeMillis();
        LIST.removeIf(t -> now - t.t0 > LIFE);
        TextRenderer tr = MinecraftClient.getInstance().textRenderer;
        int acc = Modules.accent(), acc2 = Modules.accent2();
        int n = LIST.size();
        for (int i = 0; i < n; i++) {
            T t = LIST.get(n - 1 - i);
            long age = now - t.t0;
            float in = Math.min(1f, age / 220f), out = Math.min(1f, (LIFE - age) / 300f);
            float k = in * out;
            String msg = t.name + (t.on ? "  enabled" : "  disabled");
            int w = tr.getWidth(msg) + 24, h = 18;
            float ease = 1f - (1f - in) * (1f - in) * (1f - in);
            int x = Projector.W - w - 8 + (int) ((1f - ease) * (w + 12));
            int y = Projector.H - 44 - i * 22;
            Fx.round(c, x, y, x + w, y + h, Fx.fadeA(0xF0101018, k));
            c.fillGradient(x + 1, y + 3, x + 3, y + h - 3, Fx.fadeA(acc, k), Fx.fadeA(acc2, k));
            Fx.round(c, x + 8, y + 6, x + 14, y + 12, Fx.fadeA(t.on ? 0xFF55EE77 : 0xFFEE5566, k));
            c.drawText(tr, msg, x + 19, y + 5, Fx.fadeA(0xFFFFFFFF, k), false);
        }
    }
}
