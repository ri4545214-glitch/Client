package com.goku.util;

import net.minecraft.block.BlockEntityProvider;
import net.minecraft.block.FallingBlock;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.ItemEntity;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Items;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayList;
import java.util.List;

/** Normal block placing (clicks a real neighbouring block face) and the trap shell layout shared by FeetTrap / AutoTrap. */
public final class Place {
    static MinecraftClient mc() { return MinecraftClient.getInstance(); }

    public static void msg(String s) { var mc = mc(); if (mc.player != null) mc.player.sendMessage(Text.literal("[Goku] " + s), true); }

    /** Hotbar slot with obsidian, or (if allowed) any plain solid block. -1 if none. */
    public static int blockSlot(boolean obsidianOnly) {
        int o = Inv.hotbar(s -> s.isOf(Items.OBSIDIAN) || s.isOf(Items.CRYING_OBSIDIAN));
        if (o >= 0 || obsidianOnly) return o;
        return Inv.hotbar(s -> s.getItem() instanceof BlockItem bi && !(bi.getBlock() instanceof FallingBlock) && !(bi.getBlock() instanceof BlockEntityProvider));
    }

    public static boolean free(BlockPos p) {
        var mc = mc();
        if (!mc.world.getBlockState(p).isReplaceable()) return false;
        for (Entity e : mc.world.getOtherEntities(null, new Box(p)))
            if (e.isAlive() && !e.isSpectator() && !(e instanceof ItemEntity)) return false;
        return true;
    }

    /** Places the held block at p by clicking an adjacent solid block. False if p is not free, out of reach, or has no support yet. */
    public static boolean place(BlockPos p, double reach) {
        if (!free(p)) return false;
        reach = com.goku.modules.LegitMode.placeReach(reach);
        var mc = mc();
        Vec3d eye = mc.player.getEyePos();
        Direction[] order = {Direction.DOWN, Direction.NORTH, Direction.SOUTH, Direction.EAST, Direction.WEST, Direction.UP};
        for (Direction d : order) {
            BlockPos nb = p.offset(d);
            if (mc.world.getBlockState(nb).isReplaceable()) continue;
            Direction face = d.getOpposite();
            Vec3d hit = Vec3d.ofCenter(nb).add(Vec3d.of(face.getVector()).multiply(0.5));
            if (eye.distanceTo(hit) > reach) continue;
            mc.interactionManager.interactBlock(mc.player, Hand.MAIN_HAND, new BlockHitResult(hit, face, nb, false));
            mc.player.swingHand(Hand.MAIN_HAND);
            return true;
        }
        return false;
    }

    /**
     * Blocks around a standing entity in the order they should be placed so each one has support:
     * floor, feet-level sides, head-level sides, then the cap (one side block at cap height first, then the cap itself).
     */
    public static List<BlockPos> shell(BlockPos feet, boolean base, boolean head, boolean top) {
        List<BlockPos> l = new ArrayList<>();
        Direction[] h = {Direction.NORTH, Direction.SOUTH, Direction.EAST, Direction.WEST};
        if (base) l.add(feet.down());
        for (Direction d : h) l.add(feet.offset(d));
        if (head) for (Direction d : h) l.add(feet.up().offset(d));
        if (top) { l.add(feet.up(2).offset(h[0])); l.add(feet.up(2)); }
        return l;
    }
}
