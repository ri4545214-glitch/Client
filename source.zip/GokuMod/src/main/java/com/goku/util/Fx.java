package com.goku.util;

import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.gui.DrawContext;

/** Small drawing helpers shared by the visual modules: rounded panels, glow, arrows, colour ramps. */
public final class Fx {
    private static String ver;

    public static String version() {
        if (ver == null) ver = FabricLoader.getInstance().getModContainer("gokumod").map(c -> c.getMetadata().getVersion().getFriendlyString()).orElse("");
        return ver;
    }

    public static int a(int col, int alpha) { return Esp.a(col, alpha); }

    /** Scales the alpha of an ARGB colour by k (0..1). */
    public static int fadeA(int col, float k) {
        k = Math.max(0f, Math.min(1f, k));
        return ((int) (((col >>> 24) & 255) * k) << 24) | (col & 0xFFFFFF);
    }

    public static int mix(int a, int b, float t) {
        t = Math.max(0f, Math.min(1f, t));
        int r = (int) (((a >> 16) & 255) * (1 - t) + ((b >> 16) & 255) * t);
        int g = (int) (((a >> 8) & 255) * (1 - t) + ((b >> 8) & 255) * t);
        int bl = (int) ((a & 255) * (1 - t) + (b & 255) * t);
        return 0xFF000000 | (r << 16) | (g << 8) | bl;
    }

    /** Red (0) -> yellow (0.5) -> green (1). */
    public static int healthColor(float f) {
        f = Math.max(0f, Math.min(1f, f));
        int r = f < 0.5f ? 255 : (int) (255 * (1 - (f - 0.5f) * 2));
        int g = f > 0.5f ? 255 : (int) (255 * f * 2);
        return 0xFF000000 | (r << 16) | (g << 8) | 0x30;
    }

    public static double time() { return (System.nanoTime() % 1_000_000_000_000L) / 1e9; }

    /** Filled rectangle with 2px rounded corners (pixels never overlap, so translucent colours stay even). */
    public static void round(DrawContext c, int x1, int y1, int x2, int y2, int col) {
        if (x2 - x1 < 5 || y2 - y1 < 5) { c.fill(x1, y1, x2, y2, col); return; }
        c.fill(x1 + 2, y1, x2 - 2, y2, col);
        c.fill(x1 + 1, y1 + 1, x1 + 2, y2 - 1, col);
        c.fill(x2 - 2, y1 + 1, x2 - 1, y2 - 1, col);
        c.fill(x1, y1 + 2, x1 + 1, y2 - 2, col);
        c.fill(x2 - 1, y1 + 2, x2, y2 - 2, col);
    }

    /** Soft outer glow: fading 1px outlines around a rectangle. maxAlpha is the alpha of the innermost layer. */
    public static void glow(DrawContext c, int x1, int y1, int x2, int y2, int col, int layers, int maxAlpha) {
        for (int i = 1; i <= layers; i++) {
            float t = 1f - (i - 1f) / layers;
            int al = (int) (maxAlpha * t * t);
            if (al < 2) continue;
            Draw.outline(c, x1 - i, y1 - i, x2 + i, y2 + i, a(col, al));
        }
    }

    /** Filled triangle pointing along ang (radians, 0 = right, PI/2 = down) centred on cx, cy. */
    public static void arrow(DrawContext c, double cx, double cy, double ang, int size, int col) {
        var m = c.getMatrices();
        m.pushMatrix();
        m.translate((float) cx, (float) cy);
        m.rotate((float) ang);
        int h = size / 2;
        for (int x = -h; x <= h; x += 2) {
            int half = (int) Math.round((h - x) * 0.62);
            c.fill(x, -half, x + 2, half + 1, col);
        }
        m.popMatrix();
    }

    /** Filled diamond of radius r. */
    public static void diamond(DrawContext c, double cx, double cy, int r, int col) {
        var m = c.getMatrices();
        m.pushMatrix();
        m.translate((float) cx, (float) cy);
        m.rotate((float) (Math.PI / 4));
        c.fill(-r, -r, r, r, col);
        m.popMatrix();
    }
}
