# MJ Client (Fabric 1.21.11)

Client-side Fabric mod with a draggable Click GUI.

- Open GUI: **Right Shift** (or type `/mj` in chat - useful on mobile)
- Left click a module = toggle, right click = open its settings
- Drag a panel header to move it, right click a header to collapse
- Config is saved to `config/mjclient.properties`

## Modules
**Base**: Storage ESP (chests, ender chests, hoppers, barrels, shulkers, furnaces, dispensers; boxes, fill, tracers, labels, range),
Entity ESP, Aimbot (players / hostile / passive, range, FOV, speed, aim point, priority, visible only).
**Client**: HUD (watermark + module list), Theme (accent color, rainbow, dim).

## Build on GitHub
1. Create a GitHub repo and upload everything in this folder (keep the `.github` folder).
2. Open the **Actions** tab -> "Build MJ Client" runs automatically (or press "Run workflow").
3. When it finishes, open the run and download the **mj-client** artifact. Inside is `mj-client-1.0.0.jar`.
4. Put the jar in your mods folder together with Fabric API 1.21.11.
