# MJ Client (Fabric 1.21.11)
Right Shift (or /mj) opens the click GUI. Mod source is in ./mod-src.
`gradle build` at the root downloads Gradle 9.2.1 and builds the mod; the jar ends up in build/libs/.
