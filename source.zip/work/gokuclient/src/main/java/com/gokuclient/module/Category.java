package com.gokuclient.module;

public enum Category {
    CRYSTAL("Crystal PvP", "CRYSTAL PVP"),
    SWORD("Sword PvP", "SWORD PVP"),
    MACE("Mace PvP", "MACE PVP");

    public final String label, tag;
    Category(String label, String tag) { this.label = label; this.tag = tag; }
}
