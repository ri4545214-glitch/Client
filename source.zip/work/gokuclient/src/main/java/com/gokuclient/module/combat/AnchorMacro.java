package com.gokuclient.module.combat;

import com.gokuclient.module.*;
import com.gokuclient.module.Module;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.RespawnAnchorBlock;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Items;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

import java.util.HashSet;
import java.util.Set;

/** Hold right-click on a block: place anchor -> charge -> (safe block) -> explode. */
public class AnchorMacro extends Module {
    private final Setting.Num minDelay = add(new Setting.Num("Min Delay", 20, 0, 500, 5));
    private final Setting.Num maxDelay = add(new Setting.Num("Max Delay", 60, 0, 500, 5));
    private final Setting.Bool silentAim = add(new Setting.Bool("Silent Aim", true));
    private final Setting.Bool autoSwap = add(new Setting.Bool("Auto Swap", true));
    private final Setting.Bool onlyOwn = add(new Setting.Bool("Only Own Anchors", true));
    private final Setting.Bool safeAnchor = add(new Setting.Bool("Safe Anchor", true));

    private enum Step { IDLE, CHARGE, SHIELD, EXPLODE }
    private Step step = Step.IDLE;
    private BlockPos anchor;
    private int prevSlot;
    private long nextAction, stepStart;
    private boolean armed = true;
    private final Set<BlockPos> own = new HashSet<>();

    public AnchorMacro() {
        super("Anchor Macro", "Instant anchors. Place, safe anchor, explode.", Category.CRYSTAL);
    }

    @Override public void onEnable() { step = Step.IDLE; own.clear(); }

    private void setStep(Step s, long now) { step = s; stepStart = now; nextAction = now + randomDelay(minDelay, maxDelay); }

    @Override
    public void onTick() {
        if (mc.currentScreen != null || mc.interactionManager == null) return;
        long now = System.currentTimeMillis();
        if (!mc.options.useKey.isPressed()) armed = true;
        if (step != Step.IDLE) {
            mc.options.useKey.setPressed(false); // stop vanilla right-click fighting the macro
            if (now - stepStart > 1500) step = Step.IDLE;
        }
        if (now < nextAction) return;

        switch (step) {
            case IDLE -> idle(now);
            case CHARGE -> charge(now);
            case SHIELD -> shield(now);
            case EXPLODE -> explode(now);
        }
    }

    private void look(Vec3d v) { if (silentAim.value) PlayerUtil.silentLook(v); }

    private void idle(long now) {
        if (!armed || !mc.options.useKey.isPressed()) return;
        if (!(mc.crosshairTarget instanceof BlockHitResult bh) || bh.getType() != HitResult.Type.BLOCK) return;
        BlockPos target = bh.getBlockPos();
        prevSlot = mc.player.getInventory().getSelectedSlot();

        if (mc.world.getBlockState(target).isOf(Blocks.RESPAWN_ANCHOR)) {
            if (onlyOwn.value && !own.contains(target)) return;
            armed = false; anchor = target; setStep(Step.CHARGE, now);
            return;
        }
        BlockPos ap = target.offset(bh.getSide());
        if (!mc.world.isAir(ap)) return;
        int slot = PlayerUtil.find(s -> s.isOf(Items.RESPAWN_ANCHOR));
        if (slot < 0) return;
        if (autoSwap.value) PlayerUtil.select(slot);
        else if (!mc.player.getMainHandStack().isOf(Items.RESPAWN_ANCHOR)) return;

        armed = false;
        look(Vec3d.ofCenter(ap));
        PlayerUtil.useBlock(target, bh.getSide(), false);
        own.add(ap); anchor = ap;
        setStep(Step.CHARGE, now);
    }

    private void charge(long now) {
        BlockState st = mc.world.getBlockState(anchor);
        if (!st.isOf(Blocks.RESPAWN_ANCHOR)) { if (now - stepStart > 400) step = Step.IDLE; return; }
        if (st.get(RespawnAnchorBlock.CHARGES) > 0) { setStep(safeAnchor.value ? Step.SHIELD : Step.EXPLODE, now); return; }

        int slot = PlayerUtil.find(s -> s.isOf(Items.GLOWSTONE));
        if (slot < 0) { step = Step.IDLE; return; }
        if (autoSwap.value) PlayerUtil.select(slot);
        else if (!mc.player.getMainHandStack().isOf(Items.GLOWSTONE)) return;
        look(Vec3d.ofCenter(anchor));
        PlayerUtil.useBlock(anchor, Direction.UP, false);
        nextAction = now + randomDelay(minDelay, maxDelay);
    }

    /** Puts a block between you and the anchor so the blast can't reach you. */
    private void shield(long now) {
        Direction toPlayer = Direction.getFacing(mc.player.getX() - anchor.getX(), 0, mc.player.getZ() - anchor.getZ());
        BlockPos sp = anchor.offset(toPlayer);
        if (mc.world.isAir(sp) && mc.world.getBlockState(sp.down()).isSolidBlock(mc.world, sp.down())) {
            int slot = PlayerUtil.find(s -> s.getItem() instanceof BlockItem
                    && !s.isOf(Items.GLOWSTONE) && !s.isOf(Items.RESPAWN_ANCHOR));
            if (slot >= 0 && autoSwap.value) {
                PlayerUtil.select(slot);
                look(Vec3d.ofCenter(sp));
                PlayerUtil.useBlock(sp.down(), Direction.UP, false);
            }
        }
        setStep(Step.EXPLODE, now);
    }

    private void explode(long now) {
        int slot = prevSlot;
        if (mc.player.getInventory().getStack(slot).isOf(Items.GLOWSTONE))
            slot = PlayerUtil.find(s -> !s.isOf(Items.GLOWSTONE));
        if (autoSwap.value) PlayerUtil.select(slot);
        else if (mc.player.getMainHandStack().isOf(Items.GLOWSTONE)) return;
        look(Vec3d.ofCenter(anchor));
        PlayerUtil.useBlock(anchor, Direction.UP, false);
        own.remove(anchor);
        step = Step.IDLE;
        nextAction = now + randomDelay(minDelay, maxDelay);
    }
}
