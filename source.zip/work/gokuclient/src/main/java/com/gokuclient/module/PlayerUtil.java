package com.gokuclient.module;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.item.ItemStack;
import net.minecraft.network.packet.c2s.play.HandSwingC2SPacket;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

import java.util.function.Predicate;

public final class PlayerUtil {
    private static final MinecraftClient mc = MinecraftClient.getInstance();

    /** First hotbar slot matching the predicate, or -1. */
    public static int find(Predicate<ItemStack> p) {
        for (int i = 0; i < 9; i++) if (p.test(mc.player.getInventory().getStack(i))) return i;
        return -1;
    }

    public static void select(int slot) {
        if (slot >= 0 && slot < 9 && mc.player.getInventory().getSelectedSlot() != slot)
            mc.player.getInventory().setSelectedSlot(slot);
    }

    public static void swing(boolean silent) {
        if (silent) mc.getNetworkHandler().sendPacket(new HandSwingC2SPacket(Hand.MAIN_HAND));
        else mc.player.swingHand(Hand.MAIN_HAND);
    }

    /** Right-click the given face of a block with the main hand. */
    public static ActionResult useBlock(BlockPos pos, Direction face, boolean silentSwing) {
        Vec3d hit = Vec3d.ofCenter(pos).add(face.getOffsetX() * 0.5, face.getOffsetY() * 0.5, face.getOffsetZ() * 0.5);
        BlockHitResult r = new BlockHitResult(hit, face, pos, false);
        ActionResult res = mc.interactionManager.interactBlock(mc.player, Hand.MAIN_HAND, r);
        if (res.isAccepted()) swing(silentSwing);
        return res;
    }

    public static void attack(Entity e, boolean silentSwing) {
        mc.interactionManager.attackEntity(mc.player, e);
        swing(silentSwing);
    }

    /** Sends a look packet to the server without turning your camera. */
    public static void silentLook(Vec3d target) {
        Vec3d eye = mc.player.getEyePos();
        double dx = target.x - eye.x, dy = target.y - eye.y, dz = target.z - eye.z;
        float yaw = (float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0);
        float pitch = (float) -Math.toDegrees(Math.atan2(dy, Math.hypot(dx, dz)));
        mc.getNetworkHandler().sendPacket(new PlayerMoveC2SPacket.LookAndOnGround(
                yaw, pitch, mc.player.isOnGround(), mc.player.horizontalCollision));
    }
}
