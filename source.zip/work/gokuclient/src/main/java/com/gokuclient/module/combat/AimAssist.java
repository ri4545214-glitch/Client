package com.gokuclient.module.combat;

/** Gentle, legit-looking version of Auto Aim: short range, slow, only while you attack. */
public class AimAssist extends AutoAim {
    public AimAssist() {
        super("Aim Assist", "Gently pulls your aim toward targets while you fight.");
        range.value = 4.5; fov.value = 70; smooth.value = 12; maxSpeed.value = 10;
        needClick.value = true; hostile.value = false;
    }
}
