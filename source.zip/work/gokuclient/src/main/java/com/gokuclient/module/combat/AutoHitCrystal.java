package com.gokuclient.module.combat;

import com.gokuclient.module.*;
import com.gokuclient.module.Module;
import net.minecraft.block.Blocks;
import net.minecraft.entity.decoration.EndCrystalEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.registry.tag.ItemTags;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;

import java.util.List;

/** Places obsidian beside the enemy's feet, crystals it, explodes it, then (optionally) double taps. */
public class AutoHitCrystal extends Module {
    private final Setting.Num minDelay = add(new Setting.Num("Min Delay", 30, 0, 500, 5));
    private final Setting.Num maxDelay = add(new Setting.Num("Max Delay", 80, 0, 500, 5));
    private final Setting.Mode crystalMode = add(new Setting.Mode("Crystal Mode", 1, "Single", "Double Tap"));
    private final Setting.Bool damageTick = add(new Setting.Bool("Damage Tick", true));
    private final Setting.Bool pauseOnKill = add(new Setting.Bool("Pause On Kill", true));

    private enum Step { IDLE, CRYSTAL, BREAK, FOLLOW }
    private Step step = Step.IDLE;
    private BlockPos obi;
    private PlayerEntity target;
    private long nextAction, pauseUntil, stepStart;
    private boolean armed = true;
    private final KillTracker kills = new KillTracker();

    private static final Direction[] SIDES = {Direction.NORTH, Direction.SOUTH, Direction.EAST, Direction.WEST};

    public AutoHitCrystal() {
        super("Auto Hit Crystal", "Places obsidian at your enemy's feet to instantly double tap them.", Category.CRYSTAL);
    }

    @Override public void onEnable() { step = Step.IDLE; kills.reset(); }

    private void setStep(Step s, long now) { step = s; stepStart = now; nextAction = now + randomDelay(minDelay, maxDelay); }

    @Override
    public void onTick() {
        if (mc.currentScreen != null || mc.interactionManager == null) return;
        long now = System.currentTimeMillis();

        if (kills.update() && pauseOnKill.value) { pauseUntil = now + 1500; step = Step.IDLE; }
        if (!mc.options.useKey.isPressed()) armed = true;   // hold right-click to trigger
        if (step != Step.IDLE && now - stepStart > 1500) step = Step.IDLE;
        if (now < pauseUntil || now < nextAction) return;

        switch (step) {
            case IDLE -> idle(now);
            case CRYSTAL -> crystal(now);
            case BREAK -> breakCrystal(now);
            case FOLLOW -> follow(now);
        }
    }

    private void idle(long now) {
        if (!armed || !mc.options.useKey.isPressed()) return;
        target = nearestEnemy();
        if (target == null) return;
        int obiSlot = PlayerUtil.find(s -> s.isOf(Items.OBSIDIAN));
        int crySlot = PlayerUtil.find(s -> s.isOf(Items.END_CRYSTAL));
        if (obiSlot < 0 || crySlot < 0) return;

        BlockPos spot = pickSpot(target);
        if (spot == null) return;
        armed = false;
        obi = spot;
        if (!mc.world.getBlockState(spot).isOf(Blocks.OBSIDIAN)) {
            PlayerUtil.select(obiSlot);
            PlayerUtil.useBlock(spot.down(), Direction.UP, false);
        }
        setStep(Step.CRYSTAL, now);
    }

    private void crystal(long now) {
        if (!mc.world.getBlockState(obi).isOf(Blocks.OBSIDIAN)) return; // wait for server
        int crySlot = PlayerUtil.find(s -> s.isOf(Items.END_CRYSTAL));
        if (crySlot < 0) { step = Step.IDLE; return; }
        PlayerUtil.select(crySlot);
        PlayerUtil.useBlock(obi, Direction.UP, false);
        setStep(Step.BREAK, now);
    }

    private void breakCrystal(long now) {
        List<EndCrystalEntity> list = mc.world.getEntitiesByClass(EndCrystalEntity.class, new Box(obi.up()), e -> true);
        if (list.isEmpty()) return; // wait for crystal to spawn
        if (damageTick.value && target != null && target.hurtTime > 0) return;
        PlayerUtil.attack(list.get(0), false);
        setStep(crystalMode.get().equals("Double Tap") ? Step.FOLLOW : Step.IDLE, now);
    }

    private void follow(long now) {
        int w = PlayerUtil.find(s -> s.isIn(ItemTags.SWORDS) || s.isIn(ItemTags.AXES));
        if (w >= 0 && target != null && target.isAlive() && mc.player.distanceTo(target) <= 3.5f) {
            PlayerUtil.select(w);
            PlayerUtil.attack(target, false);
        }
        step = Step.IDLE;
        nextAction = now + randomDelay(minDelay, maxDelay);
    }

    private PlayerEntity nearestEnemy() {
        PlayerEntity best = null; double bd = 5.0 * 5.0;
        for (PlayerEntity p : mc.world.getPlayers()) {
            if (p == mc.player || !p.isAlive() || p.isSpectator()) continue;
            double d = p.squaredDistanceTo(mc.player);
            if (d < bd) { bd = d; best = p; }
        }
        return best;
    }

    /** Free block next to the enemy's feet with solid ground and 2 blocks of air above. */
    private BlockPos pickSpot(PlayerEntity t) {
        BlockPos feet = t.getBlockPos();
        BlockPos best = null; double bd = Double.MAX_VALUE;
        for (Direction d : SIDES) {
            BlockPos p = feet.offset(d);
            boolean existing = mc.world.getBlockState(p).isOf(Blocks.OBSIDIAN);
            if (!existing && !mc.world.isAir(p)) continue;
            if (!mc.world.isAir(p.up()) || !mc.world.isAir(p.up(2))) continue;
            if (!existing && !mc.world.getBlockState(p.down()).isSolidBlock(mc.world, p.down())) continue;
            double dist = p.getSquaredDistance(mc.player.getBlockPos());
            if (dist > 4.5 * 4.5) continue;
            if (dist < bd) { bd = dist; best = p; }
        }
        return best;
    }
}
