package com.gokuclient.module;

import java.util.List;
import java.util.Locale;

public abstract class Setting {
    public final String name;
    protected Setting(String name) { this.name = name; }

    public static class Bool extends Setting {
        public boolean value;
        public Bool(String name, boolean value) { super(name); this.value = value; }
        public void toggle() { value = !value; }
    }

    public static class Num extends Setting {
        public double value, min, max, step;
        public Num(String name, double value, double min, double max, double step) {
            super(name); this.min = min; this.max = max; this.step = step; this.value = value;
        }
        public void set(double v) {
            v = Math.round(v / step) * step;
            value = Math.max(min, Math.min(max, v));
        }
        public float norm() { return (float) ((value - min) / (max - min)); }
        public String text() {
            return step >= 1 ? String.valueOf((int) Math.round(value)) : String.format(Locale.ROOT, "%.1f", value);
        }
    }

    public static class Mode extends Setting {
        public final List<String> modes;
        public int index;
        public Mode(String name, int def, String... modes) { super(name); this.modes = List.of(modes); this.index = def; }
        public String get() { return modes.get(index); }
        public void cycle(int dir) { index = (index + dir + modes.size()) % modes.size(); }
    }
}
