package com.gokuclient;

import com.gokuclient.gui.ClickGuiScreen;
import com.gokuclient.module.ModuleManager;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;

public class GokuClient implements ClientModInitializer {
    public static final String MOD_ID = "gokuclient";
    public static final String NAME = "Goku Client v2";
    private static KeyBinding openShift, openAlt;

    @Override
    public void onInitializeClient() {
        KeyBinding.Category cat = KeyBinding.Category.create(Identifier.of(MOD_ID, "main"));
        openShift = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.gokuclient.open_shift", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_RIGHT_SHIFT, cat));
        openAlt = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.gokuclient.open_alt", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_RIGHT_ALT, cat));

        ModuleManager.init();

        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            boolean open = false;
            while (openShift.wasPressed()) open = true;
            while (openAlt.wasPressed()) open = true;
            if (open && mc.currentScreen == null) mc.setScreen(new ClickGuiScreen());
            ModuleManager.tick();
        });
    }
}
