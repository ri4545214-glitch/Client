package com.gokuclient.module;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.entity.mob.Monster;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

public final class Targets {
    private static final MinecraftClient mc = MinecraftClient.getInstance();

    public static Vec3d aimPoint(LivingEntity t, String mode) {
        double y = switch (mode) {
            case "Head" -> t.getEyeY();
            case "Feet" -> t.getY() + 0.1;
            default -> t.getBodyY(0.6);
        };
        return new Vec3d(t.getX(), y, t.getZ());
    }

    /** {yaw, pitch} needed to look at a point. */
    public static float[] rotationsTo(Vec3d v) {
        ClientPlayerEntity p = mc.player;
        double dx = v.x - p.getX(), dz = v.z - p.getZ(), dy = v.y - p.getEyeY();
        float yaw = (float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0);
        float pitch = (float) -Math.toDegrees(Math.atan2(dy, Math.hypot(dx, dz)));
        return new float[]{yaw, pitch};
    }

    public static LivingEntity find(double range, double fov, boolean players, boolean hostile,
                                    boolean passive, boolean visible, String aimMode) {
        ClientPlayerEntity p = mc.player;
        LivingEntity best = null; double bestD = Double.MAX_VALUE;
        for (Entity e : mc.world.getEntities()) {
            if (!(e instanceof LivingEntity le) || le == p || !le.isAlive() || le.isRemoved()) continue;
            if (le instanceof ArmorStandEntity || le.isInvisible()) continue;
            if (le instanceof PlayerEntity pl) { if (!players || pl.isSpectator()) continue; }
            else if (le instanceof Monster) { if (!hostile) continue; }
            else if (!passive) continue;
            double d = p.distanceTo(le);
            if (d > range) continue;
            if (visible && !p.canSee(le)) continue;
            if (fov < 360) {
                float[] r = rotationsTo(aimPoint(le, aimMode));
                float dy = MathHelper.wrapDegrees(r[0] - p.getYaw()), dp = r[1] - p.getPitch();
                if (Math.sqrt(dy * dy + dp * dp) > fov / 2.0) continue;
            }
            if (d < bestD) { bestD = d; best = le; }
        }
        return best;
    }
}
