package com.gokuclient.gui;

import com.gokuclient.GokuClient;
import com.gokuclient.module.Category;
import com.gokuclient.module.Module;
import com.gokuclient.module.ModuleManager;
import com.gokuclient.module.Setting;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.input.KeyInput;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.math.MathHelper;
import org.lwjgl.glfw.GLFW;

import java.util.*;

public class ClickGuiScreen extends Screen {
    // Palette: deep navy + indigo, matching the Prestige-style cards
    static final int ACCENT = 0xFF6D5BF5, ACCENT2 = 0xFF9D8CFF;
    static final int BG = 0xF2090919, HEADER = 0xFF0F0F28;
    static final int CARD = 0xFF101030, CARD_HOVER = 0xFF1A1A44, BORDER = 0xFF23234F;
    static final int PILL_BG = 0xFF181845, PILL_BORDER = 0xFF30307A, PILL_TEXT = 0xFFC9C9FF;
    static final int TEXT = 0xFFF2F2FF, DIM = 0xFF8A8AAE, GREEN = 0xFF22C55E;
    static final int W = 200, HEAD = 30, ROW_H = 27, PAD = 5, HDR = 29;

    private enum Type { HEADER, MODULE, BOOL, NUM, MODE }
    private record Hit(Type type, float x, float y, float w, float h, Module m, Setting s, Panel p) {
        boolean in(double mx, double my) { return mx >= x && mx <= x + w && my >= y && my <= y + h; }
    }
    private static final class Panel {
        final Category cat; float x, y, scroll, maxScroll; boolean collapsed;
        final Anim scrollA = new Anim(0);
        Panel(Category c, float x, float y) { cat = c; this.x = x; this.y = y; }
    }
    private static final class Ripple {
        final String key; final float x, y, start;
        Ripple(String k, float x, float y, float s) { key = k; this.x = x; this.y = y; start = s; }
    }

    private final List<Panel> panels = new ArrayList<>();
    private final Map<String, Anim> anims = new HashMap<>();
    private final List<Ripple> ripples = new ArrayList<>();
    private final List<Hit> hits = new ArrayList<>();

    private float openT = 0f, time = 0f, visTop, visBot;
    private boolean closing = false;
    private long last = System.nanoTime();

    private Panel dragPanel; private float dragOX, dragOY;
    private Setting.Num dragNum; private float dragX, dragW;

    public ClickGuiScreen() {
        super(Text.literal(GokuClient.NAME));
        float px = 30;
        for (Category c : Category.values()) { panels.add(new Panel(c, px, 36)); px += W + 14; }
    }

    private Anim an(String key, float init) { return anims.computeIfAbsent(key, k -> new Anim(init)); }

    @Override public boolean shouldPause() { return false; }
    @Override public void renderBackground(DrawContext c, int mx, int my, float d) { /* custom, no vanilla blur */ }
    @Override public void close() { closing = true; }

    private static float sh(Setting s) { return (s instanceof Setting.Num ? 25 : 19) + 3; }
    private static float settingsHeight(Module m) {
        if (m.settings.isEmpty()) return 0;
        float h = HDR + 2;
        for (Setting s : m.settings) h += sh(s);
        return h;
    }
    private boolean inView(float y, float h) { return y + h > visTop && y < visBot; }

    // ------------------------------------------------------------------ render
    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        long now = System.nanoTime();
        float dt = Math.min((now - last) / 1_000_000_000f, 0.05f);
        last = now; time += dt;

        openT += (closing ? -dt / 0.22f : dt / 0.5f);
        openT = MathHelper.clamp(openT, 0f, 1f);
        if (closing && openT <= 0f) { client.setScreen(null); return; }

        hits.clear();
        ripples.removeIf(r -> time - r.start > 0.55f);

        float bgA = Math.min(1f, openT * 1.4f);
        ctx.fill(0, 0, width, height, Draw.alpha(0xFF02020A, 0.55f * bgA));
        ctx.fillGradient(0, height / 2, width, height, 0x00000000, Draw.alpha(ACCENT, 0.18f * bgA));

        // branding
        Draw.text(ctx, "GOKU CLIENT", 10, 9 - (1 - bgA) * 8, Draw.alpha(TEXT, bgA));
        Draw.text(ctx, "v2", 10 + Draw.width("GOKU CLIENT ") , 9 - (1 - bgA) * 8, Draw.alpha(ACCENT2, bgA));
        String hint = "Right-click: settings / collapse   |   Scroll: panel   |   Right Shift or Right Alt: close";
        Draw.text(ctx, hint, (width - Draw.width(hint)) / 2f, height - 14 + (1 - bgA) * 10, Draw.alpha(DIM, bgA));

        if (dragPanel != null) {
            dragPanel.x = MathHelper.clamp(mx - dragOX, 0, width - W);
            dragPanel.y = MathHelper.clamp(my - dragOY, 0, height - HEAD);
        }
        if (dragNum != null) {
            dragNum.set(dragNum.min + MathHelper.clamp((mx - dragX) / dragW, 0f, 1f) * (dragNum.max - dragNum.min));
        }

        for (int i = 0; i < panels.size(); i++) {
            float stag = MathHelper.clamp(openT * 1.5f - i * 0.15f, 0f, 1f);
            float e = closing ? Anim.outCubic(stag) : Anim.outBack(stag);
            drawPanel(ctx, panels.get(i), mx, my, dt, e, MathHelper.clamp(stag * 1.4f, 0f, 1f), stag);
        }
    }

    private void drawPanel(DrawContext ctx, Panel p, int mx, int my, float dt, float e, float pa, float stag) {
        List<Module> mods = ModuleManager.byCategory(p.cat);
        Anim col = an("col:" + p.cat, 1f);
        col.to(p.collapsed ? 0f : 1f, dt, 14);

        float body = PAD;
        for (Module m : mods) {
            Anim ex = an("ex:" + m.name, 0f);
            ex.to(m.expanded ? 1f : 0f, dt, 14);
            body += ROW_H + settingsHeight(m) * ex.v;
        }
        body += PAD;
        float avail = Math.max(90f, height - p.y - HEAD - 10f);
        float bodyVis = Math.min(body, avail);
        p.maxScroll = Math.max(0f, body - bodyVis);
        p.scroll = MathHelper.clamp(p.scroll, 0f, p.maxScroll);
        p.scrollA.to(p.scroll, dt, 18);

        float x = p.x, y = p.y + (1 - e) * 30f;
        float totalH = HEAD + bodyVis * col.v;

        for (int i = 4; i >= 1; i--)
            Draw.round(ctx, x - i * 2, y - i * 2 + 3, W + i * 4, totalH + i * 4, 9 + i, Draw.alpha(0xFF000000, 0.07f * pa));
        Draw.card(ctx, x, y, W, totalH, 9, Draw.alpha(BG, pa), Draw.alpha(BORDER, pa));
        Draw.round(ctx, x + 1, y + 1, W - 2, HEAD - 1, 8, Draw.alpha(HEADER, pa));
        if (col.v > 0.02f) Draw.rect(ctx, x + 1, y + HEAD - 8, W - 2, 8, Draw.alpha(HEADER, pa));

        for (int i = 8; i < W - 8; i += 2) { // animated accent line
            float t = (float) (0.5 + 0.5 * Math.sin(time * 2.2 + i * 0.045));
            Draw.rect(ctx, x + i, y + HEAD - 1, 2, 1, Draw.alpha(Draw.lerp(ACCENT, ACCENT2, t), pa));
        }
        Draw.text(ctx, p.cat.tag, x + 12, y + 11, Draw.alpha(TEXT, pa));
        String cnt = String.valueOf(mods.size());
        Draw.text(ctx, cnt, x + W - 12 - Draw.width(cnt), y + 11, Draw.alpha(DIM, pa));
        hits.add(new Hit(Type.HEADER, x, y, W, HEAD, null, null, p));

        if (col.v < 0.01f) return;
        visTop = y + HEAD; visBot = y + HEAD + bodyVis * col.v;
        ctx.enableScissor(Math.round(x), Math.round(visTop), Math.round(x + W), Math.round(visBot));

        float cy = y + HEAD + PAD - p.scrollA.v;
        boolean clickable = col.v > 0.95f;
        int idx = 0;
        for (Module m : mods) {
            float ra = pa * MathHelper.clamp(stag * 2f - idx * 0.2f, 0f, 1f) * col.v;
            float rx = x + 6 + (1 - ra) * -12f, rw = W - 12, rh = ROW_H - 3;

            boolean hover = mx >= rx && mx <= rx + rw && my >= cy && my <= cy + rh
                    && my >= visTop && my <= visBot && dragPanel == null;
            Anim hv = an("hv:" + m.name, 0f); hv.to(hover ? 1f : 0f, dt, 16);
            Anim en = an("en:" + m.name, 0f); en.to(m.enabled ? 1f : 0f, dt, 12);
            Anim pop = an("pop:" + m.name, 0f); pop.to(0f, dt, 7);
            Anim ex = an("ex:" + m.name, 0f);

            int fill = Draw.lerp(CARD, CARD_HOVER, hv.v);
            fill = Draw.lerp(fill, ACCENT, 0.10f * en.v + 0.14f * pop.v);
            int border = Draw.lerp(BORDER, ACCENT, Math.min(1f, en.v * 0.8f + hv.v * 0.35f));
            Draw.card(ctx, rx, cy, rw, rh, 7, Draw.alpha(fill, ra), Draw.alpha(border, ra));

            ctx.enableScissor(Math.round(rx), Math.round(Math.max(cy, visTop)),
                    Math.round(rx + rw), Math.round(Math.min(cy + rh, visBot)));
            for (Ripple r : ripples) {
                if (!r.key.equals(m.name)) continue;
                float t = (time - r.start) / 0.55f;
                Draw.circle(ctx, Math.round(r.x), Math.round(r.y), (int) (Anim.outCubic(t) * rw * 1.1f),
                        Draw.alpha(0xFFFFFFFF, (1 - t) * 0.16f * ra));
            }
            ctx.disableScissor();
            ctx.enableScissor(Math.round(x), Math.round(visTop), Math.round(x + W), Math.round(visBot));

            Draw.text(ctx, m.name, rx + 10 + 2 * en.v, cy + 8, Draw.alpha(Draw.lerp(0xFFB8B8D6, 0xFFFFFFFF, en.v), ra));

            // "In Action" status pill (green) fades in when enabled
            float cx = rx + rw - 16;
            if (en.v > 0.02f) {
                String t = "In Action";
                float pw = Draw.width(t) + 18, px = cx - pw - 2, py = cy + 4;
                float pal = ra * en.v;
                Draw.card(ctx, px, py, pw, 14, 7, Draw.alpha(0xFF0B1F1A, pal), Draw.alpha(0xFF14532D, pal));
                Draw.circle(ctx, Math.round(px + 8), Math.round(py + 7), 2, Draw.alpha(GREEN, pal));
                Draw.text(ctx, t, px + 13, py + 3, Draw.alpha(GREEN, pal));
            }
            if (!m.settings.isEmpty())
                Draw.text(ctx, ex.v > 0.5f ? "v" : ">", rx + rw - 12, cy + 8, Draw.alpha(Draw.lerp(DIM, ACCENT2, ex.v), ra));
            if (clickable && inView(cy, rh)) hits.add(new Hit(Type.MODULE, rx, cy, rw, rh, m, null, p));
            cy += ROW_H;

            float full = settingsHeight(m), shown = full * ex.v;
            if (shown > 0.5f) {
                float sa = ra * ex.v;
                ctx.enableScissor(Math.round(x), Math.round(Math.max(cy - 2, visTop)),
                        Math.round(x + W), Math.round(Math.min(cy - 2 + shown, visBot)));
                float yy = cy;
                String tag = m.category.tag;
                float tw = Draw.width(tag) + 12;
                Draw.card(ctx, rx + 1, yy, tw, 12, 6, Draw.alpha(PILL_BG, sa), Draw.alpha(PILL_BORDER, sa));
                Draw.text(ctx, tag, rx + 7, yy + 2, Draw.alpha(ACCENT2, sa));
                yy += 15;
                Draw.text(ctx, Draw.trim(m.description, (int) rw - 4), rx + 3, yy, Draw.alpha(DIM, sa));
                yy += 14;
                boolean settingsClickable = clickable && ex.v > 0.9f;
                for (Setting s : m.settings) {
                    drawSetting(ctx, s, m, rx, rw, yy, sa, dt, p, settingsClickable);
                    yy += sh(s);
                }
                ctx.disableScissor();
                ctx.enableScissor(Math.round(x), Math.round(visTop), Math.round(x + W), Math.round(visBot));
            }
            cy += shown;
            idx++;
        }
        ctx.disableScissor();
    }

    private void drawSetting(DrawContext ctx, Setting s, Module m, float rx, float rw, float yy,
                             float al, float dt, Panel p, boolean addHits) {
        String key = m.name + ":" + s.name;
        int label = Draw.alpha(0xFFC4C4E0, al);
        float h = sh(s) - 3;
        Draw.card(ctx, rx, yy, rw, h, 6, Draw.alpha(0xFF0D0D26, al), Draw.alpha(BORDER, al));

        if (s instanceof Setting.Bool b) {
            Anim a = an("b:" + key, b.value ? 1f : 0f); a.to(b.value ? 1f : 0f, dt, 16);
            Draw.text(ctx, s.name, rx + 9, yy + 6, label);
            pill(ctx, b.value ? "On" : "Off", rx + rw - 6, yy + 3, 13,
                    Draw.lerp(0xFF7A7A99, PILL_TEXT, a.v), Draw.lerp(0xFF121230, PILL_BG, a.v),
                    Draw.lerp(BORDER, PILL_BORDER, a.v), al);
            if (addHits && inView(yy, h)) hits.add(new Hit(Type.BOOL, rx, yy, rw, h, m, s, p));

        } else if (s instanceof Setting.Num n) {
            Anim a = an("n:" + key, n.norm()); a.to(n.norm(), dt, 20);
            Draw.text(ctx, s.name, rx + 9, yy + 5, label);
            pill(ctx, n.text(), rx + rw - 6, yy + 3, 13, PILL_TEXT, PILL_BG, PILL_BORDER, al);
            float tx = rx + 9, tw = rw - 18, ty = yy + 19;
            Draw.round(ctx, tx, ty, tw, 3, 1.5f, Draw.alpha(0xFF2A2A4A, al));
            Draw.round(ctx, tx, ty, Math.max(3, tw * a.v), 3, 1.5f, Draw.alpha(ACCENT, al));
            Draw.round(ctx, tx + tw * a.v - 3.5f, ty - 2, 7, 7, 3.5f, Draw.alpha(0xFFFFFFFF, al));
            if (addHits && inView(yy, h)) hits.add(new Hit(Type.NUM, tx, yy + 14, tw, 11, m, s, p));

        } else if (s instanceof Setting.Mode md) {
            Anim fl = an("m:" + key, 0f); fl.to(0f, dt, 7);
            Draw.text(ctx, s.name, rx + 9, yy + 6, label);
            pill(ctx, md.get(), rx + rw - 6, yy + 3, 13, Draw.lerp(PILL_TEXT, 0xFFFFFFFF, fl.v),
                    Draw.lerp(PILL_BG, ACCENT, fl.v * 0.5f), Draw.lerp(PILL_BORDER, ACCENT2, fl.v), al);
            if (addHits && inView(yy, h)) hits.add(new Hit(Type.MODE, rx, yy, rw, h, m, s, p));
        }
    }

    /** Right-aligned value pill (like the "On" / "Double Tap" badges). */
    private void pill(DrawContext ctx, String t, float right, float y, float h, int tc, int bg, int border, float al) {
        float w = Draw.width(t) + 14, x = right - w;
        Draw.card(ctx, x, y, w, h, h / 2f, Draw.alpha(bg, al), Draw.alpha(border, al));
        Draw.text(ctx, t, x + 7, y + (h - 8) / 2f, Draw.alpha(tc, al));
    }

    // ------------------------------------------------------------------ input
    private void click() {
        client.getSoundManager().play(PositionedSoundInstance.master(SoundEvents.UI_BUTTON_CLICK.value(), 1.0f));
    }

    @Override
    public boolean mouseClicked(Click click, boolean doubled) {
        if (closing) return true;
        double mx = click.x(), my = click.y();
        int b = click.button();
        for (int i = hits.size() - 1; i >= 0; i--) {
            Hit h = hits.get(i);
            if (!h.in(mx, my)) continue;
            if (h.type() != Type.HEADER && (my < h.p().y + HEAD)) continue;
            switch (h.type()) {
                case HEADER -> {
                    if (b == 0) { dragPanel = h.p(); dragOX = (float) mx - h.p().x; dragOY = (float) my - h.p().y; }
                    else if (b == 1) { h.p().collapsed = !h.p().collapsed; click(); }
                }
                case MODULE -> {
                    ripples.add(new Ripple(h.m().name, (float) mx, (float) my, time));
                    if (b == 0) { h.m().toggle(); an("pop:" + h.m().name, 0f).v = 1f; click(); }
                    else if (b == 1 && !h.m().settings.isEmpty()) { h.m().expanded = !h.m().expanded; click(); }
                }
                case BOOL -> { ((Setting.Bool) h.s()).toggle(); click(); }
                case NUM -> {
                    dragNum = (Setting.Num) h.s(); dragX = h.x(); dragW = h.w();
                    dragNum.set(dragNum.min + MathHelper.clamp(((float) mx - dragX) / dragW, 0f, 1f) * (dragNum.max - dragNum.min));
                }
                case MODE -> {
                    ((Setting.Mode) h.s()).cycle(b == 1 ? -1 : 1);
                    an("m:" + h.m().name + ":" + h.s().name, 0f).v = 1f; click();
                }
            }
            return true;
        }
        return super.mouseClicked(click, doubled);
    }

    @Override
    public boolean mouseReleased(Click click) {
        dragPanel = null; dragNum = null;
        return super.mouseReleased(click);
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double hAmount, double vAmount) {
        for (Panel p : panels) {
            if (mx >= p.x && mx <= p.x + W) {
                p.scroll = MathHelper.clamp(p.scroll - (float) vAmount * 22f, 0f, p.maxScroll);
                return true;
            }
        }
        return super.mouseScrolled(mx, my, hAmount, vAmount);
    }

    @Override
    public boolean keyPressed(KeyInput input) {
        int k = input.key();
        if (k == GLFW.GLFW_KEY_RIGHT_SHIFT || k == GLFW.GLFW_KEY_RIGHT_ALT || k == GLFW.GLFW_KEY_ESCAPE) {
            closing = true;
            return true;
        }
        return super.keyPressed(input);
    }
}
