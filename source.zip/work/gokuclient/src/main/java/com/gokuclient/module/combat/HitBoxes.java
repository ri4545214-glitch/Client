package com.gokuclient.module.combat;

import com.gokuclient.module.*;
import com.gokuclient.module.Module;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

import java.util.Optional;

/** Expands enemy hit boxes for your attacks (works by ray-testing enlarged boxes when you click). */
public class HitBoxes extends Module {
    private final Setting.Num expand = add(new Setting.Num("Expand", 0.3, 0.1, 1.0, 0.1));
    private final Setting.Num reach  = add(new Setting.Num("Reach", 3.0, 2.5, 4.0, 0.1));
    private final Setting.Bool players = add(new Setting.Bool("Players", true));
    private final Setting.Bool mobs    = add(new Setting.Bool("Mobs", false));
    private long next;

    public HitBoxes() {
        super("Hit Boxes", "Makes enemy hit boxes bigger so near-misses still hit.", Category.SWORD);
    }

    @Override
    public void onTick() {
        if (mc.currentScreen != null || mc.interactionManager == null) return;
        if (!mc.options.attackKey.isPressed()) return;
        if (mc.crosshairTarget instanceof EntityHitResult) return; // vanilla already hits
        long now = System.currentTimeMillis();
        if (now < next || mc.player.getAttackCooldownProgress(0.5f) < 0.9f) return;

        Vec3d eye = mc.player.getEyePos();
        Vec3d end = eye.add(mc.player.getRotationVec(1f).multiply(reach.value));
        Entity best = null; double bd = Double.MAX_VALUE;
        for (Entity e : mc.world.getEntities()) {
            if (!(e instanceof LivingEntity le) || e == mc.player || !le.isAlive()) continue;
            if (e instanceof PlayerEntity ? !players.value : !mobs.value) continue;
            Box b = e.getBoundingBox().expand(expand.value);
            Optional<Vec3d> hit = b.raycast(eye, end);
            if (hit.isEmpty()) continue;
            double d = eye.squaredDistanceTo(hit.get());
            if (d < bd) { bd = d; best = e; }
        }
        if (best == null) return;
        // don't hit through walls
        if (mc.crosshairTarget != null && mc.crosshairTarget.getType() == HitResult.Type.BLOCK
                && eye.squaredDistanceTo(mc.crosshairTarget.getPos()) < bd) return;
        PlayerUtil.attack(best, false);
        next = now + 120;
    }
}
