package com.gokuclient.module;

import com.gokuclient.module.combat.*;
import net.minecraft.client.MinecraftClient;
import java.util.ArrayList;
import java.util.List;

public final class ModuleManager {
    public static final List<Module> modules = new ArrayList<>();

    public static void init() {
        // Crystal PvP
        modules.add(new AutoCrystal());
        modules.add(new AutoHitCrystal());
        modules.add(new AutoTotem());
        modules.add(new AnchorMacro());
        // Sword PvP
        modules.add(new Triggerbot());
        modules.add(new AutoShieldBreaker());
        modules.add(new WTap());
        modules.add(new SilentAim());
        modules.add(new AimAssist());
        modules.add(new HitBoxes());
        modules.add(new AutoAim());
        // Mace PvP
        modules.add(new AutoMace());
        modules.add(new AutoPearlCatch());
        modules.add(new BreachSwap());
        modules.add(new ShortWindCharge());
    }

    public static List<Module> byCategory(Category c) {
        List<Module> l = new ArrayList<>();
        for (Module m : modules) if (m.category == c) l.add(m);
        return l;
    }

    public static void tick() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null) return;
        for (Module m : modules) if (m.enabled) m.onTick();
    }
}
