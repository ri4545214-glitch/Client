package com.gokuclient.module.combat;

import com.gokuclient.module.*;
import com.gokuclient.module.Module;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.Enchantments;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.util.hit.EntityHitResult;

/** Swaps to your Breach mace when you look at an armored target, then swaps back. */
public class BreachSwap extends Module {
    private final Setting.Num backDelay = add(new Setting.Num("Swap Back Delay", 150, 0, 1000, 10));
    private final Setting.Num range = add(new Setting.Num("Range", 3.5, 2.5, 6, 0.1));
    private final Setting.Bool onlyArmored = add(new Setting.Bool("Only Armored", true));
    private int prevSlot = -1;
    private long lastSeen;

    public BreachSwap() {
        super("Breach Swap", "Swaps to your Breach mace to strip armor.", Category.MACE);
    }

    @Override public void onDisable() { if (prevSlot >= 0 && mc.player != null) PlayerUtil.select(prevSlot); prevSlot = -1; }

    private static boolean hasBreach(ItemStack s) {
        if (!s.isOf(Items.MACE)) return false;
        for (RegistryEntry<Enchantment> e : s.getEnchantments().getEnchantments())
            if (e.matchesKey(Enchantments.BREACH)) return true;
        return false;
    }

    @Override
    public void onTick() {
        if (mc.currentScreen != null) return;
        long now = System.currentTimeMillis();
        boolean looking = mc.crosshairTarget instanceof EntityHitResult eh
                && eh.getEntity() instanceof LivingEntity le && le != mc.player && le.isAlive()
                && mc.player.distanceTo(le) <= range.value
                && (!onlyArmored.value || le.getArmor() > 0);

        if (looking) {
            lastSeen = now;
            int slot = PlayerUtil.find(BreachSwap::hasBreach);
            if (slot >= 0 && mc.player.getInventory().getSelectedSlot() != slot) {
                if (prevSlot < 0) prevSlot = mc.player.getInventory().getSelectedSlot();
                PlayerUtil.select(slot);
            }
        } else if (prevSlot >= 0 && now - lastSeen >= backDelay.value) {
            PlayerUtil.select(prevSlot);
            prevSlot = -1;
        }
    }
}
