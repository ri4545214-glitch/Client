package com.gokuclient.module;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import java.util.HashSet;
import java.util.Set;

/** Detects when a nearby player dies (used by "Pause On Kill"). */
public class KillTracker {
    private Set<Integer> tracked = new HashSet<>();

    public boolean update() {
        MinecraftClient mc = MinecraftClient.getInstance();
        boolean killed = false;
        Set<Integer> now = new HashSet<>();
        for (PlayerEntity p : mc.world.getPlayers()) {
            if (p == mc.player || p.distanceTo(mc.player) > 12) continue;
            if (p.isAlive()) now.add(p.getId());
        }
        for (int id : tracked) {
            if (now.contains(id)) continue;
            Entity e = mc.world.getEntityById(id);
            if (e != null && !e.isAlive()) killed = true;
        }
        tracked = now;
        return killed;
    }

    public void reset() { tracked = new HashSet<>(); }
}
