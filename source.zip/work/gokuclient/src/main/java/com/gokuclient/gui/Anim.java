package com.gokuclient.gui;

public final class Anim {
    public float v;
    public Anim(float v) { this.v = v; }

    /** Frame-rate independent smoothing toward target. */
    public void to(float target, float dt, float speed) {
        v += (target - v) * (1f - (float) Math.exp(-speed * dt));
        if (Math.abs(target - v) < 0.001f) v = target;
    }

    public static float outCubic(float t) { float f = 1 - t; return 1 - f * f * f; }
    public static float outBack(float t) {
        float c1 = 1.70158f, c3 = c1 + 1, f = t - 1;
        return 1 + c3 * f * f * f + c1 * f * f;
    }
}
