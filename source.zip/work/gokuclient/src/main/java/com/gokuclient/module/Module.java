package com.gokuclient.module;

import net.minecraft.client.MinecraftClient;
import java.util.ArrayList;
import java.util.List;

public abstract class Module {
    public final String name, description;
    public final Category category;
    public boolean enabled;
    public boolean expanded; // GUI state
    public final List<Setting> settings = new ArrayList<>();
    protected final MinecraftClient mc = MinecraftClient.getInstance();

    protected Module(String name, String description, Category category) {
        this.name = name; this.description = description; this.category = category;
    }

    protected <T extends Setting> T add(T s) { settings.add(s); return s; }

    /** Configurable randomized delay in ms, picked between the two sliders. */
    protected long randomDelay(Setting.Num min, Setting.Num max) {
        double lo = Math.min(min.value, max.value), hi = Math.max(min.value, max.value);
        return (long) (lo + Math.random() * (hi - lo));
    }

    public void toggle() { setEnabled(!enabled); }
    public void setEnabled(boolean e) {
        if (e == enabled) return;
        enabled = e;
        if (e) onEnable(); else onDisable();
    }
    public void onEnable() {}
    public void onDisable() {}
    public void onTick() {}
}
