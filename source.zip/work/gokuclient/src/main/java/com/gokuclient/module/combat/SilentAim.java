package com.gokuclient.module.combat;

import com.gokuclient.module.*;
import com.gokuclient.module.Module;
import net.minecraft.entity.LivingEntity;

/** Aims on the server only: your camera never moves. */
public class SilentAim extends Module {
    private final Setting.Num range = add(new Setting.Num("Range", 4.5, 1, 6, 0.5));
    private final Setting.Num fov   = add(new Setting.Num("FOV", 90, 10, 360, 5));
    private final Setting.Mode aimAt = add(new Setting.Mode("Aim At", 1, "Head", "Chest", "Feet"));
    private final Setting.Bool players = add(new Setting.Bool("Players", true));
    private final Setting.Bool hostile = add(new Setting.Bool("Hostile Mobs", true));
    private final Setting.Bool visible = add(new Setting.Bool("Visible Only", true));
    private final Setting.Bool onlyAttack = add(new Setting.Bool("Only On Attack", true));

    public SilentAim() {
        super("Silent Aim", "Server-side aim. Your camera stays where it is.", Category.SWORD);
    }

    @Override
    public void onTick() {
        if (mc.currentScreen != null) return;
        if (onlyAttack.value && !mc.options.attackKey.isPressed()) return;
        LivingEntity t = Targets.find(range.value, fov.value, players.value, hostile.value, false, visible.value, aimAt.get());
        if (t == null) return;
        PlayerUtil.silentLook(Targets.aimPoint(t, aimAt.get()));
    }
}
