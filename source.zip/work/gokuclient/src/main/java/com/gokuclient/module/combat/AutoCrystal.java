package com.gokuclient.module.combat;

import com.gokuclient.module.*;
import com.gokuclient.module.Module;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.entity.Entity;
import net.minecraft.entity.decoration.EndCrystalEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;

/** Places and explodes end crystals at the block you are looking at. */
public class AutoCrystal extends Module {
    private final Setting.Num minDelay = add(new Setting.Num("Min Delay", 20, 0, 500, 5));
    private final Setting.Num maxDelay = add(new Setting.Num("Max Delay", 60, 0, 500, 5));
    private final Setting.Mode headBob = add(new Setting.Mode("Head Bob", 1, "Normal", "Silent"));
    private final Setting.Bool damageTick = add(new Setting.Bool("Damage Tick", true));
    private final Setting.Bool pauseOnKill = add(new Setting.Bool("Pause On Kill", true));

    private long nextAction, pauseUntil;
    private final KillTracker kills = new KillTracker();

    public AutoCrystal() {
        super("Auto Crystal", "Automatically places and explodes end crystals at the block you are looking at.", Category.CRYSTAL);
    }

    @Override public void onEnable() { kills.reset(); }

    @Override
    public void onTick() {
        if (mc.currentScreen != null || mc.interactionManager == null) return;
        long now = System.currentTimeMillis();

        boolean killed = kills.update();
        if (killed && pauseOnKill.value) pauseUntil = now + 1500;
        if (now < pauseUntil || now < nextAction) return;

        boolean silent = headBob.get().equals("Silent");
        HitResult hr = mc.crosshairTarget;
        if (hr == null) return;

        // 1) explode the crystal we are looking at
        if (hr instanceof EntityHitResult eh && eh.getEntity() instanceof EndCrystalEntity crystal) {
            if (damageTick.value && targetInDamageTick(crystal)) return;
            PlayerUtil.attack(crystal, silent);
            nextAction = now + randomDelay(minDelay, maxDelay);
            return;
        }

        // 2) place a crystal on the obsidian / bedrock we are looking at
        if (hr.getType() == HitResult.Type.BLOCK && hr instanceof BlockHitResult bh) {
            if (!mc.player.getMainHandStack().isOf(Items.END_CRYSTAL)) return;
            BlockPos pos = bh.getBlockPos();
            BlockState st = mc.world.getBlockState(pos);
            if (!st.isOf(Blocks.OBSIDIAN) && !st.isOf(Blocks.BEDROCK)) return;
            if (!mc.world.isAir(pos.up()) || !mc.world.isAir(pos.up(2))) return;
            if (!mc.world.getOtherEntities(null, new Box(pos.up())).isEmpty()) return;
            PlayerUtil.useBlock(pos, bh.getSide(), silent);
            nextAction = now + randomDelay(minDelay, maxDelay);
        }
    }

    /** True if the nearest enemy to the crystal is still in hurt time (explosion would be wasted). */
    private boolean targetInDamageTick(Entity crystal) {
        PlayerEntity best = null; double bd = 36;
        for (PlayerEntity p : mc.world.getPlayers()) {
            if (p == mc.player || !p.isAlive()) continue;
            double d = p.squaredDistanceTo(crystal);
            if (d < bd) { bd = d; best = p; }
        }
        return best != null && best.hurtTime > 0;
    }
}
