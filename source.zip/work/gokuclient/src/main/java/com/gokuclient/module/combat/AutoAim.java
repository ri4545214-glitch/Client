package com.gokuclient.module.combat;

import com.gokuclient.module.Category;
import com.gokuclient.module.Module;
import com.gokuclient.module.Setting;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.entity.mob.Monster;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.MathHelper;

public class AutoAim extends Module {
    protected final Setting.Num range    = add(new Setting.Num("Range", 6, 1, 20, 0.5));
    protected final Setting.Num fov      = add(new Setting.Num("FOV", 120, 10, 360, 5));
    protected final Setting.Num smooth   = add(new Setting.Num("Smoothing", 5, 1, 20, 0.5));
    protected final Setting.Num maxSpeed = add(new Setting.Num("Max Speed", 40, 5, 180, 5));
    protected final Setting.Mode priority = add(new Setting.Mode("Priority", 0, "Distance", "Health", "Crosshair"));
    protected final Setting.Mode aimAt    = add(new Setting.Mode("Aim At", 1, "Head", "Chest", "Feet"));
    protected final Setting.Bool players  = add(new Setting.Bool("Players", true));
    protected final Setting.Bool hostile  = add(new Setting.Bool("Hostile Mobs", true));
    protected final Setting.Bool passive  = add(new Setting.Bool("Passive Mobs", false));
    protected final Setting.Bool invis    = add(new Setting.Bool("Invisible", false));
    protected final Setting.Bool visible  = add(new Setting.Bool("Visible Only", true));
    protected final Setting.Bool needClick = add(new Setting.Bool("Only On Attack", false));

    public AutoAim() { this("Auto Aim", "Smoothly aims at nearby players / mobs."); }

    protected AutoAim(String name, String description) {
        super(name, description, Category.SWORD);
    }

    @Override
    public void onTick() {
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.world == null || mc.currentScreen != null || !p.isAlive()) return;
        if (needClick.value && !mc.options.attackKey.isPressed()) return;

        LivingEntity target = findTarget(p);
        if (target == null) return;

        float[] r = rotations(p, target);
        float dYaw = MathHelper.wrapDegrees(r[0] - p.getYaw());
        float dPitch = r[1] - p.getPitch();

        float f = 1f / (float) smooth.value;
        float max = (float) maxSpeed.value;
        float sYaw = MathHelper.clamp(dYaw * f, -max, max);
        float sPitch = MathHelper.clamp(dPitch * f, -max, max);

        p.setYaw(p.getYaw() + sYaw);
        p.setPitch(MathHelper.clamp(p.getPitch() + sPitch, -90f, 90f));
    }

    private LivingEntity findTarget(ClientPlayerEntity p) {
        LivingEntity best = null;
        double bestScore = Double.MAX_VALUE;

        for (Entity e : mc.world.getEntities()) {
            if (!(e instanceof LivingEntity le) || le == p || !le.isAlive() || le.isRemoved()) continue;
            if (le instanceof ArmorStandEntity) continue;

            if (le instanceof PlayerEntity pl) {
                if (!players.value || pl.isSpectator()) continue;
            } else if (le instanceof Monster) {
                if (!hostile.value) continue;
            } else if (!passive.value) continue;

            if (le.isInvisible() && !invis.value) continue;
            if (p.distanceTo(le) > range.value) continue;
            if (visible.value && !p.canSee(le)) continue;

            float[] r = rotations(p, le);
            float dy = MathHelper.wrapDegrees(r[0] - p.getYaw());
            float dp = r[1] - p.getPitch();
            double angle = Math.sqrt(dy * dy + dp * dp);
            if (fov.value < 360 && angle > fov.value / 2.0) continue;

            double score = switch (priority.get()) {
                case "Health" -> le.getHealth();
                case "Crosshair" -> angle;
                default -> p.distanceTo(le);
            };
            if (score < bestScore) { bestScore = score; best = le; }
        }
        return best;
    }

    private float[] rotations(ClientPlayerEntity p, LivingEntity t) {
        double y = switch (aimAt.get()) {
            case "Head" -> t.getEyeY();
            case "Feet" -> t.getY() + 0.1;
            default -> t.getBodyY(0.6);
        };
        double dx = t.getX() - p.getX();
        double dz = t.getZ() - p.getZ();
        double dy = y - p.getEyeY();
        float yaw = (float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0);
        float pitch = (float) -Math.toDegrees(Math.atan2(dy, Math.hypot(dx, dz)));
        return new float[]{yaw, pitch};
    }
}
