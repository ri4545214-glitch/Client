package com.gokuclient.gui;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.util.math.MathHelper;

public final class Draw {
    public static int alpha(int c, float a) {
        int al = (int) (((c >>> 24) & 0xFF) * MathHelper.clamp(a, 0f, 1f));
        return (al << 24) | (c & 0xFFFFFF);
    }

    public static int lerp(int a, int b, float t) {
        t = MathHelper.clamp(t, 0f, 1f);
        int aa = (int) (((a >>> 24) & 255) + (((b >>> 24) & 255) - ((a >>> 24) & 255)) * t);
        int r = (int) (((a >> 16) & 255) + (((b >> 16) & 255) - ((a >> 16) & 255)) * t);
        int g = (int) (((a >> 8) & 255) + (((b >> 8) & 255) - ((a >> 8) & 255)) * t);
        int bl = (int) ((a & 255) + ((b & 255) - (a & 255)) * t);
        return (aa << 24) | (r << 16) | (g << 8) | bl;
    }

    public static void rect(DrawContext c, float x, float y, float w, float h, int col) {
        c.fill(Math.round(x), Math.round(y), Math.round(x + w), Math.round(y + h), col);
    }

    public static void round(DrawContext c, float x, float y, float w, float h, float r, int col) {
        if ((col >>> 24) == 0) return;
        int ix = Math.round(x), iy = Math.round(y), iw = Math.round(w), ih = Math.round(h);
        if (iw <= 0 || ih <= 0) return;
        int ir = (int) Math.min(r, Math.min(iw, ih) / 2f);
        if (ir <= 0) { c.fill(ix, iy, ix + iw, iy + ih, col); return; }
        c.fill(ix, iy + ir, ix + iw, iy + ih - ir, col);
        for (int i = 0; i < ir; i++) {
            double dy = ir - i - 0.5;
            int inset = (int) Math.round(ir - Math.sqrt(ir * ir - dy * dy));
            c.fill(ix + inset, iy + i, ix + iw - inset, iy + i + 1, col);
            c.fill(ix + inset, iy + ih - i - 1, ix + iw - inset, iy + ih - i, col);
        }
    }

    public static void circle(DrawContext c, int cx, int cy, int r, int col) {
        if ((col >>> 24) == 0 || r <= 0) return;
        for (int dy = -r; dy <= r; dy++) {
            int dx = (int) Math.sqrt((double) r * r - (double) dy * dy);
            c.fill(cx - dx, cy + dy, cx + dx, cy + dy + 1, col);
        }
    }

    public static void text(DrawContext c, String s, float x, float y, int col) {
        if ((col >>> 24) < 8) return;
        c.drawText(MinecraftClient.getInstance().textRenderer, s, Math.round(x), Math.round(y), col, false);
    }

    public static int width(String s) { return MinecraftClient.getInstance().textRenderer.getWidth(s); }

    /** Rounded card with a 1px border. */
    public static void card(DrawContext c, float x, float y, float w, float h, float r, int fill, int border) {
        round(c, x, y, w, h, r, border);
        round(c, x + 1, y + 1, w - 2, h - 2, Math.max(0, r - 1), fill);
    }

    public static String trim(String s, int px) {
        return MinecraftClient.getInstance().textRenderer.trimToWidth(s, px);
    }
}
