package com.gokuclient.module.combat;

import com.gokuclient.module.*;
import com.gokuclient.module.Module;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import net.minecraft.util.math.Vec3d;

/** Right after you jump, throws a wind charge straight down (server-side) for a short boost. */
public class ShortWindCharge extends Module {
    private final Setting.Num minDelay = add(new Setting.Num("Min Delay", 0, 0, 300, 5));
    private final Setting.Num maxDelay = add(new Setting.Num("Max Delay", 30, 0, 300, 5));
    private final Setting.Bool swapBack = add(new Setting.Bool("Swap Back", true));
    private boolean armed = true;
    private long due;

    public ShortWindCharge() {
        super("Short Wind Charge", "Jump + instant wind charge for a short boost.", Category.MACE);
    }

    @Override public void onEnable() { armed = true; due = 0; }

    @Override
    public void onTick() {
        if (mc.currentScreen != null || mc.interactionManager == null) return;
        long now = System.currentTimeMillis();

        if (due > 0 && now >= due) {
            due = 0;
            int wind = PlayerUtil.find(s -> s.isOf(Items.WIND_CHARGE));
            if (wind >= 0) {
                int prev = mc.player.getInventory().getSelectedSlot();
                PlayerUtil.select(wind);
                PlayerUtil.silentLook(new Vec3d(mc.player.getX(), mc.player.getY() - 1.0, mc.player.getZ()));
                mc.interactionManager.interactItem(mc.player, Hand.MAIN_HAND);
                PlayerUtil.swing(false);
                if (swapBack.value) PlayerUtil.select(prev);
            }
        }

        if (mc.player.isOnGround()) { armed = true; return; }
        if (armed && mc.options.jumpKey.isPressed() && mc.player.getVelocity().y > 0.1) {
            armed = false;
            due = now + randomDelay(minDelay, maxDelay);
        }
    }
}
