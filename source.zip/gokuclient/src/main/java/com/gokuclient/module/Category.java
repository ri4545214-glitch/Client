package com.gokuclient.module;

public enum Category {
    OFFENSE("Offense", "OFFENSE"),
    CORE("Core Module", "CORE MODULE");

    public final String label, tag;
    Category(String label, String tag) { this.label = label; this.tag = tag; }
}
