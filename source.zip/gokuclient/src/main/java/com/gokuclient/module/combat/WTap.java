package com.gokuclient.module.combat;

import com.gokuclient.module.*;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.hit.EntityHitResult;

/** Resets sprint right after you hit so the next hit gets full sprint knockback. */
public class WTap extends Module {
    private final Setting.Num chance = add(new Setting.Num("Chance %", 100, 0, 100, 5));
    private final Setting.Bool playersOnly = add(new Setting.Bool("Players Only", true));
    private float lastCd = 1f;

    public WTap() {
        super("W Tap", "Resets your sprint after each hit for extra knockback.", Category.SWORD);
    }

    @Override
    public void onTick() {
        float cd = mc.player.getAttackCooldownProgress(0.5f);
        boolean attacked = lastCd >= 0.8f && cd < 0.4f;
        lastCd = cd;
        if (!attacked || !mc.player.isSprinting()) return;
        if (Math.random() * 100.0 >= chance.value) return;
        if (playersOnly.value && !(mc.crosshairTarget instanceof EntityHitResult eh && eh.getEntity() instanceof PlayerEntity)) return;
        mc.player.setSprinting(false);
    }
}
