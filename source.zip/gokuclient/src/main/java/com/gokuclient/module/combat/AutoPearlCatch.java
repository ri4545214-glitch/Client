package com.gokuclient.module.combat;

import com.gokuclient.module.*;
import net.minecraft.entity.projectile.thrown.EnderPearlEntity;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import net.minecraft.util.math.Vec3d;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * After you throw an ender pearl, fires a wind charge at your feet (server-side look down)
 * so you ride the pearl up for a mace smash.
 */
public class AutoPearlCatch extends Module {
    private final Setting.Num minDelay = add(new Setting.Num("Min Delay", 60, 0, 1000, 10));
    private final Setting.Num maxDelay = add(new Setting.Num("Max Delay", 140, 0, 1000, 10));
    private final Setting.Bool swapBack = add(new Setting.Bool("Swap Back", true));
    private final Set<Integer> handled = new HashSet<>();
    private long due;

    public AutoPearlCatch() {
        super("Auto Pearl Catch", "Wind charge boost timed to your own ender pearl.", Category.MACE);
    }

    @Override public void onEnable() { handled.clear(); due = 0; }

    @Override
    public void onTick() {
        if (mc.currentScreen != null || mc.interactionManager == null) return;
        long now = System.currentTimeMillis();

        List<EnderPearlEntity> pearls = mc.world.getEntitiesByClass(EnderPearlEntity.class,
                mc.player.getBoundingBox().expand(8), p -> p.getOwner() == mc.player);
        for (EnderPearlEntity p : pearls)
            if (p.age < 10 && handled.add(p.getId())) due = now + randomDelay(minDelay, maxDelay);
        if (pearls.isEmpty()) handled.clear();

        if (due > 0 && now >= due) {
            due = 0;
            int wind = PlayerUtil.find(s -> s.isOf(Items.WIND_CHARGE));
            if (wind < 0) return;
            int prev = mc.player.getInventory().getSelectedSlot();
            PlayerUtil.select(wind);
            PlayerUtil.silentLook(new Vec3d(mc.player.getX(), mc.player.getY() - 1.0, mc.player.getZ()));
            mc.interactionManager.interactItem(mc.player, Hand.MAIN_HAND);
            PlayerUtil.swing(false);
            if (swapBack.value) PlayerUtil.select(prev);
        }
    }
}
