package com.gokuclient.module;

import com.gokuclient.module.combat.*;
import net.minecraft.client.MinecraftClient;
import java.util.ArrayList;
import java.util.List;

public final class ModuleManager {
    public static final List<Module> modules = new ArrayList<>();

    public static void init() {
        modules.add(new AnchorMacro());
        modules.add(new AutoHitCrystal());
        modules.add(new AutoAim());
        modules.add(new AutoCrystal());
    }

    public static List<Module> byCategory(Category c) {
        List<Module> l = new ArrayList<>();
        for (Module m : modules) if (m.category == c) l.add(m);
        return l;
    }

    public static void tick() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null) return;
        for (Module m : modules) if (m.enabled) m.onTick();
    }
}
