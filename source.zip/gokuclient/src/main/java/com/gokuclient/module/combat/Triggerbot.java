package com.gokuclient.module.combat;

import com.gokuclient.module.*;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.registry.tag.ItemTags;
import net.minecraft.util.hit.EntityHitResult;

/** Attacks automatically when your crosshair is on a target. */
public class Triggerbot extends Module {
    private final Setting.Num minDelay = add(new Setting.Num("Min Delay", 20, 0, 300, 5));
    private final Setting.Num maxDelay = add(new Setting.Num("Max Delay", 70, 0, 300, 5));
    private final Setting.Num cooldown = add(new Setting.Num("Cooldown %", 90, 0, 100, 5));
    private final Setting.Bool players = add(new Setting.Bool("Players", true));
    private final Setting.Bool mobs    = add(new Setting.Bool("Mobs", false));
    private final Setting.Bool weapon  = add(new Setting.Bool("Only Weapon", true));
    private long next;

    public Triggerbot() {
        super("Triggerbot", "Attacks the moment your crosshair is on a target.", Category.SWORD);
    }

    @Override
    public void onTick() {
        if (mc.currentScreen != null || mc.interactionManager == null) return;
        long now = System.currentTimeMillis();
        if (now < next) return;
        if (!(mc.crosshairTarget instanceof EntityHitResult eh)) return;
        Entity e = eh.getEntity();
        if (!(e instanceof LivingEntity le) || !le.isAlive() || e == mc.player) return;
        if (e instanceof PlayerEntity ? !players.value : !mobs.value) return;
        if (weapon.value) {
            var s = mc.player.getMainHandStack();
            if (!s.isIn(ItemTags.SWORDS) && !s.isIn(ItemTags.AXES) && !s.isOf(Items.MACE)) return;
        }
        if (mc.player.getAttackCooldownProgress(0.5f) * 100f < cooldown.value) return;
        PlayerUtil.attack(e, false);
        next = now + randomDelay(minDelay, maxDelay);
    }
}
