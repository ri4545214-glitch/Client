package com.gokuclient.module.combat;

import com.gokuclient.module.*;
import net.minecraft.item.Items;
import net.minecraft.screen.slot.SlotActionType;

/** Keeps a totem of undying in your offhand. */
public class AutoTotem extends Module {
    private final Setting.Num minDelay = add(new Setting.Num("Min Delay", 40, 0, 500, 5));
    private final Setting.Num maxDelay = add(new Setting.Num("Max Delay", 110, 0, 500, 5));
    private final Setting.Num health   = add(new Setting.Num("Health Threshold", 20, 1, 20, 1));
    private long next;

    public AutoTotem() {
        super("Auto Totem", "Keeps a totem of undying in your offhand.", Category.CRYSTAL);
    }

    @Override
    public void onTick() {
        if (mc.currentScreen != null || mc.interactionManager == null) return;
        long now = System.currentTimeMillis();
        if (now < next) return;
        if (mc.player.getOffHandStack().isOf(Items.TOTEM_OF_UNDYING)) return;
        if (mc.player.getHealth() + mc.player.getAbsorptionAmount() > health.value) return;

        for (int i = 0; i < 36; i++) {
            if (!mc.player.getInventory().getStack(i).isOf(Items.TOTEM_OF_UNDYING)) continue;
            int slotId = i < 9 ? 36 + i : i;
            mc.interactionManager.clickSlot(mc.player.playerScreenHandler.syncId, slotId, 40,
                    SlotActionType.SWAP, mc.player);
            next = now + randomDelay(minDelay, maxDelay);
            return;
        }
    }
}
