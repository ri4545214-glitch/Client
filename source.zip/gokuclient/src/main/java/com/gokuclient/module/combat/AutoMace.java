package com.gokuclient.module.combat;

import com.gokuclient.module.*;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.util.hit.EntityHitResult;

/** While falling, swaps to your mace and smashes the target under your crosshair. */
public class AutoMace extends Module {
    private final Setting.Num minFall = add(new Setting.Num("Min Fall", 1.5, 0.5, 10, 0.5));
    private final Setting.Num range   = add(new Setting.Num("Range", 3.5, 2.5, 6, 0.1));
    private final Setting.Num minDelay = add(new Setting.Num("Min Delay", 10, 0, 300, 5));
    private final Setting.Num maxDelay = add(new Setting.Num("Max Delay", 50, 0, 300, 5));
    private final Setting.Bool autoSwap = add(new Setting.Bool("Auto Swap", true));
    private final Setting.Bool swapBack = add(new Setting.Bool("Swap Back", true));
    private final Setting.Bool players  = add(new Setting.Bool("Players Only", true));
    private int prevSlot = -1;
    private long next;

    public AutoMace() {
        super("Auto Mace", "Swaps to the mace and smashes while you fall.", Category.MACE);
    }

    @Override public void onDisable() { restore(); }

    private void restore() {
        if (prevSlot >= 0 && mc.player != null && swapBack.value) PlayerUtil.select(prevSlot);
        prevSlot = -1;
    }

    @Override
    public void onTick() {
        if (mc.currentScreen != null || mc.interactionManager == null) return;
        double fd = mc.player.fallDistance;
        boolean falling = !mc.player.isOnGround() && fd >= minFall.value;
        if (!falling) { if (prevSlot >= 0) restore(); return; }

        if (!(mc.crosshairTarget instanceof EntityHitResult eh)
                || !(eh.getEntity() instanceof LivingEntity le) || !le.isAlive()) return;
        if (players.value && !(le instanceof PlayerEntity)) return;
        if (mc.player.distanceTo(le) > range.value) return;

        int mace = PlayerUtil.find(s -> s.isOf(Items.MACE));
        if (mace < 0) return;
        if (autoSwap.value) {
            if (prevSlot < 0) prevSlot = mc.player.getInventory().getSelectedSlot();
            PlayerUtil.select(mace);
        } else if (!mc.player.getMainHandStack().isOf(Items.MACE)) return;

        long now = System.currentTimeMillis();
        if (now >= next && mc.player.getAttackCooldownProgress(0.5f) >= 0.9f) {
            PlayerUtil.attack(le, false);
            next = now + randomDelay(minDelay, maxDelay);
        }
    }
}
