package com.gokuclient.module.combat;

import com.gokuclient.module.*;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.registry.tag.ItemTags;
import net.minecraft.util.hit.EntityHitResult;

/** Swaps to an axe when you look at a player who is blocking with a shield. */
public class AutoShieldBreaker extends Module {
    private final Setting.Num minDelay = add(new Setting.Num("Min Delay", 30, 0, 300, 5));
    private final Setting.Num maxDelay = add(new Setting.Num("Max Delay", 80, 0, 300, 5));
    private final Setting.Bool autoAttack = add(new Setting.Bool("Auto Attack", true));
    private final Setting.Bool swapBack   = add(new Setting.Bool("Swap Back", true));
    private int prevSlot = -1;
    private long next;

    public AutoShieldBreaker() {
        super("Auto Shield Breaker", "Swaps to your axe and breaks shields.", Category.SWORD);
    }

    @Override public void onDisable() { restore(); }

    private void restore() {
        if (prevSlot >= 0 && mc.player != null && swapBack.value) PlayerUtil.select(prevSlot);
        prevSlot = -1;
    }

    @Override
    public void onTick() {
        if (mc.currentScreen != null || mc.interactionManager == null) return;
        long now = System.currentTimeMillis();
        if (mc.crosshairTarget instanceof EntityHitResult eh
                && eh.getEntity() instanceof PlayerEntity pl && pl != mc.player && pl.isBlocking()) {
            int axe = PlayerUtil.find(s -> s.isIn(ItemTags.AXES));
            if (axe < 0) return;
            if (prevSlot < 0) prevSlot = mc.player.getInventory().getSelectedSlot();
            PlayerUtil.select(axe);
            if (autoAttack.value && now >= next && mc.player.getAttackCooldownProgress(0.5f) >= 0.9f) {
                PlayerUtil.attack(pl, false);
                next = now + randomDelay(minDelay, maxDelay);
            }
        } else if (prevSlot >= 0) {
            restore();
        }
    }
}
